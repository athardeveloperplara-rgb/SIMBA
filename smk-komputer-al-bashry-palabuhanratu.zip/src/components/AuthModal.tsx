import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SchoolLogo } from './SchoolLogo';
import { demoAccounts } from '../data/seedData';
import { X, Lock, User, CheckCircle2, ShieldAlert, ArrowRight } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, login } = useApp();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const success = login(username, password);
    if (!success) {
      setError('Username atau sandi tidak cocok. Gunakan tombol demo di bawah untuk login instan.');
    }
  };

  const handleSelectDemo = (demoUser: typeof demoAccounts[0]) => {
    setUsername(demoUser.username);
    setPassword(demoUser.username + '123');
    setError(null);
    login(demoUser.username, demoUser.username + '123');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#0B1F3A] p-6 text-white relative">
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="absolute top-4 right-4 p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="bg-white p-1 rounded-full shadow-md">
              <SchoolLogo size={48} />
            </div>
            <div>
              <h2 className="text-xl font-bold font-heading text-white">
                Login SIAKAD & Portal
              </h2>
              <p className="text-xs text-sky-200 mt-0.5">
                SMK Komputer Al-Bashry Palabuhanratu
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 flex-shrink-0 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username / Email / NIP / NISN
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Contoh: admin, guru, rizki.pratama"
                  required
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Kata Sandi
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 shadow-sm transition"
            >
              <span>Masuk ke Sistem</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* 1-Click Role Fill */}
          <div className="pt-4 border-t border-slate-100">
            <p className="text-xs font-bold text-slate-600 mb-2.5 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Pilih Akun Demo (1-Klik Otomatis Masuk):
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {demoAccounts.map(demo => (
                <button
                  key={demo.role}
                  type="button"
                  onClick={() => handleSelectDemo(demo)}
                  className="text-left p-2.5 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 transition flex flex-col group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 group-hover:text-blue-700">
                      {demo.role === 'super_admin' && '👑 Super Admin'}
                      {demo.role === 'guru' && '👨‍🏫 Guru TKJ'}
                      {demo.role === 'wali_kelas' && '📋 Wali Kelas'}
                      {demo.role === 'siswa' && '🎓 Siswa'}
                      {demo.role === 'orang_tua' && '👨‍👩‍👧 Orang Tua'}
                      {demo.role === 'petugas_ppdb' && '📝 Petugas PPDB'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">user: {demo.username}</span>
                  </div>
                  <span className="text-[11px] text-slate-500 truncate mt-0.5">
                    {demo.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 text-center text-[11px] text-slate-500">
          Sistem Informasi Akademik terenkripsi & terproteksi Role-Based Access Control (RBAC).
        </div>
      </div>
    </div>
  );
};
