import React from 'react';
import { useApp } from '../context/AppContext';
import { demoAccounts } from '../data/seedData';
import { ShieldCheck, User, LogOut, LayoutDashboard, Globe, KeyRound } from 'lucide-react';

export const RoleSwitcherBanner: React.FC = () => {
  const { 
    currentUser, 
    quickSwitchRole, 
    logout, 
    isSiakadMode, 
    navigateToSiakad, 
    exitSiakadToPublic,
    setIsAuthModalOpen
  } = useApp();

  return (
    <aside aria-label="Demo Bar" className="no-print bg-[#071426] text-white text-xs border-b border-slate-800 py-1.5 px-4 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        {/* Left: Role Indicator */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 font-semibold text-sky-400 bg-sky-950/60 px-2.5 py-0.5 rounded-full border border-sky-800/40">
            <ShieldCheck className="w-3.5 h-3.5" />
            Mode Demo RBAC:
          </span>
          {currentUser ? (
            <div className="flex items-center gap-2">
              <span className="font-medium text-slate-200">
                {currentUser.fullName}
              </span>
              <span className="bg-blue-600/30 text-blue-300 font-mono text-[10px] uppercase px-2 py-0.5 rounded border border-blue-500/30">
                {currentUser.role.replace('_', ' ')}
              </span>
            </div>
          ) : (
            <span className="text-slate-400">Pengunjung Publik (Belum Login)</span>
          )}
        </div>

        {/* Center / Quick Switch Buttons */}
        <div className="flex items-center flex-wrap gap-1.5">
          <span className="text-slate-400 hidden lg:inline">Cepat Uji Peran:</span>
          {demoAccounts.map(demo => (
            <button
              key={demo.role}
              onClick={() => {
                quickSwitchRole(demo.role);
                if (!isSiakadMode) {
                  navigateToSiakad('dashboard');
                }
              }}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                currentUser?.role === demo.role
                  ? 'bg-blue-600 text-white shadow-sm ring-1 ring-blue-300'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
              title={demo.desc}
            >
              {demo.role === 'super_admin' && '👑 Super Admin'}
              {demo.role === 'guru' && '👨‍🏫 Guru TKJ'}
              {demo.role === 'wali_kelas' && '📋 Wali Kelas'}
              {demo.role === 'siswa' && '🎓 Siswa'}
              {demo.role === 'orang_tua' && '👨‍👩‍👧 Orang Tua'}
              {demo.role === 'petugas_ppdb' && '📝 Petugas PPDB'}
            </button>
          ))}
        </div>

        {/* Right: Mode Toggle and Auth */}
        <div className="flex items-center gap-2">
          {currentUser ? (
            <>
              {isSiakadMode ? (
                <button
                  onClick={exitSiakadToPublic}
                  className="inline-flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-0.5 rounded text-xs transition"
                >
                  <Globe className="w-3 h-3 text-sky-400" />
                  Website Publik
                </button>
              ) : (
                <button
                  onClick={() => navigateToSiakad('dashboard')}
                  className="inline-flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white px-2.5 py-0.5 rounded text-xs font-semibold shadow transition"
                >
                  <LayoutDashboard className="w-3 h-3" />
                  Buka SIAKAD
                </button>
              )}
              <button
                onClick={logout}
                className="inline-flex items-center gap-1 text-rose-300 hover:text-rose-200 hover:bg-rose-950/40 px-2 py-0.5 rounded transition"
                title="Keluar / Logout"
              >
                <LogOut className="w-3 h-3" />
                Logout
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3 py-1 rounded text-xs font-semibold shadow transition"
            >
              <KeyRound className="w-3.5 h-3.5" />
              Masuk / Login
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};
