import React from 'react';

interface SchoolLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textColor?: string;
  subtextColor?: string;
  variant?: 'full' | 'icon' | 'badge';
}

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  className = '',
  size = 48,
  showText = false,
  textColor = 'text-slate-900',
  subtextColor = 'text-slate-500',
  variant = 'icon'
}) => {
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* High-fidelity SVG recreation of SMK Komputer Al-Bashry Seal */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0 drop-shadow-sm select-none"
      >
        <defs>
          {/* Radial & linear gradients matching the official badge */}
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F5D061" />
            <stop offset="50%" stopColor="#D4AF37" />
            <stop offset="100%" stopColor="#AA7C11" />
          </linearGradient>

          <linearGradient id="navyRing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0B1F3A" />
            <stop offset="50%" stopColor="#1E3A8A" />
            <stop offset="100%" stopColor="#071426" />
          </linearGradient>

          <linearGradient id="flameGrad" x1="50%" y1="100%" x2="50%" y2="0%">
            <stop offset="0%" stopColor="#DC2626" />
            <stop offset="40%" stopColor="#EA580C" />
            <stop offset="80%" stopColor="#FBBF24" />
            <stop offset="100%" stopColor="#FEF08A" />
          </linearGradient>

          <linearGradient id="blueGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="100%" stopColor="#1D4ED8" />
          </linearGradient>

          {/* Text paths for curved text */}
          {/* Top text arc: SMK KOMPUTER ALBASHRY */}
          <path
            id="textArcTop"
            d="M 65 250 A 185 185 0 0 1 435 250"
            fill="none"
          />
          {/* Bottom text arc: PALABUHANRATU • KAB. SUKABUMI */}
          <path
            id="textArcBottom"
            d="M 435 250 A 185 185 0 0 1 65 250"
            fill="none"
          />
        </defs>

        {/* Outer Golden Border */}
        <circle cx="250" cy="250" r="242" fill="url(#goldGrad)" />
        <circle cx="250" cy="250" r="236" fill="#0B1F3A" stroke="#FFFFFF" strokeWidth="2" />

        {/* Navy Ring for Text */}
        <circle cx="250" cy="250" r="232" fill="url(#navyRing)" />
        <circle cx="250" cy="250" r="172" fill="#FFFFFF" stroke="url(#goldGrad)" strokeWidth="6" />

        {/* Arched Typography */}
        <text
          fill="#FFFFFF"
          fontSize="24"
          fontWeight="800"
          letterSpacing="4"
          fontFamily="'Plus Jakarta Sans', 'Arial Black', sans-serif"
        >
          <textPath href="#textArcTop" startOffset="50%" textAnchor="middle">
            SMK KOMPUTER ALBASHRY
          </textPath>
        </text>

        {/* Gold Stars */}
        <g fill="url(#goldGrad)">
          <path d="M 52 250 l 4 -8 l 9 0 l -7 6 l 3 9 l -9 -5 l -9 5 l 3 -9 l -7 -6 l 9 0 Z" transform="translate(10, 0)" />
          <path d="M 448 250 l 4 -8 l 9 0 l -7 6 l 3 9 l -9 -5 l -9 5 l 3 -9 l -7 -6 l 9 0 Z" transform="translate(-10, 0)" />
        </g>

        <text
          fill="#FFFFFF"
          fontSize="18"
          fontWeight="700"
          letterSpacing="3"
          fontFamily="'Plus Jakarta Sans', 'Arial', sans-serif"
        >
          <textPath href="#textArcBottom" startOffset="50%" textAnchor="middle">
            PALABUHANRATU • KAB. SUKABUMI
          </textPath>
        </text>

        {/* Inner White Field with subtle coastal wave texture at bottom */}
        <g clipPath="url(#innerCircleClip)">
          <clipPath id="innerCircleClip">
            <circle cx="250" cy="250" r="169" />
          </clipPath>
          <circle cx="250" cy="250" r="169" fill="#FFFFFF" />

          {/* Coastal wave patterns at base */}
          <path
            d="M 120 370 Q 150 355 180 370 T 240 370 T 300 370 T 360 370 L 380 430 L 120 430 Z"
            fill="#E0F2FE"
            opacity="0.8"
          />
          <path
            d="M 100 385 Q 135 370 170 385 T 240 385 T 310 385 T 380 385 L 390 430 L 100 430 Z"
            fill="#BAE6FD"
            opacity="0.6"
          />
        </g>

        {/* Golden & Blue Crest Shield */}
        <g filter="drop-shadow(0px 4px 6px rgba(0,0,0,0.15))">
          {/* Outer Shield Outline */}
          <path
            d="M 155 155 
               C 155 155, 250 135, 250 135 
               C 250 135, 345 155, 345 155 
               C 345 250, 315 320, 250 365 
               C 185 320, 155 250, 155 155 Z"
            fill="#FFFFFF"
            stroke="url(#goldGrad)"
            strokeWidth="8"
            strokeLinejoin="round"
          />

          {/* Inner Blue Shield Border */}
          <path
            d="M 167 165 
               C 167 165, 250 148, 250 148 
               C 250 148, 333 165, 333 165 
               C 333 245, 306 308, 250 348 
               C 194 308, 167 245, 167 165 Z"
            fill="#FFFFFF"
            stroke="#1D4ED8"
            strokeWidth="5"
            strokeLinejoin="round"
          />
        </g>

        {/* Torch of Knowledge (Obor Ilmu) */}
        <g transform="translate(250, 155)">
          {/* Torch Flame */}
          <path
            d="M 0 -48 
               C 12 -38, 22 -26, 18 -10 
               C 14 2, 4 8, 0 10 
               C -4 8, -14 2, -18 -10 
               C -22 -26, -12 -38, 0 -48 Z"
            fill="url(#flameGrad)"
          />
          <path
            d="M 0 -36 
               C 6 -28, 10 -20, 8 -8 
               C 6 0, 2 4, 0 5 
               C -2 4, -6 0, -8 -8 
               C -10 -20, -6 -28, 0 -36 Z"
            fill="#FEF08A"
          />

          {/* Torch Bowl */}
          <path
            d="M -22 10 L 22 10 L 16 22 L -16 22 Z"
            fill="#1E3A8A"
            stroke="url(#goldGrad)"
            strokeWidth="2"
          />
          {/* Torch Handle */}
          <rect x="-6" y="22" width="12" height="24" rx="2" fill="#1E3A8A" stroke="url(#goldGrad)" strokeWidth="1.5" />
          <line x1="-12" y1="28" x2="12" y2="28" stroke="url(#goldGrad)" strokeWidth="2" />
        </g>

        {/* TKJ Computer Network Symbols */}
        <g transform="translate(250, 245)">
          {/* Center Globe (Internet) */}
          <circle cx="0" cy="0" r="28" fill="#F0F9FF" stroke="#0284C7" strokeWidth="3" />
          {/* Longitude / Latitude lines */}
          <ellipse cx="0" cy="0" rx="14" ry="28" fill="none" stroke="#0284C7" strokeWidth="2" />
          <line x1="-28" y1="0" x2="28" y2="0" stroke="#0284C7" strokeWidth="2" />
          <line x1="-22" y1="-12" x2="22" y2="-12" stroke="#0284C7" strokeWidth="1.5" />
          <line x1="-22" y1="12" x2="22" y2="12" stroke="#0284C7" strokeWidth="1.5" />

          {/* Dynamic Circular Networking Arrows */}
          <path
            d="M -34 -15 A 42 42 0 0 1 34 -15"
            fill="none"
            stroke="#0284C7"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <polygon points="34,-24 45,-12 30,-7" fill="#0284C7" />

          <path
            d="M 34 15 A 42 42 0 0 1 -34 15"
            fill="none"
            stroke="#1E3A8A"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <polygon points="-34,24 -45,12 -30,7" fill="#1E3A8A" />

          {/* Left: Computer Workstation */}
          <g transform="translate(-62, -2)">
            {/* Monitor */}
            <rect x="-16" y="-14" width="24" height="18" rx="2" fill="#FFFFFF" stroke="#0F172A" strokeWidth="2.5" />
            <rect x="-13" y="-11" width="18" height="12" fill="#0284C7" />
            {/* Stand */}
            <rect x="-6" y="4" width="4" height="5" fill="#0F172A" />
            <rect x="-10" y="9" width="12" height="3" rx="1" fill="#0F172A" />
            {/* Network connector line */}
            <path d="M 8 -5 L 24 -5" stroke="#0F172A" strokeWidth="2" strokeDasharray="3 2" />
            <circle cx="16" cy="14" r="3" fill="#0F172A" />
          </g>

          {/* Right: Computer Mouse with cable */}
          <g transform="translate(48, 14)">
            {/* Mouse body */}
            <rect x="-6" y="-10" width="18" height="24" rx="9" fill="#1E3A8A" stroke="#0F172A" strokeWidth="2" />
            {/* Buttons separator */}
            <line x1="3" y1="-10" x2="3" y2="-1" stroke="#FFFFFF" strokeWidth="1.5" />
            <line x1="-5" y1="-1" x2="11" y2="-1" stroke="#FFFFFF" strokeWidth="1" />
            {/* Cable going back */}
            <path d="M 3 -10 C 3 -22, -10 -15, -14 -12" fill="none" stroke="#0F172A" strokeWidth="2" />
          </g>
        </g>

        {/* Lower Banner Ribbon */}
        <g transform="translate(250, 345)" filter="drop-shadow(0px 3px 5px rgba(0,0,0,0.25))">
          {/* Banner Tails */}
          <polygon points="-125,12 -145,-5 -145,25 -125,20" fill="#071426" stroke="url(#goldGrad)" strokeWidth="2" />
          <polygon points="125,12 145,-5 145,25 125,20" fill="#071426" stroke="url(#goldGrad)" strokeWidth="2" />

          {/* Main Ribbon Body */}
          <path
            d="M -130 -8 
               L 130 -8 
               L 122 22 
               L -122 22 Z"
            fill="url(#navyRing)"
            stroke="url(#goldGrad)"
            strokeWidth="3"
          />

          {/* Ribbon Text */}
          <text
            x="0"
            y="12"
            fill="#FFFFFF"
            fontSize="14"
            fontWeight="800"
            letterSpacing="2.5"
            textAnchor="middle"
            fontFamily="'Plus Jakarta Sans', sans-serif"
          >
            SMK KOMPUTER ALBASHRY
          </text>
        </g>
      </svg>

      {showText && (
        <div className="flex flex-col">
          <span className={`font-extrabold tracking-tight leading-none text-base sm:text-lg font-heading ${textColor}`}>
            SMK KOMPUTER AL-BASHRY
          </span>
          <span className={`text-xs font-semibold tracking-wider uppercase mt-1 ${subtextColor}`}>
            Palabuhanratu • TKJ Unggulan
          </span>
        </div>
      )}
    </div>
  );
};
