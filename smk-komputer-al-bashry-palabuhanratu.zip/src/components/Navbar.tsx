import React, { useState } from 'react';
import { useApp, PublicPage } from '../context/AppContext';
import { SchoolLogo } from './SchoolLogo';
import { 
  Menu, 
  X, 
  ChevronDown, 
  LayoutDashboard, 
  User, 
  GraduationCap, 
  PhoneCall, 
  BookOpen, 
  FileText, 
  Users, 
  Image as ImageIcon,
  LogIn
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    publicPage, 
    navigateToPublic, 
    currentUser, 
    navigateToSiakad, 
    setIsAuthModalOpen 
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [academicDropdownOpen, setAcademicDropdownOpen] = useState(false);

  const handleNav = (page: PublicPage) => {
    navigateToPublic(page);
    setMobileMenuOpen(false);
    setProfileDropdownOpen(false);
    setAcademicDropdownOpen(false);
  };

  return (
    <header className="sticky top-8 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand */}
          <div 
            onClick={() => handleNav('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <SchoolLogo size={52} />
            <div className="flex flex-col">
              <span className="font-extrabold text-[#0B1F3A] text-lg sm:text-xl tracking-tight leading-tight group-hover:text-blue-600 transition">
                SMK KOMPUTER AL-BASHRY
              </span>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Palabuhanratu • Kab. Sukabumi (TKJ)
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 text-sm font-semibold text-slate-700">
            <button
              onClick={() => handleNav('home')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'home' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Beranda
            </button>

            {/* Profil with Submenu */}
            <div 
              className="relative"
              onMouseEnter={() => setProfileDropdownOpen(true)}
              onMouseLeave={() => setProfileDropdownOpen(false)}
            >
              <button
                onClick={() => handleNav('profil')}
                className={`px-3 py-2 rounded-lg transition inline-flex items-center gap-1 ${
                  publicPage === 'profil' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
                }`}
              >
                <span>Profil</span>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </button>

              {profileDropdownOpen && (
                <div className="absolute left-0 mt-1 w-64 bg-white rounded-xl shadow-xl border border-slate-100 py-2 animate-in fade-in slide-in-from-top-2 duration-150 z-50">
                  <button
                    onClick={() => handleNav('profil')}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition"
                  >
                    Identitas & Visi Misi Sekolah
                  </button>
                  <button
                    onClick={() => handleNav('profil')}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition"
                  >
                    Sambutan & Profil Kepala Sekolah
                  </button>
                  <button
                    onClick={() => handleNav('profil')}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition"
                  >
                    Struktur Organisasi & Tata Tertib
                  </button>
                  <button
                    onClick={() => handleNav('profil')}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition"
                  >
                    Sarana & Laboratorium Komputer
                  </button>
                </div>
              )}
            </div>

            {/* Program Keahlian TKJ */}
            <button
              onClick={() => handleNav('tkj')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'tkj' ? 'text-blue-600 bg-blue-50/80 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Program TKJ
            </button>

            {/* Akademik */}
            <button
              onClick={() => handleNav('akademik')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'akademik' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Akademik
            </button>

            {/* Guru & Tendik */}
            <button
              onClick={() => handleNav('guru')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'guru' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Guru & Tendik
            </button>

            {/* Berita */}
            <button
              onClick={() => handleNav('berita')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'berita' || publicPage === 'berita-detail' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Berita
            </button>

            {/* Galeri */}
            <button
              onClick={() => handleNav('galeri')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'galeri' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Galeri
            </button>

            {/* PPDB Online */}
            <button
              onClick={() => handleNav('ppdb')}
              className={`px-3 py-2 rounded-lg font-bold transition flex items-center gap-1.5 ${
                publicPage === 'ppdb' ? 'text-emerald-700 bg-emerald-50' : 'text-emerald-600 hover:bg-emerald-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              PPDB 2026
            </button>

            {/* Kontak */}
            <button
              onClick={() => handleNav('kontak')}
              className={`px-3 py-2 rounded-lg transition ${
                publicPage === 'kontak' ? 'text-blue-600 bg-blue-50/80' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              Kontak
            </button>
          </nav>

          {/* Right Action: Portal SIAKAD Button */}
          <div className="hidden sm:flex items-center gap-3">
            {currentUser ? (
              <button
                onClick={() => navigateToSiakad('dashboard')}
                className="bg-[#0B1F3A] hover:bg-[#1E3A8A] text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition group"
              >
                <LayoutDashboard className="w-4 h-4 text-sky-400 group-hover:rotate-12 transition-transform" />
                <span>Dashboard SIAKAD</span>
              </button>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-md shadow-blue-500/20 transition"
              >
                <LogIn className="w-4 h-4" />
                <span>Masuk SIAKAD</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex xl:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:text-blue-600 hover:bg-slate-100 transition"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-4 duration-200 shadow-xl">
          <button
            onClick={() => handleNav('home')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'home' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Beranda
          </button>
          <button
            onClick={() => handleNav('profil')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'profil' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Profil Sekolah
          </button>
          <button
            onClick={() => handleNav('tkj')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'tkj' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Program Keahlian TKJ
          </button>
          <button
            onClick={() => handleNav('akademik')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'akademik' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Akademik & Kalender
          </button>
          <button
            onClick={() => handleNav('guru')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'guru' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Direktori Guru & Tendik
          </button>
          <button
            onClick={() => handleNav('berita')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'berita' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Berita & Pengumuman
          </button>
          <button
            onClick={() => handleNav('galeri')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'galeri' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Galeri Kegiatan
          </button>
          <button
            onClick={() => handleNav('ppdb')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold bg-emerald-50 text-emerald-700 flex items-center justify-between"
          >
            <span>PPDB Online 2026/2027</span>
            <span className="text-xs bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full">Buka</span>
          </button>
          <button
            onClick={() => handleNav('kontak')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              publicPage === 'kontak' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-700'
            }`}
          >
            Kontak & Lokasi
          </button>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            {currentUser ? (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigateToSiakad('dashboard');
                }}
                className="w-full bg-[#0B1F3A] text-white py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4 text-sky-400" />
                <span>Masuk Dashboard SIAKAD</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsAuthModalOpen(true);
                }}
                className="w-full bg-blue-600 text-white py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Login SIAKAD</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
