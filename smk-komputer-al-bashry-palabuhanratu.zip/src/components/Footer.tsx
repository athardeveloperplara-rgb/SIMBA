import React from 'react';
import { useApp } from '../context/AppContext';
import { SchoolLogo } from './SchoolLogo';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ChevronRight, 
  ExternalLink,
  ShieldCheck,
  Cpu
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, navigateToPublic, setIsAuthModalOpen } = useApp();

  return (
    <footer className="no-print bg-[#071426] text-slate-300 border-t border-slate-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-slate-800">
          
          {/* Col 1: Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="bg-white p-1 rounded-full shadow-md">
                <SchoolLogo size={52} />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base tracking-tight leading-snug">
                  SMK KOMPUTER AL-BASHRY
                </h3>
                <p className="text-xs text-sky-400 font-semibold tracking-wide">
                  PALABUHANRATU
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Lembaga pendidikan kejuruan berfokus pada keahlian <strong className="text-white">Teknik Komputer dan Jaringan (TKJ)</strong> di Palabuhanratu, Sukabumi. Mempersiapkan generasi kompeten berstandar industri digital dan berakhlak mulia.
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono text-[11px] text-sky-300">
                <Cpu className="w-3.5 h-3.5" />
                NPSN: {settings.npsn}
              </span>
              <span className="inline-flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono text-[11px] text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5" />
                Akreditasi: {settings.accreditation}
              </span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-2 border-blue-500 pl-2.5">
              Tautan Navigasi
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => navigateToPublic('home')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Beranda Utama
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('profil')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Profil & Sejarah Sekolah
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('tkj')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Jurusan Teknik Komputer & Jaringan
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('akademik')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Kalender Akademik & PKL
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('guru')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Direktori Guru & Tendik
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('ppdb')} 
                  className="hover:text-white transition flex items-center gap-1.5 font-semibold text-emerald-400"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />
                  Pendaftaran PPDB Online
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Portal Akademik & Layanan */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-2 border-blue-500 pl-2.5">
              Layanan & Sistem
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => setIsAuthModalOpen(true)} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Portal SIAKAD (Login Guru & Siswa)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('ppdb')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Cek Status Kelulusan PPDB
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('berita')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Warta & Pengumuman Sekolah
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToPublic('galeri')} 
                  className="hover:text-white transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  Dokumentasi Praktik & Galeri
                </button>
              </li>
            </ul>

            <div className="mt-4 p-3 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
              <span className="font-semibold text-white block mb-0.5">Tahun Pelajaran Aktif:</span>
              <span>{settings.activeAcademicYear} — Semester {settings.activeSemester}</span>
            </div>
          </div>

          {/* Col 4: Official Contact */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-2 border-blue-500 pl-2.5">
              Kontak Resmi
            </h4>
            <ul className="space-y-3 text-xs text-slate-300">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <span>{settings.address}, {settings.subdistrict}, {settings.city}, {settings.province} {settings.postalCode}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <span>{settings.phone} / WA: {settings.whatsapp}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <span>{settings.email}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <span>Senin - Jumat: 07.15 - 16.00 WIB</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>
            © {new Date().getFullYear()} SMK Komputer Al-Bashry Palabuhanratu. Seluruh hak cipta dilindungi.
          </p>
          <div className="flex items-center gap-4">
            <button onClick={() => navigateToPublic('profil')} className="hover:text-slate-300 transition">
              Kebijakan Privasi
            </button>
            <span>•</span>
            <button onClick={() => navigateToPublic('kontak')} className="hover:text-slate-300 transition">
              Bantuan & Dukungan
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
