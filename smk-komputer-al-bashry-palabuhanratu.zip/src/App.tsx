import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { RoleSwitcherBanner } from './components/RoleSwitcherBanner';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';

// Public Pages
import { HomePage } from './pages/public/HomePage';
import { ProfilePage } from './pages/public/ProfilePage';
import { TkjPage } from './pages/public/TkjPage';
import { AcademicPublicPage } from './pages/public/AcademicPublicPage';
import { TeachersPublicPage } from './pages/public/TeachersPublicPage';
import { NewsPage } from './pages/public/NewsPage';
import { NewsDetailPage } from './pages/public/NewsDetailPage';
import { GalleryPage } from './pages/public/GalleryPage';
import { PpdbPage } from './pages/public/PpdbPage';
import { ContactPage } from './pages/public/ContactPage';

// SIAKAD Internal Pages
import { SiakadLayout } from './pages/siakad/SiakadLayout';
import { DashboardOverview } from './pages/siakad/DashboardOverview';
import { StudentsManagement } from './pages/siakad/StudentsManagement';
import { TeachersManagement } from './pages/siakad/TeachersManagement';
import { ClassesManagement } from './pages/siakad/ClassesManagement';
import { SubjectsManagement } from './pages/siakad/SubjectsManagement';
import { SchedulesManagement } from './pages/siakad/SchedulesManagement';
import { AttendanceModule } from './pages/siakad/AttendanceModule';
import { GradesModule } from './pages/siakad/GradesModule';
import { ReportCardModule } from './pages/siakad/ReportCardModule';
import { TeachingJournalModule } from './pages/siakad/TeachingJournalModule';
import { PpdbAdminModule } from './pages/siakad/PpdbAdminModule';
import { AcademicReportsModule } from './pages/siakad/AcademicReportsModule';
import { SystemSettingsModule } from './pages/siakad/SystemSettingsModule';

const MainAppContent: React.FC = () => {
  const { isSiakadMode, publicPage, activeSiakadModule } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      {/* Demo Switcher for fast RBAC role inspection */}
      <RoleSwitcherBanner />

      {isSiakadMode ? (
        /* SIAKAD Application (Protected Academic System) */
        <SiakadLayout>
          {activeSiakadModule === 'dashboard' && <DashboardOverview />}
          {activeSiakadModule === 'siswa' && <StudentsManagement />}
          {activeSiakadModule === 'guru-admin' && <TeachersManagement />}
          {activeSiakadModule === 'kelas' && <ClassesManagement />}
          {activeSiakadModule === 'mapel' && <SubjectsManagement />}
          {activeSiakadModule === 'jadwal' && <SchedulesManagement />}
          {activeSiakadModule === 'presensi' && <AttendanceModule />}
          {activeSiakadModule === 'nilai' && <GradesModule />}
          {activeSiakadModule === 'rapor' && <ReportCardModule />}
          {activeSiakadModule === 'jurnal' && <TeachingJournalModule />}
          {activeSiakadModule === 'ppdb-admin' && <PpdbAdminModule />}
          {activeSiakadModule === 'laporan' && <AcademicReportsModule />}
          {activeSiakadModule === 'pengaturan' && <SystemSettingsModule />}
        </SiakadLayout>
      ) : (
        /* Public School Website */
        <div className="flex-1 flex flex-col justify-between">
          <Navbar />
          <main className="flex-1">
            {publicPage === 'home' && <HomePage />}
            {publicPage === 'profil' && <ProfilePage />}
            {publicPage === 'tkj' && <TkjPage />}
            {publicPage === 'akademik' && <AcademicPublicPage />}
            {publicPage === 'guru' && <TeachersPublicPage />}
            {publicPage === 'berita' && <NewsPage />}
            {publicPage === 'berita-detail' && <NewsDetailPage />}
            {publicPage === 'galeri' && <GalleryPage />}
            {publicPage === 'ppdb' && <PpdbPage />}
            {publicPage === 'kontak' && <ContactPage />}
          </main>
          <Footer />
        </div>
      )}

      {/* Global Auth Modal */}
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
