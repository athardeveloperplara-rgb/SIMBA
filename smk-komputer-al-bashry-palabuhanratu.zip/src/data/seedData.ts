import { 
  Student, 
  Teacher, 
  SchoolClass, 
  Subject, 
  ScheduleItem, 
  AttendanceRecord, 
  GradeItem, 
  TeachingJournal, 
  PPDBApplication, 
  SchoolNews, 
  GalleryItem, 
  SchoolSettings, 
  UserProfile, 
  ReportCard,
  AuditLog
} from '../types';

export const initialSchoolSettings: SchoolSettings = {
  schoolName: 'SMK Komputer Al-Bashry Palabuhanratu',
  npsn: '69984123',
  accreditation: 'B (Unggul)',
  address: 'Jl. Pelita No. 45, Kelurahan Palabuhanratu',
  subdistrict: 'Kecamatan Palabuhanratu',
  city: 'Kabupaten Sukabumi',
  province: 'Jawa Barat',
  postalCode: '43364',
  phone: '(0266) 432190',
  whatsapp: '0812-8899-7711',
  email: 'info@smkalbashry.sch.id',
  website: 'https://smkalbashry.sch.id',
  headmasterName: 'H. Ahmad Bashry, S.Kom., M.T.',
  headmasterNip: '19780512 200312 1 004',
  activeAcademicYear: '2026/2027',
  activeSemester: 'Ganjil',
  gradeWeightTugas: 30,
  gradeWeightPraktik: 30,
  gradeWeightUts: 20,
  gradeWeightUas: 20,
  ppdbActive: true,
  ppdbYear: '2026/2027',
  ppdbQuota: 108
};

export const initialTeachers: Teacher[] = [
  {
    id: 't-1',
    nip: '19780512 200312 1 004',
    fullName: 'H. Ahmad Bashry, S.Kom., M.T.',
    gender: 'L',
    phone: '0812-1122-3344',
    email: 'ahmad.bashry@smkalbashry.sch.id',
    education: 'S2 Magister Teknik Elektro & Komputer (ITB)',
    subjectsTaught: ['Kepala Sekolah & Pembina TKJ'],
    isHomeroom: false,
    status: 'aktif',
    roleTitle: 'Kepala Sekolah',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-2',
    nip: '19850315 200902 1 008',
    fullName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    gender: 'L',
    phone: '0813-8822-9901',
    email: 'irvan.tkj@smkalbashry.sch.id',
    education: 'S2 Ilmu Komputer (Universitas Indonesia)',
    subjectsTaught: ['Administrasi Infrastruktur Jaringan (AIJ)', 'Keamanan Jaringan'],
    isHomeroom: false,
    status: 'aktif',
    roleTitle: 'Ketua Program Keahlian TKJ',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-3',
    nip: '19900820 201403 2 005',
    fullName: 'Siti Rahmawati, S.Kom.',
    gender: 'P',
    phone: '0857-2233-4455',
    email: 'siti.rahma@smkalbashry.sch.id',
    education: 'S1 Sistem Informasi (UPI Bandung)',
    subjectsTaught: ['Komputer dan Jaringan Dasar (KJD)', 'Simulasi Digital'],
    isHomeroom: true,
    homeroomClassId: 'c-1',
    status: 'aktif',
    roleTitle: 'Wali Kelas X TKJ 1 & Guru Produktif',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-4',
    nip: '19871104 201101 1 003',
    fullName: 'Dedi Mulyadi, S.T.',
    gender: 'L',
    phone: '0878-9900-1122',
    email: 'dedi.mulyadi@smkalbashry.sch.id',
    education: 'S1 Teknik Informatika (Telkom University)',
    subjectsTaught: ['Administrasi Sistem Jaringan (ASJ)', 'Fiber Optik'],
    isHomeroom: true,
    homeroomClassId: 'c-3',
    status: 'aktif',
    roleTitle: 'Wali Kelas XI TKJ 1 & Guru Produktif',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-5',
    nip: '19920418 201708 2 002',
    fullName: 'Fitri Handayani, S.Kom.',
    gender: 'P',
    phone: '0819-3344-5566',
    email: 'fitri.handayani@smkalbashry.sch.id',
    education: 'S1 Teknik Komputer (UNIKOM)',
    subjectsTaught: ['Teknologi Layanan Jaringan (TLJ)', 'Produk Kreatif & Kewirausahaan (PKK)'],
    isHomeroom: true,
    homeroomClassId: 'c-5',
    status: 'aktif',
    roleTitle: 'Wali Kelas XII TKJ 1 & Guru Produktif',
    photoUrl: 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-6',
    nip: '19820710 200604 1 006',
    fullName: 'Asep Hidayat, S.Pd.I.',
    gender: 'L',
    phone: '0812-7788-9900',
    email: 'asep.hidayat@smkalbashry.sch.id',
    education: 'S1 Pendidikan Agama Islam (UIN SGD)',
    subjectsTaught: ['Pendidikan Agama Islam dan Budi Pekerti'],
    isHomeroom: false,
    status: 'aktif',
    roleTitle: 'Guru PAI & Pembina Rohis',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 't-7',
    nip: '19910905 201602 2 007',
    fullName: 'Nurul Aini, S.Pd.',
    gender: 'P',
    phone: '0856-1122-8899',
    email: 'nurul.aini@smkalbashry.sch.id',
    education: 'S1 Pendidikan Bahasa dan Sastra Indonesia',
    subjectsTaught: ['Bahasa Indonesia'],
    isHomeroom: false,
    status: 'aktif',
    roleTitle: 'Guru Bahasa Indonesia',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80'
  }
];

export const initialClasses: SchoolClass[] = [
  {
    id: 'c-1',
    name: 'X TKJ 1',
    gradeLevel: 'X',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-3',
    homeroomTeacherName: 'Siti Rahmawati, S.Kom.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Ruang Teori 1 / Lab TKJ 1'
  },
  {
    id: 'c-2',
    name: 'X TKJ 2',
    gradeLevel: 'X',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-2',
    homeroomTeacherName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Ruang Teori 2 / Lab TKJ 1'
  },
  {
    id: 'c-3',
    name: 'XI TKJ 1',
    gradeLevel: 'XI',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-4',
    homeroomTeacherName: 'Dedi Mulyadi, S.T.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Lab Jaringan & Fiber Optik'
  },
  {
    id: 'c-4',
    name: 'XI TKJ 2',
    gradeLevel: 'XI',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-6',
    homeroomTeacherName: 'Asep Hidayat, S.Pd.I.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Ruang Teori 3'
  },
  {
    id: 'c-5',
    name: 'XII TKJ 1',
    gradeLevel: 'XII',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-5',
    homeroomTeacherName: 'Fitri Handayani, S.Kom.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Lab Server & Cloud Computing'
  },
  {
    id: 'c-6',
    name: 'XII TKJ 2',
    gradeLevel: 'XII',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: 't-2',
    homeroomTeacherName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    academicYear: '2026/2027',
    capacity: 36,
    room: 'Lab Troubleshooting Jaringan'
  }
];

export const initialSubjects: Subject[] = [
  {
    id: 's-1',
    code: 'KJD-10',
    name: 'Komputer dan Jaringan Dasar (KJD)',
    group: 'Muatan Peminatan Kejuruan (TKJ)',
    totalHours: 5,
    teacherId: 't-3',
    teacherName: 'Siti Rahmawati, S.Kom.',
    targetGrades: ['X'],
    description: 'Perakitan PC, instalasi sistem operasi Linux/Windows, pengkabelan UTP/STP, LAN, pengalamatan IPv4/IPv6.'
  },
  {
    id: 's-2',
    code: 'AIJ-11',
    name: 'Administrasi Infrastruktur Jaringan (AIJ)',
    group: 'Muatan Peminatan Kejuruan (TKJ)',
    totalHours: 6,
    teacherId: 't-2',
    teacherName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    targetGrades: ['XI', 'XII'],
    description: 'VLAN, Trunking, Spanning Tree, Routing Statis & Dinamis (OSPF, BGP), Firewall NAT, Mikrotik RouterOS & Cisco IOS.'
  },
  {
    id: 's-3',
    code: 'ASJ-11',
    name: 'Administrasi Sistem Jaringan (ASJ)',
    group: 'Muatan Peminatan Kejuruan (TKJ)',
    totalHours: 6,
    teacherId: 't-4',
    teacherName: 'Dedi Mulyadi, S.T.',
    targetGrades: ['XI', 'XII'],
    description: 'Instalasi server Linux Debian, DHCP Server, DNS, Web Server Apache/Nginx, FTP, Mail Server, Samba, dan Virtualisasi Proxmox/VMware.'
  },
  {
    id: 's-4',
    code: 'TLJ-12',
    name: 'Teknologi Layanan Jaringan (TLJ)',
    group: 'Muatan Peminatan Kejuruan (TKJ)',
    totalHours: 6,
    teacherId: 't-5',
    teacherName: 'Fitri Handayani, S.Kom.',
    targetGrades: ['XII'],
    description: 'Komunikasi data, jaringan telepon kabel/nirkabel, VoIP (Voice over IP) Asterisk/Elastix, QoS dan Bandwidth Management.'
  },
  {
    id: 's-5',
    code: 'PAI-01',
    name: 'Pendidikan Agama Islam dan Budi Pekerti',
    group: 'Muatan Nasional',
    totalHours: 3,
    teacherId: 't-6',
    teacherName: 'Asep Hidayat, S.Pd.I.',
    targetGrades: ['X', 'XI', 'XII'],
    description: 'Pembentukan akhlakul karimah, ketakwaan, kejujuran, dan integritas profesional.'
  },
  {
    id: 's-6',
    code: 'BIN-01',
    name: 'Bahasa Indonesia & Literasi Teknis',
    group: 'Muatan Nasional',
    totalHours: 4,
    teacherId: 't-7',
    teacherName: 'Nurul Aini, S.Pd.',
    targetGrades: ['X', 'XI', 'XII'],
    description: 'Kemampuan komunikasi lisan dan tulisan, penyusunan laporan teknis, dan dokumentasi jaringan.'
  },
  {
    id: 's-7',
    code: 'PKK-12',
    name: 'Produk Kreatif dan Kewirausahaan (PKK)',
    group: 'Muatan Peminatan Kejuruan (TKJ)',
    totalHours: 5,
    teacherId: 't-5',
    teacherName: 'Fitri Handayani, S.Kom.',
    targetGrades: ['XI', 'XII'],
    description: 'Jasa servis komputer, instalasi RT/RW Net, desain topologi jaringan, wirausaha bidang IT.'
  }
];

export const initialStudents: Student[] = [
  {
    id: 'std-1',
    nis: '2601001',
    nisn: '0087654321',
    fullName: 'Muhammad Rizki Pratama',
    gender: 'L',
    birthPlace: 'Sukabumi',
    birthDate: '2010-04-12',
    address: 'Jl. Citarik No. 18, Palabuhanratu',
    phone: '0812-3456-7890',
    email: 'rizki.pratama@student.smkalbashry.sch.id',
    parentName: 'Bambang Pratama',
    parentPhone: '0812-7766-5544',
    parentJob: 'Wiraswasta',
    classId: 'c-1',
    className: 'X TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2026',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'std-2',
    nis: '2601002',
    nisn: '0087654322',
    fullName: 'Anisa Maulida Zahra',
    gender: 'P',
    birthPlace: 'Palabuhanratu',
    birthDate: '2010-06-25',
    address: 'Kp. Citepus Hilir RT 02/05, Palabuhanratu',
    phone: '0857-1234-5678',
    email: 'anisa.zahra@student.smkalbashry.sch.id',
    parentName: 'H. Suryana',
    parentPhone: '0857-9988-7766',
    parentJob: 'Pegawai Negeri',
    classId: 'c-1',
    className: 'X TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2026',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'std-3',
    nis: '2601003',
    nisn: '0087654323',
    fullName: 'Fajar Nugraha',
    gender: 'L',
    birthPlace: 'Palabuhanratu',
    birthDate: '2010-02-14',
    address: 'Jl. Kidang Kencana No. 89, Palabuhanratu',
    phone: '0878-1122-3344',
    email: 'fajar.nugraha@student.smkalbashry.sch.id',
    parentName: 'Cecep Nugraha',
    parentPhone: '0878-2233-4455',
    parentJob: 'Nelayan / Pengusaha Ikan',
    classId: 'c-1',
    className: 'X TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2026'
  },
  {
    id: 'std-4',
    nis: '2501015',
    nisn: '0076543210',
    fullName: 'Dimas Aditya Saputra',
    gender: 'L',
    birthPlace: 'Cikembar, Sukabumi',
    birthDate: '2009-08-19',
    address: 'Jl. Raya Palabuhanratu KM 12',
    phone: '0896-5544-3322',
    email: 'dimas.aditya@student.smkalbashry.sch.id',
    parentName: 'Agus Saputra',
    parentPhone: '0896-1122-3344',
    parentJob: 'Karyawan Swasta',
    classId: 'c-3',
    className: 'XI TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2025'
  },
  {
    id: 'std-5',
    nis: '2501016',
    nisn: '0076543211',
    fullName: 'Nabila Putri Cahyani',
    gender: 'P',
    birthPlace: 'Palabuhanratu',
    birthDate: '2009-11-03',
    address: 'Jl. Siliwangi No. 102, Palabuhanratu',
    phone: '0813-9988-7711',
    email: 'nabila.putri@student.smkalbashry.sch.id',
    parentName: 'Rahmat Cahyana',
    parentPhone: '0813-4455-6677',
    parentJob: 'Wiraswasta',
    classId: 'c-3',
    className: 'XI TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2025'
  },
  {
    id: 'std-6',
    nis: '2401030',
    nisn: '0065432109',
    fullName: 'Bagas Wahyu Ramadhan',
    gender: 'L',
    birthPlace: 'Sukabumi',
    birthDate: '2008-09-15',
    address: 'Kp. Buniwangi RT 01/03, Palabuhanratu',
    phone: '0858-6677-8899',
    email: 'bagas.wahyu@student.smkalbashry.sch.id',
    parentName: 'Wahyu Hidayat',
    parentPhone: '0858-1122-3344',
    parentJob: 'Petani Modern',
    classId: 'c-5',
    className: 'XII TKJ 1',
    academicYear: '2026/2027',
    status: 'aktif',
    entryYear: '2024'
  }
];

export const initialSchedules: ScheduleItem[] = [
  {
    id: 'sch-1',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    teacherId: 't-3',
    teacherName: 'Siti Rahmawati, S.Kom.',
    day: 'Senin',
    startTime: '07:30',
    endTime: '10:00',
    room: 'Lab Jaringan 1'
  },
  {
    id: 'sch-2',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-5',
    subjectName: 'Pendidikan Agama Islam dan Budi Pekerti',
    teacherId: 't-6',
    teacherName: 'Asep Hidayat, S.Pd.I.',
    day: 'Senin',
    startTime: '10:15',
    endTime: '12:00',
    room: 'Ruang Teori 1'
  },
  {
    id: 'sch-3',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-6',
    subjectName: 'Bahasa Indonesia & Literasi Teknis',
    teacherId: 't-7',
    teacherName: 'Nurul Aini, S.Pd.',
    day: 'Selasa',
    startTime: '08:00',
    endTime: '10:30',
    room: 'Ruang Teori 1'
  },
  {
    id: 'sch-4',
    classId: 'c-3',
    className: 'XI TKJ 1',
    subjectId: 's-2',
    subjectName: 'Administrasi Infrastruktur Jaringan (AIJ)',
    teacherId: 't-2',
    teacherName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    day: 'Rabu',
    startTime: '07:30',
    endTime: '11:30',
    room: 'Lab Cisco & Mikrotik'
  },
  {
    id: 'sch-5',
    classId: 'c-3',
    className: 'XI TKJ 1',
    subjectId: 's-3',
    subjectName: 'Administrasi Sistem Jaringan (ASJ)',
    teacherId: 't-4',
    teacherName: 'Dedi Mulyadi, S.T.',
    day: 'Kamis',
    startTime: '07:30',
    endTime: '11:30',
    room: 'Lab Server Linux'
  },
  {
    id: 'sch-6',
    classId: 'c-5',
    className: 'XII TKJ 1',
    subjectId: 's-4',
    subjectName: 'Teknologi Layanan Jaringan (TLJ)',
    teacherId: 't-5',
    teacherName: 'Fitri Handayani, S.Kom.',
    day: 'Jumat',
    startTime: '07:30',
    endTime: '11:00',
    room: 'Lab VoIP & Fiber Optik'
  }
];

export const initialAttendance: AttendanceRecord[] = [
  {
    id: 'att-1',
    date: '2026-10-14',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    studentId: 'std-1',
    studentName: 'Muhammad Rizki Pratama',
    status: 'Hadir',
    recordedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'att-2',
    date: '2026-10-14',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    studentId: 'std-2',
    studentName: 'Anisa Maulida Zahra',
    status: 'Hadir',
    recordedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'att-3',
    date: '2026-10-14',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    studentId: 'std-3',
    studentName: 'Fajar Nugraha',
    status: 'Sakit',
    note: 'Surat dokter terlampir di TU',
    recordedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'att-4',
    date: '2026-10-13',
    classId: 'c-3',
    className: 'XI TKJ 1',
    subjectId: 's-2',
    subjectName: 'Administrasi Infrastruktur Jaringan (AIJ)',
    studentId: 'std-4',
    studentName: 'Dimas Aditya Saputra',
    status: 'Hadir',
    recordedBy: 'Irvan Kurniawan, S.Pd., M.Kom.'
  },
  {
    id: 'att-5',
    date: '2026-10-13',
    classId: 'c-3',
    className: 'XI TKJ 1',
    subjectId: 's-2',
    subjectName: 'Administrasi Infrastruktur Jaringan (AIJ)',
    studentId: 'std-5',
    studentName: 'Nabila Putri Cahyani',
    status: 'Hadir',
    recordedBy: 'Irvan Kurniawan, S.Pd., M.Kom.'
  }
];

export const initialGrades: GradeItem[] = [
  {
    id: 'grd-1',
    studentId: 'std-1',
    studentName: 'Muhammad Rizki Pratama',
    classId: 'c-1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    tugas: 88,
    praktik: 92,
    uts: 85,
    uas: 90,
    finalScore: 89,
    predicate: 'A',
    teacherNotes: 'Sangat terampil dalam crimping kabel UTP straight/cross dan konfigurasi IP address.',
    lastUpdated: '2026-10-10',
    updatedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'grd-2',
    studentId: 'std-2',
    studentName: 'Anisa Maulida Zahra',
    classId: 'c-1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    tugas: 94,
    praktik: 90,
    uts: 92,
    uas: 91,
    finalScore: 92,
    predicate: 'A',
    teacherNotes: 'Pemahaman logika jaringan dan troubleshooting hardware sangat baik.',
    lastUpdated: '2026-10-10',
    updatedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'grd-3',
    studentId: 'std-3',
    studentName: 'Fajar Nugraha',
    classId: 'c-1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    tugas: 80,
    praktik: 82,
    uts: 78,
    uas: 80,
    finalScore: 80,
    predicate: 'B',
    teacherNotes: 'Perlu latihan lebih lanjut pada pengalamatan subnetting CIDR.',
    lastUpdated: '2026-10-10',
    updatedBy: 'Siti Rahmawati, S.Kom.'
  },
  {
    id: 'grd-4',
    studentId: 'std-4',
    studentName: 'Dimas Aditya Saputra',
    classId: 'c-3',
    subjectId: 's-2',
    subjectName: 'Administrasi Infrastruktur Jaringan (AIJ)',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    tugas: 86,
    praktik: 89,
    uts: 85,
    uas: 88,
    finalScore: 87,
    predicate: 'A',
    teacherNotes: 'Konfigurasi VLAN Trunking dan OSPF RouterOS tuntas dengan baik.',
    lastUpdated: '2026-10-11',
    updatedBy: 'Irvan Kurniawan, S.Pd., M.Kom.'
  }
];

export const initialJournals: TeachingJournal[] = [
  {
    id: 'jnl-1',
    date: '2026-10-14',
    teacherId: 't-3',
    teacherName: 'Siti Rahmawati, S.Kom.',
    classId: 'c-1',
    className: 'X TKJ 1',
    subjectId: 's-1',
    subjectName: 'Komputer dan Jaringan Dasar (KJD)',
    period: 'Jam ke 1 - 3 (07:30 - 10:00)',
    topic: 'Pengkabelan Kabel UTP Kategori 6 dan Standar T568A / T568B',
    competency: 'Menerapkan pengkabelan jaringan lokal dan pengujian LAN Tester',
    learningActivities: 'Penjelasan teori kabel twisted pair, demonstrasi kupas kabel dan crimping RJ-45, dilanjutkan praktik mandiri siswa 2 orang per kelompok.',
    presentCount: 35,
    absentCount: 1,
    obstacles: '1 buah tang crimping tumpul, telah ditandai untuk servis teknisi lab.',
    followUp: 'Siswa yang belum tuntas diberikan sesi pendampingan tambahan di jam praktikum berikutnya.'
  },
  {
    id: 'jnl-2',
    date: '2026-10-13',
    teacherId: 't-2',
    teacherName: 'Irvan Kurniawan, S.Pd., M.Kom.',
    classId: 'c-3',
    className: 'XI TKJ 1',
    subjectId: 's-2',
    subjectName: 'Administrasi Infrastruktur Jaringan (AIJ)',
    period: 'Jam ke 1 - 5 (07:30 - 11:30)',
    topic: 'Implementasi Static Routing Multi-Hop pada MikroTik RouterBOARD',
    competency: 'Mengkonfigurasi routing statis pada router Mikrotik dengan gateway cadangan (failover).',
    learningActivities: 'Simulasi topologi di WinBox dan EVE-NG, implementasi di perangkat keras RB941-2nD (hAP lite), pengujian ping dan traceroute.',
    presentCount: 36,
    absentCount: 0,
    obstacles: 'Tidak ada, seluruh router lab berfungsi optimal.',
    followUp: 'Pemberian tugas analisis troubleshooting routing loop.'
  }
];

export const initialPPDB: PPDBApplication[] = [
  {
    id: 'ppdb-1',
    registrationNumber: 'PPDB-2026-TKJ-001',
    registrationDate: '2026-10-01',
    fullName: 'Rayhan Faturahman',
    nisn: '0098123456',
    gender: 'L',
    birthPlace: 'Palabuhanratu',
    birthDate: '2011-03-10',
    address: 'Jl. Raya Cisolok KM 3, Palabuhanratu',
    previousSchool: 'SMP Negeri 1 Palabuhanratu',
    graduationYear: '2026',
    parentName: 'H. Sudrajat',
    parentPhone: '0812-9988-1122',
    email: 'rayhan.fatur@gmail.com',
    chosenMajor: 'Teknik Komputer dan Jaringan (TKJ)',
    status: 'Diterima',
    notes: 'Berkas lengkap dan lulus tes potensi akademik & wawancara minat IT.',
    documentsUploaded: {
      ijazahOrSkl: true,
      kartuKeluarga: true,
      aktaKelahiran: true,
      pasFoto: true,
      raporSmp: true
    }
  },
  {
    id: 'ppdb-2',
    registrationNumber: 'PPDB-2026-TKJ-002',
    registrationDate: '2026-10-05',
    fullName: 'Alya Syakira Maharani',
    nisn: '0098123457',
    gender: 'P',
    birthPlace: 'Sukabumi',
    birthDate: '2011-07-21',
    address: 'Kp. Badak Putih RT 04/02, Palabuhanratu',
    previousSchool: 'MTs Al-Bashry Palabuhanratu',
    graduationYear: '2026',
    parentName: 'Hendra Gunawan',
    parentPhone: '0857-4433-2211',
    email: 'alya.syakira@gmail.com',
    chosenMajor: 'Teknik Komputer dan Jaringan (TKJ)',
    status: 'Terverifikasi',
    notes: 'Jadwal tes wawancara minat kejuruan: Sabtu, 24 Oktober 2026.',
    documentsUploaded: {
      ijazahOrSkl: true,
      kartuKeluarga: true,
      aktaKelahiran: true,
      pasFoto: true,
      raporSmp: true
    }
  },
  {
    id: 'ppdb-3',
    registrationNumber: 'PPDB-2026-TKJ-003',
    registrationDate: '2026-10-10',
    fullName: 'Genta Arya Pratama',
    nisn: '0098123458',
    gender: 'L',
    birthPlace: 'Simpenan, Sukabumi',
    birthDate: '2011-01-05',
    address: 'Jl. Raya Bagbagan No. 22, Simpenan',
    previousSchool: 'SMP Negeri 2 Palabuhanratu',
    graduationYear: '2026',
    parentName: 'Deni Pratama',
    parentPhone: '0878-6655-4433',
    email: 'genta.arya@gmail.com',
    chosenMajor: 'Teknik Komputer dan Jaringan (TKJ)',
    status: 'Perlu Perbaikan',
    notes: 'Mohon unggah ulang Pas Foto formal dan scan Kartu Keluarga yang lebih jelas.',
    documentsUploaded: {
      ijazahOrSkl: true,
      kartuKeluarga: false,
      aktaKelahiran: true,
      pasFoto: false,
      raporSmp: true
    }
  },
  {
    id: 'ppdb-4',
    registrationNumber: 'PPDB-2026-TKJ-004',
    registrationDate: '2026-10-12',
    fullName: 'Zaskia Nur Azizah',
    nisn: '0098123459',
    gender: 'P',
    birthPlace: 'Palabuhanratu',
    birthDate: '2011-09-18',
    address: 'Jl. Gunung Butak RT 03/01, Palabuhanratu',
    previousSchool: 'SMP Islam Terpadu Palabuhanratu',
    graduationYear: '2026',
    parentName: 'Ahmad Fauzi',
    parentPhone: '0813-2211-0099',
    email: 'zaskia.azizah@gmail.com',
    chosenMajor: 'Teknik Komputer dan Jaringan (TKJ)',
    status: 'Menunggu Verifikasi',
    notes: 'Pendaftaran online berhasil diterima panitia pada 12 Oktober 2026.',
    documentsUploaded: {
      ijazahOrSkl: true,
      kartuKeluarga: true,
      aktaKelahiran: true,
      pasFoto: true,
      raporSmp: true
    }
  }
];

export const initialNews: SchoolNews[] = [
  {
    id: 'news-1',
    slug: 'siswa-smk-komputer-al-bashry-raih-sertifikasi-mikrotik-mtcna',
    title: 'Siswa SMK Komputer Al-Bashry Raih Sertifikasi Internasional MikroTik (MTCNA)',
    category: 'Prestasi',
    summary: 'Sebanyak 24 siswa kompetensi keahlian TKJ berhasil lulus ujian sertifikasi resmi internasional MikroTik Certified Network Associate dengan nilai membanggakan.',
    content: `
      Palabuhanratu — SMK Komputer Al-Bashry Palabuhanratu kembali menorehkan prestasi membanggakan di bidang teknologi informasi. Sebanyak 24 siswa tingkat akhir Teknik Komputer dan Jaringan (TKJ) berhasil lulus sertifikasi kompetensi jaringan tingkat internasional yaitu MikroTik Certified Network Associate (MTCNA).

      Ujian sertifikasi ini diselenggarakan melalui kerja sama MikroTik Academy di SMK Komputer Al-Bashry dengan pengawasan langsung dari MikroTik Certified Trainer. Materi yang diujikan mencakup routing statis dan dinamis, firewall filter & NAT, manajemen bandwidth (Simple Queue & Queue Tree), wireless networking, serta tunnel dan VPN.

      Kepala SMK Komputer Al-Bashry, H. Ahmad Bashry, S.Kom., M.T., mengungkapkan rasa syukurnya atas capaian ini: "Sertifikasi MTCNA ini menjadi bukti otentik bahwa kompetensi lulusan kami selaras dengan standar industri telekomunikasi dan jaringan global. Lulusan TKJ Al-Bashry siap bersaing di pasar kerja maupun berwirausaha di bidang teknologi jaringan."
    `,
    imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80',
    author: 'Humas SMK Al-Bashry',
    publishedAt: '2026-10-10',
    isImportant: true
  },
  {
    id: 'news-2',
    slug: 'pembukaan-ppdb-smk-komputer-al-bashry-2026-2027',
    title: 'Penerimaan Peserta Didik Baru (PPDB) 2026/2027 Resmi Dibuka Secara Online',
    category: 'Pengumuman',
    summary: 'Pendaftaran gelombang pertama dibuka untuk calon siswa yang bertekad menjadi teknisi jaringan andal, administrator server, dan profesional keamanan siber.',
    content: `
      SMK Komputer Al-Bashry Palabuhanratu membuka Penerimaan Peserta Didik Baru (PPDB) Tahun Pelajaran 2026/2027 untuk Program Keahlian Teknik Komputer dan Jaringan (TKJ).

      Pendaftaran dapat dilakukan secara online melalui portal resmi ini atau langsung hadir di Sekretariat PPDB SMK Komputer Al-Bashry, Jl. Pelita No. 45 Palabuhanratu. Kuota yang disediakan terbatas sebanyak 3 rombongan belajar (108 siswa) untuk menjamin kualitas praktik di laboratorium komputer dan jaringan.

      Fasilitas unggulan meliputi:
      - Laboratorium Cisco dan MikroTik RouterBOARD
      - Fasilitas Fiber Optik lengkap dengan Fusion Splicer dan OTDR
      - Lab Perakitan Komputer & Maintenance Hardware
      - Akses Internet Kecepatan Tinggi Dedicated
      - Bimbingan Sertifikasi Kompetensi BNSP dan MTCNA
    `,
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80',
    author: 'Panitia PPDB',
    publishedAt: '2026-10-01',
    isImportant: true
  },
  {
    id: 'news-3',
    slug: 'pelaksanaan-program-pkl-industri-isp-sukabumi',
    title: 'Pelepasan Siswa Praktik Kerja Lapangan (PKL) ke Industri ISP dan Kominfo',
    category: 'TKJ & Industri',
    summary: 'Puluhan siswa kelas XI dilepas untuk mengikuti PKL selama 6 bulan di berbagai Internet Service Provider (ISP), instansi pemerintah, dan perusahaan mitra IT.',
    content: `
      Sebanyak 72 siswa kelas XI Program Keahlian TKJ secara resmi dilepas untuk melaksanakan Praktik Kerja Lapangan (PKL) semester ini. Penempatan siswa tersebar di sejumlah mitra industri terkemuka seperti Telkom Indonesia, PT Palabuhanratu Digital Network, Dinas Kominfo Kabupaten Sukabumi, serta penyedia jasa RT/RW Net dan IT Support.

      Program PKL ini dirancang untuk membekali siswa dengan etos kerja profesional, pemecahan masalah jaringan di lapangan secara nyata, penanganan kabel fiber optik outdoor, serta interaksi langsung dengan klien layanan teknologi.
    `,
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80',
    author: 'Pokja Humas & DUDI',
    publishedAt: '2026-09-28'
  },
  {
    id: 'news-4',
    slug: 'workshop-cybersecurity-dan-ethical-hacking-pelajar',
    title: 'Workshop Cyber Security: Mengenal Etika Keamanan Siber untuk Remaja',
    category: 'Kegiatan',
    summary: 'SMK Komputer Al-Bashry menyelenggarakan lokakarya keamanan siber bersama praktisi IT Sukabumi mengenai pertahanan data dan konfigurasi firewall modern.',
    content: `
      Di era digital yang serba terkoneksi, pemahaman tentang keamanan data menjadi hal krusial. SMK Komputer Al-Bashry mengadakan Workshop Keamanan Siber yang diikuti oleh siswa dan perwakilan pelajar SMP se-Palabuhanratu.

      Materi meliputi konsep dasar kriptografi, pencegahan serangan Denial of Service (DoS), konfigurasi Port Knocking di router, dan pengamanan kredensial nirkabel Wi-Fi WPA3.
    `,
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
    author: 'Lab TKJ Al-Bashry',
    publishedAt: '2026-09-15'
  }
];

export const initialGallery: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Praktik Penyambungan Kabel Fiber Optik Menggunakan Fusion Splicer',
    category: 'Praktik TKJ',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    date: '2026-10-08',
    description: 'Siswa kelas XI menguji redaman koneksi fiber optik setelah penyambungan presisi di laboratorium jaringan.'
  },
  {
    id: 'gal-2',
    title: 'Laboratorium Perakitan Komputer dan Hardware Maintenance',
    category: 'Laboratorium',
    imageUrl: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=800&q=80',
    date: '2026-09-24',
    description: 'Fasilitas 36 unit workstation dengan spesifikasi modern untuk kegiatan perakitan PC dan instalasi sistem operasi.'
  },
  {
    id: 'gal-3',
    title: 'Konfigurasi Jaringan Routing & VLAN pada Rak Server MikroTik',
    category: 'Praktik TKJ',
    imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80',
    date: '2026-09-18',
    description: 'Siswa kelas XII melakukan simulasi jaringan multi-subnet untuk skenario kantor berlantai tiga.'
  },
  {
    id: 'gal-4',
    title: 'Kunjungan Industri ke Data Center & Internet Exchange Point',
    category: 'Kunjungan Industri',
    imageUrl: 'https://images.unsplash.com/photo-1520869562399-e772f242f22d?auto=format&fit=crop&w=800&q=80',
    date: '2026-08-30',
    description: 'Edukasi lapangan siswa mengenai arsitektur server blade, sistem pendingin presisi, dan pasokan daya UPS industri.'
  },
  {
    id: 'gal-5',
    title: 'Upacara Peringatan Hari Pendidikan dan Penyerahan Piagam Siswa Teladan',
    category: 'Kegiatan Sekolah',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
    date: '2026-08-17',
    description: 'Penyerahan medali penghargaan bagi siswa berprestasi di lomba LKS bidang Network System Administration.'
  },
  {
    id: 'gal-6',
    title: 'Ekstrakurikuler Robotika dan Internet of Things (IoT)',
    category: 'Ekstrakurikuler',
    imageUrl: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80',
    date: '2026-09-12',
    description: 'Eksplorasi mikrokontroler ESP32 terhubung dengan sensor cuaca dan sistem monitoring jarak jauh berbasis web.'
  }
];

export const initialAuditLogs: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: '2026-10-14 08:30:15',
    userName: 'Siti Rahmawati, S.Kom.',
    userRole: 'Wali Kelas / Guru',
    action: 'INPUT_PRESENSI',
    module: 'Presensi',
    details: 'Input presensi harian kelas X TKJ 1 mapel Komputer dan Jaringan Dasar.'
  },
  {
    id: 'log-2',
    timestamp: '2026-10-12 14:15:00',
    userName: 'Panitia PPDB',
    userRole: 'Petugas PPDB',
    action: 'VERIFIKASI_BERKAS',
    module: 'PPDB',
    details: 'Verifikasi berkas pendaftar PPDB-2026-TKJ-001 (Rayhan Faturahman) -> Status: Diterima.'
  },
  {
    id: 'log-3',
    timestamp: '2026-10-10 11:45:22',
    userName: 'Administrator',
    userRole: 'Super Admin',
    action: 'UPDATE_SETTINGS',
    module: 'Pengaturan Sistem',
    details: 'Pembaruan kuota PPDB 2026/2027 menjadi 108 siswa.'
  }
];

export const demoAccounts: {
  role: string;
  name: string;
  username: string;
  email: string;
  desc: string;
  studentId?: string;
  teacherId?: string;
}[] = [
  {
    role: 'super_admin',
    name: 'Administrator Utama (IT)',
    username: 'admin',
    email: 'admin@smkalbashry.sch.id',
    desc: 'Akses penuh ke semua konfigurasi sistem, data master, audit log, dan hak akses.'
  },
  {
    role: 'guru',
    name: 'Irvan Kurniawan, S.Pd., M.Kom.',
    username: 'guru',
    email: 'irvan.tkj@smkalbashry.sch.id',
    desc: 'Guru Produktif TKJ: kelola jadwal ajar, input presensi pertemuan, penilaian siswa, dan jurnal mengajar.',
    teacherId: 't-2'
  },
  {
    role: 'wali_kelas',
    name: 'Siti Rahmawati, S.Kom. (Wali X TKJ 1)',
    username: 'wali',
    email: 'siti.rahma@smkalbashry.sch.id',
    desc: 'Wali Kelas X TKJ 1: pantau kehadiran siswa binaan, kelola catatan wali kelas, dan pratinjau rapor digital.',
    teacherId: 't-3'
  },
  {
    role: 'siswa',
    name: 'Muhammad Rizki Pratama (Siswa X TKJ 1)',
    username: 'siswa',
    email: 'rizki.pratama@student.smkalbashry.sch.id',
    desc: 'Siswa: pantau jadwal kelas harian, rekap kehadiran pribadi, transkrip nilai, dan cetak rapor digital.',
    studentId: 'std-1'
  },
  {
    role: 'orang_tua',
    name: 'Bambang Pratama (Wali dari M. Rizki)',
    username: 'ortu',
    email: 'bambang.pratama@gmail.com',
    desc: 'Orang Tua / Wali: memantau presensi harian anak, grafik nilai capaian, dan pengumuman sekolah.',
    studentId: 'std-1'
  },
  {
    role: 'petugas_ppdb',
    name: 'Petugas Verifikasi PPDB',
    username: 'ppdb',
    email: 'panitia.ppdb@smkalbashry.sch.id',
    desc: 'Petugas PPDB: verifikasi kelengkapan berkas calon siswa, perbarui status kelulusan, dan unduh rekap.'
  }
];
