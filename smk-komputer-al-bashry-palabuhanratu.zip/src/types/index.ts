export type UserRole = 
  | 'super_admin'
  | 'admin_sekolah'
  | 'operator'
  | 'guru'
  | 'wali_kelas'
  | 'siswa'
  | 'orang_tua'
  | 'petugas_ppdb';

export interface UserProfile {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  phone?: string;
  studentId?: string; // If role is siswa or orang_tua
  teacherId?: string; // If role is guru or wali_kelas
}

export interface Student {
  id: string;
  nis: string;
  nisn: string;
  fullName: string;
  gender: 'L' | 'P';
  birthPlace: string;
  birthDate: string;
  address: string;
  phone: string;
  email: string;
  parentName: string;
  parentPhone: string;
  parentJob?: string;
  classId: string;
  className: string;
  academicYear: string;
  status: 'aktif' | 'lulus' | 'pindah' | 'nonaktif';
  entryYear: string;
  photoUrl?: string;
}

export interface Teacher {
  id: string;
  nip: string;
  fullName: string;
  gender: 'L' | 'P';
  phone: string;
  email: string;
  education: string;
  subjectsTaught: string[];
  isHomeroom: boolean;
  homeroomClassId?: string;
  status: 'aktif' | 'nonaktif';
  roleTitle: string; // e.g. "Ketua Program Keahlian TKJ", "Guru Produktif TKJ", "Kepala Sekolah"
  photoUrl?: string;
}

export interface SchoolClass {
  id: string;
  name: string; // e.g. "X TKJ 1", "XI TKJ 2"
  gradeLevel: 'X' | 'XI' | 'XII';
  major: string; // "Teknik Komputer dan Jaringan"
  homeroomTeacherId: string;
  homeroomTeacherName: string;
  academicYear: string;
  capacity: number;
  room: string;
}

export interface Subject {
  id: string;
  code: string; // e.g. "TKJ-01", "PAI-01"
  name: string;
  group: 'Muatan Nasional' | 'Muatan Kewilayahan' | 'Muatan Peminatan Kejuruan (TKJ)' | 'Muatan Lokal';
  totalHours: number; // per week
  teacherId: string;
  teacherName: string;
  targetGrades: ('X' | 'XI' | 'XII')[];
  description?: string;
}

export interface ScheduleItem {
  id: string;
  classId: string;
  className: string;
  subjectId: string;
  subjectName: string;
  teacherId: string;
  teacherName: string;
  day: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu';
  startTime: string; // "07:30"
  endTime: string;   // "09:00"
  room: string;      // "Lab Jaringan 1", "Ruang Teori 2"
}

export type AttendanceStatus = 'Hadir' | 'Sakit' | 'Izin' | 'Alpa';

export interface AttendanceRecord {
  id: string;
  date: string; // YYYY-MM-DD
  classId: string;
  className: string;
  subjectId?: string;
  subjectName?: string;
  studentId: string;
  studentName: string;
  status: AttendanceStatus;
  note?: string;
  recordedBy: string;
}

export interface GradeItem {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  subjectId: string;
  subjectName: string;
  semester: 'Ganjil' | 'Genap';
  academicYear: string;
  tugas: number;      // Formatif / Tugas (30%)
  praktik: number;    // Praktik TKJ / Lab (30%)
  uts: number;        // Penilaian Tengah Semester (20%)
  uas: number;        // Penilaian Akhir Semester (20%)
  finalScore: number; // calculated
  predicate: 'A' | 'B' | 'C' | 'D';
  teacherNotes: string;
  lastUpdated: string;
  updatedBy: string;
}

export interface ReportCard {
  id: string;
  studentId: string;
  studentName: string;
  nis: string;
  nisn: string;
  classId: string;
  className: string;
  semester: 'Ganjil' | 'Genap';
  academicYear: string;
  isLocked: boolean;
  publishedAt?: string;
  homeroomNotes: string;
  attendanceSummary: {
    hadir: number;
    sakit: number;
    izin: number;
    alpa: number;
  };
  extracurriculars: {
    name: string;
    score: 'Sangat Baik' | 'Baik' | 'Cukup';
    notes: string;
  }[];
  grades: {
    subjectName: string;
    category: string;
    kkm: number;
    knowledgeScore: number;
    skillScore: number;
    finalScore: number;
    predicate: string;
    description: string;
  }[];
}

export interface TeachingJournal {
  id: string;
  date: string;
  teacherId: string;
  teacherName: string;
  classId: string;
  className: string;
  subjectId: string;
  subjectName: string;
  period: string; // e.g. "Jam ke 1 - 3"
  topic: string;
  competency: string;
  learningActivities: string;
  presentCount: number;
  absentCount: number;
  obstacles?: string;
  followUp?: string;
}

export interface PPDBApplication {
  id: string;
  registrationNumber: string; // e.g. "PPDB-2026-TKJ-001"
  registrationDate: string;
  fullName: string;
  nisn: string;
  gender: 'L' | 'P';
  birthPlace: string;
  birthDate: string;
  address: string;
  previousSchool: string;
  graduationYear: string;
  parentName: string;
  parentPhone: string;
  email?: string;
  chosenMajor: string; // "Teknik Komputer dan Jaringan (TKJ)"
  status: 'Menunggu Verifikasi' | 'Perlu Perbaikan' | 'Terverifikasi' | 'Diterima' | 'Tidak Diterima';
  notes?: string;
  documentsUploaded: {
    ijazahOrSkl: boolean;
    kartuKeluarga: boolean;
    aktaKelahiran: boolean;
    pasFoto: boolean;
    raporSmp: boolean;
  };
}

export interface SchoolNews {
  id: string;
  slug: string;
  title: string;
  category: 'Akademik' | 'Prestasi' | 'Kegiatan' | 'Pengumuman' | 'TKJ & Industri';
  summary: string;
  content: string;
  imageUrl: string;
  author: string;
  publishedAt: string;
  isImportant?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Praktik TKJ' | 'Laboratorium' | 'Kegiatan Sekolah' | 'Ekstrakurikuler' | 'Kunjungan Industri' | 'Prestasi Siswa';
  imageUrl: string;
  date: string;
  description: string;
}

export interface SchoolSettings {
  schoolName: string;
  npsn: string;
  accreditation: string;
  address: string;
  subdistrict: string;
  city: string;
  province: string;
  postalCode: string;
  phone: string;
  whatsapp: string;
  email: string;
  website: string;
  headmasterName: string;
  headmasterNip: string;
  activeAcademicYear: string;
  activeSemester: 'Ganjil' | 'Genap';
  gradeWeightTugas: number;
  gradeWeightPraktik: number;
  gradeWeightUts: number;
  gradeWeightUas: number;
  ppdbActive: boolean;
  ppdbYear: string;
  ppdbQuota: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  details: string;
}
