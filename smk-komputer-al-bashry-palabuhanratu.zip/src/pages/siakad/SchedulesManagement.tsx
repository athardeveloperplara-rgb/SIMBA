import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ScheduleItem } from '../../types';
import { 
  Clock, 
  Calendar, 
  Plus, 
  Printer, 
  Trash2, 
  Edit3, 
  X, 
  AlertTriangle, 
  CheckCircle2 
} from 'lucide-react';

export const SchedulesManagement: React.FC = () => {
  const { schedules, addSchedule, updateSchedule, deleteSchedule, classes, subjects, teachers } = useApp();

  const [selectedClass, setSelectedClass] = useState<string>(classes[0]?.id || 'c-1');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ScheduleItem | null>(null);

  const [formData, setFormData] = useState({
    classId: classes[0]?.id || 'c-1',
    subjectId: subjects[0]?.id || 's-1',
    teacherId: teachers[0]?.id || 't-1',
    day: 'Senin' as ScheduleItem['day'],
    startTime: '07:30',
    endTime: '09:00',
    room: 'Lab Jaringan 1'
  });

  const [conflictWarning, setConflictWarning] = useState<string | null>(null);

  const days: ScheduleItem['day'][] = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

  const filteredSchedules = schedules.filter(s => s.classId === selectedClass);
  const activeClassObj = classes.find(c => c.id === selectedClass);

  const checkConflict = (data: typeof formData, ignoreId?: string): string | null => {
    // Check teacher conflict at same day & overlapping time
    const teacherConflict = schedules.find(s => 
      s.id !== ignoreId &&
      s.teacherId === data.teacherId &&
      s.day === data.day &&
      !(data.endTime <= s.startTime || data.startTime >= s.endTime)
    );
    if (teacherConflict) {
      return `Bentrok Jadwal Guru: ${teacherConflict.teacherName} sudah terjadwal di kelas ${teacherConflict.className} (${teacherConflict.startTime} - ${teacherConflict.endTime}).`;
    }

    // Check room conflict at same day & time
    const roomConflict = schedules.find(s => 
      s.id !== ignoreId &&
      s.room.toLowerCase() === data.room.toLowerCase() &&
      s.day === data.day &&
      !(data.endTime <= s.startTime || data.startTime >= s.endTime)
    );
    if (roomConflict) {
      return `Bentrok Ruangan: ${data.room} sedang dipakai oleh ${roomConflict.className} (${roomConflict.startTime} - ${roomConflict.endTime}).`;
    }

    return null;
  };

  const handleOpenAdd = () => {
    setEditingSchedule(null);
    setConflictWarning(null);
    setFormData({
      classId: selectedClass,
      subjectId: subjects[0]?.id || 's-1',
      teacherId: teachers[0]?.id || 't-1',
      day: 'Senin',
      startTime: '07:30',
      endTime: '09:00',
      room: 'Lab Jaringan 1'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: ScheduleItem) => {
    setEditingSchedule(item);
    setConflictWarning(null);
    setFormData({
      classId: item.classId,
      subjectId: item.subjectId,
      teacherId: item.teacherId,
      day: item.day,
      startTime: item.startTime,
      endTime: item.endTime,
      room: item.room
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const conflict = checkConflict(formData, editingSchedule?.id);
    if (conflict) {
      setConflictWarning(conflict);
      return;
    }

    const cls = classes.find(c => c.id === formData.classId);
    const subj = subjects.find(s => s.id === formData.subjectId);
    const teacher = teachers.find(t => t.id === formData.teacherId);

    const payload = {
      ...formData,
      className: cls ? cls.name : 'X TKJ 1',
      subjectName: subj ? subj.name : 'Mapel TKJ',
      teacherName: teacher ? teacher.fullName : 'Guru TKJ'
    };

    if (editingSchedule) {
      updateSchedule(editingSchedule.id, payload);
    } else {
      addSchedule(payload);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4 no-print">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <span>Manajemen Jadwal Pelajaran & Praktikum</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Matriks alokasi waktu mata pelajaran, validasi bentrok guru dan ruang laboratorium komputer.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Jadwal</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Jadwal</span>
          </button>
        </div>
      </div>

      {/* Class Selector */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-700">Pilih Rombongan Belajar:</span>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {classes.map(c => (
              <button
                key={c.id}
                onClick={() => setSelectedClass(c.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                  selectedClass === c.id ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        <span className="text-xs text-slate-500 hidden md:inline">
          Ruang: <strong className="text-slate-800">{activeClassObj?.room}</strong>
        </span>
      </div>

      {/* Timetable by Day */}
      <div className="space-y-4">
        {days.map(day => {
          const dayItems = filteredSchedules.filter(s => s.day === day);
          return (
            <div key={day} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <span className="font-extrabold text-sm text-[#0B1F3A] font-heading flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>Hari {day}</span>
                </span>
                <span className="text-[11px] text-slate-400 font-semibold">
                  {dayItems.length} Sesi Belajar
                </span>
              </div>

              {dayItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {dayItems.map(item => (
                    <div key={item.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[11px] font-mono font-bold text-blue-700 bg-blue-100/80 px-2 py-0.5 rounded">
                            {item.startTime} - {item.endTime} WIB
                          </span>
                          <span className="text-[10px] text-slate-500 font-semibold">{item.room}</span>
                        </div>
                        <h4 className="font-bold text-xs text-slate-900 font-heading mb-1 line-clamp-1">
                          {item.subjectName}
                        </h4>
                        <p className="text-[11px] text-slate-600 line-clamp-1">
                          Pengampu: {item.teacherName.split(',')[0]}
                        </p>
                      </div>

                      <div className="flex items-center justify-end gap-1 pt-2 mt-2 border-t border-slate-200/60 no-print">
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1 text-slate-400 hover:text-amber-600 transition"
                          title="Edit Jadwal"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Hapus jadwal ${item.subjectName}?`)) {
                              deleteSchedule(item.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 transition"
                          title="Hapus Jadwal"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic py-1">Tidak ada jadwal terjadwal di hari {day}.</p>
              )}
            </div>
          );
        })}
      </div>

      {/* Modal Add / Edit Schedule */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                {editingSchedule ? 'Edit Jadwal Pelajaran' : 'Tambah Sesi Jadwal'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              {conflictWarning && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>{conflictWarning}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kelas / Rombel</label>
                  <select
                    value={formData.classId}
                    onChange={e => setFormData({ ...formData, classId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Hari</label>
                  <select
                    value={formData.day}
                    onChange={e => setFormData({ ...formData, day: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  >
                    {days.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mata Pelajaran</label>
                <select
                  value={formData.subjectId}
                  onChange={e => {
                    const subj = subjects.find(s => s.id === e.target.value);
                    setFormData({
                      ...formData,
                      subjectId: e.target.value,
                      teacherId: subj?.teacherId || formData.teacherId
                    });
                  }}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-medium"
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Guru Pengampu</label>
                <select
                  value={formData.teacherId}
                  onChange={e => setFormData({ ...formData, teacherId: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>{t.fullName}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jam Mulai</label>
                  <input
                    type="time"
                    value={formData.startTime}
                    onChange={e => setFormData({ ...formData, startTime: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jam Selesai</label>
                  <input
                    type="time"
                    value={formData.endTime}
                    onChange={e => setFormData({ ...formData, endTime: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ruangan / Lab</label>
                <input
                  type="text"
                  value={formData.room}
                  onChange={e => setFormData({ ...formData, room: e.target.value })}
                  placeholder="Contoh: Lab Jaringan 1, Lab Cisco & Mikrotik"
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
