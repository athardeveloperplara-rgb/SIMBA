import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PPDBApplication } from '../../types';
import { 
  UserCheck, 
  Search, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  FileText, 
  Printer, 
  Eye, 
  Check 
} from 'lucide-react';

export const PpdbAdminModule: React.FC = () => {
  const { ppdbList, updatePPDBStatus, settings } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('Semua');
  const [verifyingApp, setVerifyingApp] = useState<PPDBApplication | null>(null);

  const [newStatus, setNewStatus] = useState<PPDBApplication['status']>('Terverifikasi');
  const [newNotes, setNewNotes] = useState('');

  const filteredApps = ppdbList.filter(app => {
    const matchesSearch = app.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.previousSchool.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'Semua' || app.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const handleOpenVerify = (app: PPDBApplication) => {
    setVerifyingApp(app);
    setNewStatus(app.status);
    setNewNotes(app.notes || '');
  };

  const handleSaveVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyingApp) return;

    updatePPDBStatus(verifyingApp.id, newStatus, newNotes);
    setVerifyingApp(null);
  };

  const handleExportCSV = () => {
    const headers = ['No Registrasi', 'Tanggal', 'Nama Lengkap', 'NISN', 'JK', 'Asal Sekolah', 'No WA Ortu', 'Status', 'Catatan Verifikator'];
    const rows = filteredApps.map(a => [
      `"${a.registrationNumber}"`,
      a.registrationDate,
      `"${a.fullName}"`,
      `"${a.nisn}"`,
      a.gender,
      `"${a.previousSchool}"`,
      `"${a.parentPhone}"`,
      `"${a.status}"`,
      `"${(a.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Rekap_Pendaftar_PPDB_AlBashry_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            <span>Modul Verifikasi Berkas PPDB {settings.ppdbYear}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Pemeriksaan keabsahan dokumen pendaftar, penetapan status kelulusan, dan pencatatan instruksi perbaikan berkas.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Ekspor Rekap PPDB</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-[11px] text-slate-500">Total Pendaftar:</span>
          <div className="text-xl font-bold font-heading text-slate-900 mt-0.5">{ppdbList.length}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-[11px] text-amber-600">Menunggu Verifikasi:</span>
          <div className="text-xl font-bold font-heading text-amber-600 mt-0.5">
            {ppdbList.filter(p => p.status === 'Menunggu Verifikasi').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-[11px] text-blue-600">Terverifikasi:</span>
          <div className="text-xl font-bold font-heading text-blue-600 mt-0.5">
            {ppdbList.filter(p => p.status === 'Terverifikasi').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-[11px] text-emerald-600">Dinyatakan Diterima:</span>
          <div className="text-xl font-bold font-heading text-emerald-600 mt-0.5">
            {ppdbList.filter(p => p.status === 'Diterima').length}
          </div>
        </div>
      </div>

      {/* Search and Status filter */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Cari no. registrasi, nama calon, atau asal SMP..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">Status:</span>
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-blue-500"
          >
            <option value="Semua">Semua Status</option>
            <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
            <option value="Terverifikasi">Terverifikasi</option>
            <option value="Diterima">Diterima</option>
            <option value="Perlu Perbaikan">Perlu Perbaikan</option>
            <option value="Tidak Diterima">Tidak Diterima</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-3 px-3.5">No. Registrasi</th>
                <th className="py-3 px-3.5">Tanggal</th>
                <th className="py-3 px-3.5">Nama Calon Siswa</th>
                <th className="py-3 px-3.5">Asal SMP / MTs</th>
                <th className="py-3 px-3.5">WhatsApp Ortu</th>
                <th className="py-3 px-3.5 text-center">Status</th>
                <th className="py-3 px-3.5 text-center">Aksi Verifikasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredApps.map(app => (
                <tr key={app.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-3.5 font-mono font-bold text-blue-600">
                    {app.registrationNumber}
                  </td>
                  <td className="py-3 px-3.5 text-slate-400 font-mono">
                    {app.registrationDate}
                  </td>
                  <td className="py-3 px-3.5">
                    <span className="font-bold text-slate-900 block">{app.fullName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">NISN: {app.nisn}</span>
                  </td>
                  <td className="py-3 px-3.5 text-slate-700">
                    {app.previousSchool}
                  </td>
                  <td className="py-3 px-3.5 font-mono text-slate-600">
                    {app.parentPhone}
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      app.status === 'Diterima' ? 'bg-emerald-100 text-emerald-800' :
                      app.status === 'Terverifikasi' ? 'bg-blue-100 text-blue-800' :
                      app.status === 'Perlu Perbaikan' ? 'bg-amber-100 text-amber-800' :
                      app.status === 'Tidak Diterima' ? 'bg-rose-100 text-rose-800' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {app.status}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <button
                      onClick={() => handleOpenVerify(app)}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-3 py-1 rounded-lg text-[11px] shadow-xs transition"
                    >
                      Periksa & Ubah Status
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Verification Modal */}
      {verifyingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm font-heading">
                  Verifikasi Berkas PPDB — {verifyingApp.registrationNumber}
                </h3>
                <p className="text-xs text-sky-200">{verifyingApp.fullName}</p>
              </div>
              <button onClick={() => setVerifyingApp(null)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveVerification} className="p-6 space-y-4">
              
              {/* Document Checklist preview */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="text-xs font-bold text-slate-800 block">Status Dokumen Pendaftar:</span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1.5">
                    {verifyingApp.documentsUploaded.ijazahOrSkl ? <Check className="w-4 h-4 text-emerald-600" /> : <X className="w-4 h-4 text-rose-500" />}
                    <span>Ijazah / SKL SMP</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {verifyingApp.documentsUploaded.kartuKeluarga ? <Check className="w-4 h-4 text-emerald-600" /> : <X className="w-4 h-4 text-rose-500" />}
                    <span>Kartu Keluarga (KK)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {verifyingApp.documentsUploaded.aktaKelahiran ? <Check className="w-4 h-4 text-emerald-600" /> : <X className="w-4 h-4 text-rose-500" />}
                    <span>Akta Kelahiran</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {verifyingApp.documentsUploaded.pasFoto ? <Check className="w-4 h-4 text-emerald-600" /> : <X className="w-4 h-4 text-rose-500" />}
                    <span>Pas Foto 3x4</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ubah Status Verifikasi:
                </label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold text-blue-600"
                >
                  <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
                  <option value="Terverifikasi">Terverifikasi (Berkas Lengkap)</option>
                  <option value="Diterima">Diterima Sebagai Siswa Baru TKJ</option>
                  <option value="Perlu Perbaikan">Perlu Perbaikan (Unggah Ulang)</option>
                  <option value="Tidak Diterima">Tidak Diterima</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Catatan Panitia Verifikator:
                </label>
                <textarea
                  rows={3}
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  placeholder="Instruksi untuk pendaftar (misal: jadwal tes wawancara atau berkas yang belum jelas)..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setVerifyingApp(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Status Verifikasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
