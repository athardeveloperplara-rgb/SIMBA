import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  GraduationCap, 
  BookOpen, 
  UserCheck, 
  CheckSquare, 
  Award, 
  Clock, 
  FileText, 
  Calendar, 
  ArrowRight,
  TrendingUp,
  AlertCircle,
  Bell,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const DashboardOverview: React.FC = () => {
  const { 
    currentUser, 
    settings, 
    students, 
    teachers, 
    classes, 
    schedules, 
    attendance, 
    grades, 
    ppdbList, 
    auditLogs,
    navigateToSiakad 
  } = useApp();

  const role = currentUser?.role || 'siswa';

  const activeStudents = students.filter(s => s.status === 'aktif');
  const ppdbPending = ppdbList.filter(p => p.status === 'Menunggu Verifikasi').length;
  const ppdbVerified = ppdbList.filter(p => p.status === 'Terverifikasi' || p.status === 'Diterima').length;

  // Student specific data if role is siswa or ortu
  const currentStudent = students.find(s => s.id === currentUser?.studentId) || students[0];
  const studentGrades = grades.filter(g => g.studentId === currentStudent?.id);
  const studentAtt = attendance.filter(a => a.studentId === currentStudent?.id);
  const studentHadirCount = studentAtt.filter(a => a.status === 'Hadir').length;
  const studentTotalAtt = studentAtt.length || 1;
  const studentAttPct = Math.round((studentHadirCount / studentTotalAtt) * 100);

  // Teacher specific data if role is guru or wali_kelas
  const currentTeacher = teachers.find(t => t.id === currentUser?.teacherId) || teachers[1];
  const teacherSchedules = schedules.filter(sch => sch.teacherId === currentTeacher?.id);

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#0B1F3A] to-[#1E3A8A] rounded-2xl p-6 sm:p-8 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-300 mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Tahun Ajaran {settings.activeAcademicYear} — Semester {settings.activeSemester}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold font-heading text-white">
            Selamat Datang, {currentUser?.fullName}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            {role === 'super_admin' && 'Kelola seluruh data master akademik, rombongan belajar, presensi, rapor digital, dan konfigurasi sistem.'}
            {role === 'guru' && 'Pantau jadwal mengajar, input presensi siswa, isi rekap nilai, dan catat jurnal harian.'}
            {role === 'wali_kelas' && 'Pantau kehadiran siswa kelas binaan, kelola catatan wali kelas, dan validasi cetak rapor digital.'}
            {role === 'siswa' && 'Lihat jadwal kelas harian, rekap kehadiran diri, perolehan nilai mata pelajaran, dan cetak rapor.'}
            {role === 'orang_tua' && 'Pantau kehadiran putra-putri Anda hari ini, capaian nilai ujian, dan komunikasi sekolah.'}
            {role === 'petugas_ppdb' && 'Verifikasi berkas calon siswa baru dan perbarui status seleksi PPDB secara real-time.'}
          </p>
        </div>

        <div className="text-right flex-shrink-0">
          <span className="inline-block bg-white/10 text-white font-mono text-xs px-3 py-1.5 rounded-lg border border-white/20 font-bold uppercase">
            Peran: {role.replace('_', ' ')}
          </span>
        </div>
      </div>

      {/* ADMIN & OPERATOR VIEW */}
      {(role === 'super_admin' || role === 'admin_sekolah' || role === 'operator') && (
        <div className="space-y-6">
          {/* KPI Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Siswa Aktif</span>
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Users className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-slate-900 font-heading">
                {activeStudents.length}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Terbagi dalam {classes.length} rombel TKJ</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Guru & Tendik</span>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <GraduationCap className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-slate-900 font-heading">
                {teachers.length}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">100% kualifikasi S1/S2</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Pendaftar PPDB</span>
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                  <UserCheck className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-slate-900 font-heading">
                {ppdbList.length}
              </div>
              <p className="text-[11px] text-amber-600 font-semibold mt-1">
                {ppdbPending} perlu verifikasi
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Rerata Kehadiran</span>
                <div className="p-2 bg-sky-50 text-sky-600 rounded-lg">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-blue-600 font-heading">
                96.8%
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Berdasarkan presensi semester</p>
            </div>
          </div>

          {/* Class Distribution & Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Class distribution cards */}
            <div className="lg:col-span-8 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <span>Distribusi Rombongan Belajar (Rombel TKJ)</span>
                </h3>
                <button
                  onClick={() => navigateToSiakad('kelas')}
                  className="text-xs text-blue-600 font-bold hover:underline"
                >
                  Kelola Kelas
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {classes.map(cls => {
                  const studentCount = students.filter(s => s.classId === cls.id).length;
                  const pct = Math.round((studentCount / cls.capacity) * 100);
                  return (
                    <div key={cls.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/60">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-bold text-slate-900 font-heading">{cls.name}</span>
                        <span className="text-[11px] font-mono text-slate-600 font-semibold">{studentCount} / {cls.capacity} Siswa</span>
                      </div>
                      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                        <div className="bg-blue-600 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2">
                        <span>Wali: {cls.homeroomTeacherName.split(',')[0]}</span>
                        <span>{cls.room}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Actions for Admin */}
            <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-bold text-slate-900 text-sm font-heading">
                Aksi Cepat Administrator
              </h3>
              
              <button
                onClick={() => navigateToSiakad('siswa')}
                className="w-full p-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-bold text-left flex items-center justify-between transition"
              >
                <span>+ Tambah & Kelola Siswa</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigateToSiakad('presensi')}
                className="w-full p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold text-left flex items-center justify-between transition"
              >
                <span>Input Presensi Hari Ini</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigateToSiakad('nilai')}
                className="w-full p-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-bold text-left flex items-center justify-between transition"
              >
                <span>Rekap Nilai & Bobot Formatif</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigateToSiakad('rapor')}
                className="w-full p-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 text-xs font-bold text-left flex items-center justify-between transition"
              >
                <span>Cetak Rapor Digital Siswa</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigateToSiakad('ppdb-admin')}
                className="w-full p-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold text-left flex items-center justify-between transition"
              >
                <span>Verifikasi Pendaftar PPDB ({ppdbPending})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

          {/* Recent Audit Logs */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-blue-600" />
                <span>Log Aktivitas Sistem Terkini (Audit Trail)</span>
              </h3>
              <button
                onClick={() => navigateToSiakad('pengaturan')}
                className="text-xs text-blue-600 font-bold hover:underline"
              >
                Lihat Semua Log
              </button>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {auditLogs.slice(0, 4).map(log => (
                <div key={log.id} className="py-2.5 flex items-start justify-between gap-4">
                  <div>
                    <span className="font-bold text-slate-800">{log.userName}</span>
                    <span className="text-slate-400 font-mono text-[10px] ml-1.5">({log.userRole})</span>
                    <p className="text-slate-600 mt-0.5">{log.details}</p>
                  </div>
                  <span className="font-mono text-[10px] text-slate-400 whitespace-nowrap">
                    {log.timestamp}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* GURU & WALI KELAS VIEW */}
      {(role === 'guru' || role === 'wali_kelas') && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Mata Pelajaran Diampu</span>
              <div className="text-xl font-bold font-heading text-slate-900 mt-1">
                {currentTeacher?.subjectsTaught.length} Mata Pelajaran
              </div>
              <p className="text-xs text-blue-600 mt-1 font-semibold">{currentTeacher?.subjectsTaught[0]}</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Jadwal Mengajar Pekanan</span>
              <div className="text-xl font-bold font-heading text-slate-900 mt-1">
                {teacherSchedules.length} Sesi Pertemuan
              </div>
              <p className="text-xs text-slate-500 mt-1">Lab Komputer & Ruang Teori</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Tugas Tambahan</span>
              <div className="text-xl font-bold font-heading text-emerald-600 mt-1">
                {currentTeacher?.roleTitle}
              </div>
              <p className="text-xs text-slate-500 mt-1">Status: Aktif Mengajar</p>
            </div>
          </div>

          {/* Teacher quick schedule table */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>Jadwal Mengajar {currentTeacher?.fullName}</span>
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <th className="py-2.5 px-3">Hari & Jam</th>
                    <th className="py-2.5 px-3">Kelas</th>
                    <th className="py-2.5 px-3">Mata Pelajaran</th>
                    <th className="py-2.5 px-3">Ruang / Lab</th>
                    <th className="py-2.5 px-3 text-center">Aksi Cepat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {teacherSchedules.map(sch => (
                    <tr key={sch.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        {sch.day}, {sch.startTime} - {sch.endTime}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-blue-600">{sch.className}</td>
                      <td className="py-2.5 px-3 text-slate-700">{sch.subjectName}</td>
                      <td className="py-2.5 px-3 text-slate-500">{sch.room}</td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={() => navigateToSiakad('presensi')}
                          className="bg-blue-600 text-white px-2.5 py-1 rounded-md text-[11px] font-bold hover:bg-blue-700 transition"
                        >
                          Isi Presensi
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => navigateToSiakad('presensi')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-blue-400 shadow-xs text-left transition"
            >
              <CheckSquare className="w-5 h-5 text-blue-600 mb-1" />
              <div className="font-bold text-xs text-slate-900">Input Presensi Siswa</div>
              <p className="text-[11px] text-slate-500">Catat kehadiran Hadir, Sakit, Izin, Alpa</p>
            </button>

            <button
              onClick={() => navigateToSiakad('nilai')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-blue-400 shadow-xs text-left transition"
            >
              <Award className="w-5 h-5 text-emerald-600 mb-1" />
              <div className="font-bold text-xs text-slate-900">Input Nilai Formatif & Lab</div>
              <p className="text-[11px] text-slate-500">Kalkulasi nilai akhir & deskripsi kompetensi</p>
            </button>

            <button
              onClick={() => navigateToSiakad('jurnal')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-blue-400 shadow-xs text-left transition"
            >
              <Calendar className="w-5 h-5 text-sky-600 mb-1" />
              <div className="font-bold text-xs text-slate-900">Isi Jurnal Mengajar Harian</div>
              <p className="text-[11px] text-slate-500">Agenda materi & tindak lanjut pembelajaran</p>
            </button>
          </div>
        </div>
      )}

      {/* SISWA & ORANG TUA VIEW */}
      {(role === 'siswa' || role === 'orang_tua') && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
              <div>
                <span className="text-xs text-slate-400 font-semibold uppercase">Data Siswa Terkait:</span>
                <h3 className="text-lg font-bold text-slate-900 font-heading">
                  {currentStudent.fullName}
                </h3>
                <p className="text-xs text-slate-500 font-mono mt-0.5">
                  NIS: {currentStudent.nis} • NISN: {currentStudent.nisn} • Rombel: <span className="font-bold text-blue-600">{currentStudent.className}</span>
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Kehadiran Pribadi:</span>
                  <span className="text-xl font-extrabold text-emerald-600 font-heading">{studentAttPct}%</span>
                </div>
                <button
                  onClick={() => navigateToSiakad('rapor')}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition"
                >
                  Lihat E-Rapor
                </button>
              </div>
            </div>

            {/* Quick summary cards for student */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500">Status Keaktifan:</span>
                <span className="text-sm font-bold text-emerald-600 block capitalize mt-0.5">
                  ✓ Siswa Aktif
                </span>
              </div>
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500">Wali Kelas:</span>
                <span className="text-xs font-bold text-slate-800 block mt-0.5">
                  Siti Rahmawati, S.Kom.
                </span>
              </div>
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500">Mata Pelajaran Dinilai:</span>
                <span className="text-sm font-bold text-blue-600 block mt-0.5">
                  {studentGrades.length} Mata Pelajaran
                </span>
              </div>
            </div>
          </div>

          {/* Quick Schedule */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Jadwal Pelajaran Kelas {currentStudent.className}</span>
              </h3>
              <button
                onClick={() => navigateToSiakad('jadwal')}
                className="text-xs text-blue-600 font-bold hover:underline"
              >
                Lihat Jadwal Lengkap
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <th className="py-2.5 px-3">Hari & Jam</th>
                    <th className="py-2.5 px-3">Mata Pelajaran</th>
                    <th className="py-2.5 px-3">Guru Pengampu</th>
                    <th className="py-2.5 px-3">Ruang / Lab</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {schedules.filter(s => s.classId === currentStudent.classId).map(sch => (
                    <tr key={sch.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                        {sch.day}, {sch.startTime} - {sch.endTime}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-blue-600">{sch.subjectName}</td>
                      <td className="py-2.5 px-3 text-slate-700">{sch.teacherName}</td>
                      <td className="py-2.5 px-3 text-slate-500">{sch.room}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* PETUGAS PPDB VIEW */}
      {role === 'petugas_ppdb' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Total Pendaftar</span>
              <div className="text-2xl font-bold font-heading text-slate-900 mt-1">
                {ppdbList.length} Calon Siswa
              </div>
              <p className="text-xs text-slate-500 mt-1">Target Kuota: {settings.ppdbQuota} Siswa</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Menunggu Verifikasi</span>
              <div className="text-2xl font-bold font-heading text-amber-600 mt-1">
                {ppdbPending} Berkas
              </div>
              <p className="text-xs text-slate-500 mt-1">Perlu tindakan verifikator</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">Terverifikasi / Diterima</span>
              <div className="text-2xl font-bold font-heading text-emerald-600 mt-1">
                {ppdbVerified} Calon Siswa
              </div>
              <p className="text-xs text-slate-500 mt-1">Lulus seleksi berkas</p>
            </div>
          </div>

          <div className="text-center p-8 bg-white rounded-2xl border border-slate-200">
            <UserCheck className="w-12 h-12 text-blue-600 mx-auto mb-2" />
            <h3 className="text-base font-bold text-slate-900 font-heading">
              Siap Memproses Berkas Pendaftaran?
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
              Buka modul verifikasi untuk memeriksa kelengkapan Ijazah, KK, Akta, serta mengubah status kelulusan peserta.
            </p>
            <button
              onClick={() => navigateToSiakad('ppdb-admin')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow transition"
            >
              Buka Modul Verifikasi PPDB
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
