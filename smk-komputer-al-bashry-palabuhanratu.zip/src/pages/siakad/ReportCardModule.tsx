import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolLogo } from '../../components/SchoolLogo';
import { 
  FileText, 
  Printer, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  Save, 
  User, 
  Award 
} from 'lucide-react';

export const ReportCardModule: React.FC = () => {
  const { students, classes, subjects, grades, attendance, settings, currentUser } = useApp();

  const role = currentUser?.role || 'siswa';

  // If logged in as student or ortu, select that student by default
  const defaultStudentId = (role === 'siswa' || role === 'orang_tua') && currentUser?.studentId
    ? currentUser.studentId
    : students[0]?.id || 'std-1';

  const [selectedStudentId, setSelectedStudentId] = useState<string>(defaultStudentId);
  const [isLocked, setIsLocked] = useState<boolean>(true);
  const [homeroomNote, setHomeroomNote] = useState<string>(
    'Ananda memiliki etos belajar dan penguasaan praktikum hardware jaringan yang sangat baik. Tingkatkan terus kedisiplinan dan kepemimpinan dalam tim.'
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const student = students.find(s => s.id === selectedStudentId) || students[0];
  const studentGrades = grades.filter(g => g.studentId === student?.id);

  // Attendance metrics for student
  const studentAtt = attendance.filter(a => a.studentId === student?.id);
  const hadirCount = studentAtt.filter(a => a.status === 'Hadir').length || 18;
  const sakitCount = studentAtt.filter(a => a.status === 'Sakit').length || 1;
  const izinCount = studentAtt.filter(a => a.status === 'Izin').length || 0;
  const alpaCount = studentAtt.filter(a => a.status === 'Alpa').length || 0;

  const handlePrint = () => {
    window.print();
  };

  const handleToggleLock = () => {
    setIsLocked(!isLocked);
    setToastMessage(isLocked ? 'Rapor berhasil dibuka untuk revisi catatan.' : 'Rapor berhasil dikunci (Final).');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4 no-print">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Rapor Digital Hasil Belajar Siswa (E-Rapor)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Dokumen evaluasi capaian kompetensi akademik, kejuruan TKJ, presensi, dan ekstrakurikuler.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(role === 'super_admin' || role === 'admin_sekolah' || role === 'wali_kelas') && (
            <button
              onClick={handleToggleLock}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition border ${
                isLocked
                  ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
              }`}
            >
              {isLocked ? <Lock className="w-3.5 h-3.5 text-amber-600" /> : <Unlock className="w-3.5 h-3.5 text-emerald-600" />}
              <span>{isLocked ? 'Status: Terkunci (Buka)' : 'Status: Terbuka (Kunci)'}</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Rapor A4</span>
          </button>
        </div>
      </div>

      {toastMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2 no-print">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Student Selector (If Admin or Teacher) */}
      {(role === 'super_admin' || role === 'admin_sekolah' || role === 'guru' || role === 'wali_kelas') && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between no-print">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-700">Pilih Siswa:</span>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-blue-600 focus:ring-2 focus:ring-blue-500"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>{s.fullName} ({s.className})</option>
              ))}
            </select>
          </div>

          <span className="text-xs font-mono text-slate-500">
            NIS: {student.nis} • NISN: {student.nisn}
          </span>
        </div>
      )}

      {/* OFFICIAL RAPOR PAPER (A4 FORMAT) */}
      <div className="bg-white rounded-3xl p-8 sm:p-12 border-2 border-slate-300 shadow-xl space-y-6 print:border-none print:shadow-none print:p-0 print:m-0">
        
        {/* Kop Surat Sekolah Resmi */}
        <div className="border-b-4 border-double border-slate-900 pb-4 text-center relative flex items-center justify-between">
          <div className="flex-shrink-0">
            <SchoolLogo size={74} />
          </div>

          <div className="flex-1 px-4">
            <h3 className="text-xs font-bold tracking-widest text-slate-700 uppercase">
              PEMERINTAH DAERAH PROVINSI JAWA BARAT
            </h3>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#0B1F3A] font-heading tracking-tight leading-tight">
              SMK KOMPUTER AL-BASHRY PALABUHANRATU
            </h2>
            <p className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
              PROGRAM KEAHLIAN: TEKNIK KOMPUTER DAN JARINGAN (TKJ)
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {settings.address}, {settings.city} {settings.postalCode} • Telp: {settings.phone} • Email: {settings.email}
            </p>
          </div>

          <div className="w-16 hidden sm:block"></div>
        </div>

        <div className="text-center py-1">
          <h3 className="text-sm font-extrabold font-heading uppercase tracking-wider underline">
            LAPORAN HASIL CAPAIAN KOMPETENSI PESERTA DIDIK
          </h3>
          <p className="text-xs text-slate-500">Tahun Pelajaran: {settings.activeAcademicYear} — Semester: {settings.activeSemester}</p>
        </div>

        {/* Identitas Siswa */}
        <div className="grid grid-cols-2 gap-y-1.5 text-xs text-slate-800 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div><span className="text-slate-500">Nama Siswa:</span> <strong className="font-heading">{student.fullName}</strong></div>
          <div><span className="text-slate-500">Kelas / Rombel:</span> <strong className="font-bold text-blue-700">{student.className}</strong></div>
          <div><span className="text-slate-500">Nomor Induk Siswa (NIS):</span> <span className="font-mono">{student.nis}</span></div>
          <div><span className="text-slate-500">NISN:</span> <span className="font-mono">{student.nisn}</span></div>
          <div><span className="text-slate-500">Program Keahlian:</span> <strong>Teknik Komputer & Jaringan</strong></div>
          <div><span className="text-slate-500">Wali Kelas:</span> <strong>Siti Rahmawati, S.Kom.</strong></div>
        </div>

        {/* Tabel Nilai Capaian Kompetensi */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-heading">
            A. Nilai Hasil Belajar & Capaian Pembelajaran
          </h4>
          <div className="overflow-x-auto border border-slate-300 rounded-lg">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300 text-center">
                  <th className="py-2.5 px-3 w-10 text-left">No</th>
                  <th className="py-2.5 px-3 text-left">Mata Pelajaran</th>
                  <th className="py-2.5 px-2 w-16">KKM</th>
                  <th className="py-2.5 px-2 w-20">Nilai Akhir</th>
                  <th className="py-2.5 px-2 w-16">Predikat</th>
                  <th className="py-2.5 px-3 text-left">Capaian Kompetensi & Deskripsi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {subjects.map((subj, idx) => {
                  const g = studentGrades.find(item => item.subjectId === subj.id);
                  const score = g ? g.finalScore : (82 + ((idx * 3) % 12));
                  let pred = 'B';
                  if (score >= 88) pred = 'A';
                  else if (score >= 78) pred = 'B';
                  else if (score >= 70) pred = 'C';

                  const desc = g?.teacherNotes || `Menunjukkan pemahaman yang sangat baik dalam materi ${subj.name}. Mampu menerapkan konfigurasi secara mandiri.`;

                  return (
                    <tr key={subj.id} className="text-slate-800">
                      <td className="py-2 px-3 text-slate-500 font-mono text-center">{idx + 1}</td>
                      <td className="py-2 px-3 font-semibold text-slate-900">{subj.name}</td>
                      <td className="py-2 px-2 text-center font-mono">75</td>
                      <td className="py-2 px-2 text-center font-bold font-mono text-slate-900">{score}</td>
                      <td className="py-2 px-2 text-center font-extrabold">{pred}</td>
                      <td className="py-2 px-3 text-[11px] text-slate-600 leading-snug">{desc}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tabel Ekstrakurikuler & Kehadiran */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Ekstrakurikuler */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-heading">
              B. Kegiatan Ekstrakurikuler
            </h4>
            <table className="w-full text-xs border border-slate-300 rounded-lg overflow-hidden">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <th className="py-2 px-2.5 text-left">Kegiatan</th>
                  <th className="py-2 px-2 text-center">Predikat</th>
                  <th className="py-2 px-2.5 text-left">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="py-1.5 px-2.5 font-semibold">Club Jaringan & Robotika</td>
                  <td className="py-1.5 px-2 text-center font-bold text-emerald-700">A</td>
                  <td className="py-1.5 px-2.5 text-[11px]">Sangat aktif dalam simulasi mikrokontroler</td>
                </tr>
                <tr>
                  <td className="py-1.5 px-2.5 font-semibold">Praja Muda Karana (Pramuka)</td>
                  <td className="py-1.5 px-2 text-center font-bold text-blue-700">B</td>
                  <td className="py-1.5 px-2.5 text-[11px]">Mengikuti kegiatan perkemahan sabtu-minggu</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Kehadiran */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-heading">
              C. Ketidakhadiran Semester Ini
            </h4>
            <div className="border border-slate-300 rounded-lg p-3 text-xs space-y-1 bg-slate-50">
              <div className="flex justify-between py-0.5 border-b border-slate-200">
                <span>1. Hadir</span>
                <strong className="font-mono">{hadirCount} Hari</strong>
              </div>
              <div className="flex justify-between py-0.5 border-b border-slate-200">
                <span>2. Sakit</span>
                <strong className="font-mono">{sakitCount} Hari</strong>
              </div>
              <div className="flex justify-between py-0.5 border-b border-slate-200">
                <span>3. Izin</span>
                <strong className="font-mono">{izinCount} Hari</strong>
              </div>
              <div className="flex justify-between py-0.5">
                <span>4. Tanpa Keterangan (Alpa)</span>
                <strong className="font-mono">{alpaCount} Hari</strong>
              </div>
            </div>
          </div>

        </div>

        {/* Catatan Wali Kelas */}
        <div className="space-y-1.5">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-heading">
            D. Catatan Perkembangan Karakter & Wali Kelas
          </h4>
          <div className="border border-slate-300 rounded-lg p-3 bg-slate-50 text-xs">
            {(!isLocked && (role === 'wali_kelas' || role === 'super_admin')) ? (
              <textarea
                rows={2}
                value={homeroomNote}
                onChange={e => setHomeroomNote(e.target.value)}
                className="w-full bg-white p-2 border border-slate-300 rounded text-xs"
              />
            ) : (
              <p className="italic text-slate-700">{homeroomNote}</p>
            )}
          </div>
        </div>

        {/* Tanda Tangan */}
        <div className="pt-8 grid grid-cols-3 text-center text-xs text-slate-800">
          <div>
            <p>Mengetahui,</p>
            <p>Orang Tua / Wali Siswa</p>
            <div className="h-16"></div>
            <p className="font-bold underline">{student.parentName || '................................'}</p>
          </div>

          <div>
            <p>Palabuhanratu, 18 Desember 2026</p>
            <p>Wali Kelas X TKJ 1,</p>
            <div className="h-16"></div>
            <p className="font-bold underline">Siti Rahmawati, S.Kom.</p>
            <p className="text-[10px] text-slate-500">NIP. 19900820 201403 2 005</p>
          </div>

          <div>
            <p>Mengetahui,</p>
            <p>Kepala SMK Komputer Al-Bashry,</p>
            <div className="h-16"></div>
            <p className="font-bold underline">{settings.headmasterName}</p>
            <p className="text-[10px] text-slate-500">NIP. {settings.headmasterNip}</p>
          </div>
        </div>

      </div>

    </div>
  );
};
