import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AttendanceStatus, AttendanceRecord } from '../../types';
import { 
  CheckSquare, 
  Calendar, 
  Save, 
  Printer, 
  CheckCircle2, 
  Users, 
  AlertCircle,
  FileCheck
} from 'lucide-react';

export const AttendanceModule: React.FC = () => {
  const { classes, students, subjects, attendance, saveAttendanceBatch, currentUser } = useApp();

  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || 'c-1');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.id || 's-1');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const currentClass = classes.find(c => c.id === selectedClassId);
  const currentSubject = subjects.find(s => s.id === selectedSubjectId);
  const classStudents = students.filter(s => s.classId === selectedClassId);

  // Local attendance state for current date & class
  const [statusMap, setStatusMap] = useState<Record<string, { status: AttendanceStatus; note: string }>>(() => {
    const map: Record<string, { status: AttendanceStatus; note: string }> = {};
    classStudents.forEach(s => {
      // Find existing record
      const existing = attendance.find(a => a.studentId === s.id && a.date === selectedDate);
      map[s.id] = {
        status: existing?.status || 'Hadir',
        note: existing?.note || ''
      };
    });
    return map;
  });

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setStatusMap(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  const handleNoteChange = (studentId: string, note: string) => {
    setStatusMap(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        note
      }
    }));
  };

  const handleMarkAllPresent = () => {
    const updated: Record<string, { status: AttendanceStatus; note: string }> = {};
    classStudents.forEach(s => {
      updated[s.id] = { status: 'Hadir', note: '' };
    });
    setStatusMap(updated);
  };

  const handleSaveAttendance = () => {
    const records: Omit<AttendanceRecord, 'id'>[] = classStudents.map(s => ({
      date: selectedDate,
      classId: selectedClassId,
      className: currentClass?.name || 'X TKJ 1',
      subjectId: selectedSubjectId,
      subjectName: currentSubject?.name || 'Produktif TKJ',
      studentId: s.id,
      studentName: s.fullName,
      status: statusMap[s.id]?.status || 'Hadir',
      note: statusMap[s.id]?.note || '',
      recordedBy: currentUser?.fullName || 'Guru Pengampu'
    }));

    saveAttendanceBatch(records);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // KPI Calculations
  const hadirCount = classStudents.filter(s => (statusMap[s.id]?.status || 'Hadir') === 'Hadir').length;
  const sakitCount = classStudents.filter(s => statusMap[s.id]?.status === 'Sakit').length;
  const izinCount = classStudents.filter(s => statusMap[s.id]?.status === 'Izin').length;
  const alpaCount = classStudents.filter(s => statusMap[s.id]?.status === 'Alpa').length;
  const total = classStudents.length || 1;
  const pctHadir = Math.round((hadirCount / total) * 100);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4 no-print">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-blue-600" />
            <span>Presensi Kehadiran Siswa TKJ</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Input kehadiran pertemuan harian, status Hadir / Sakit / Izin / Alpa, dan rekapitulasi semester.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Presensi</span>
          </button>

          <button
            onClick={handleSaveAttendance}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl text-xs font-bold shadow transition"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Presensi</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2 no-print">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>Presensi tanggal {selectedDate} untuk kelas {currentClass?.name} berhasil disimpan ke database!</span>
        </div>
      )}

      {/* Control Panel: Class, Date, Subject, Mark All */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs space-y-4 no-print">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Rombel / Kelas:</label>
            <select
              value={selectedClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold text-blue-600"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Pertemuan:</label>
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Mata Pelajaran:</label>
            <select
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllPresent}
              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tandai Semua Hadir</span>
            </button>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <span className="text-emerald-700">Hadir: {hadirCount}</span>
            <span className="text-amber-700">Sakit: {sakitCount}</span>
            <span className="text-blue-700">Izin: {izinCount}</span>
            <span className="text-rose-700">Alpa: {alpaCount}</span>
            <span className="text-slate-900 font-bold bg-slate-100 px-2.5 py-1 rounded-md">
              Tingkat Kehadiran: {pctHadir}%
            </span>
          </div>
        </div>
      </div>

      {/* Attendance Sheet Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        
        {/* Printable Letterhead Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 font-heading">
              Lembar Presensi: Kelas {currentClass?.name} ({currentClass?.major})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Mata Pelajaran: {currentSubject?.name} • Tanggal: {selectedDate} • Pengampu: {currentSubject?.teacherName}
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-blue-600">
            {classStudents.length} Siswa Terdaftar
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-3 px-3.5 w-12 text-center">No</th>
                <th className="py-3 px-3.5">NIS</th>
                <th className="py-3 px-3.5">Nama Lengkap Siswa</th>
                <th className="py-3 px-3.5 text-center">Status Kehadiran</th>
                <th className="py-3 px-3.5">Keterangan / Catatan Izin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classStudents.map((student, idx) => {
                const currentStatus = statusMap[student.id]?.status || 'Hadir';
                const currentNote = statusMap[student.id]?.note || '';

                return (
                  <tr key={student.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-3.5 text-center font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-3 px-3.5 font-mono font-bold text-slate-700">{student.nis}</td>
                    <td className="py-3 px-3.5 font-bold text-slate-900">
                      {student.fullName}
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <div className="inline-flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                        {(['Hadir', 'Sakit', 'Izin', 'Alpa'] as AttendanceStatus[]).map(st => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => handleStatusChange(student.id, st)}
                            className={`px-2.5 py-1 rounded text-[11px] font-bold transition ${
                              currentStatus === st
                                ? st === 'Hadir' ? 'bg-emerald-600 text-white shadow-xs' :
                                  st === 'Sakit' ? 'bg-amber-500 text-white shadow-xs' :
                                  st === 'Izin' ? 'bg-blue-600 text-white shadow-xs' :
                                  'bg-rose-600 text-white shadow-xs'
                                : 'text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-3.5">
                      <input
                        type="text"
                        value={currentNote}
                        onChange={e => handleNoteChange(student.id, e.target.value)}
                        placeholder="Catatan surat sakit / dispensasi..."
                        className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-lg focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {classStudents.length === 0 && (
          <div className="text-center py-12 text-slate-400 text-xs">
            Belum ada siswa di kelas ini.
          </div>
        )}
      </div>

    </div>
  );
};
