import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { SchoolLogo } from '../../components/SchoolLogo';
import { 
  Users, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  Download, 
  Printer, 
  X, 
  CheckCircle2, 
  CreditCard,
  Filter
} from 'lucide-react';

export const StudentsManagement: React.FC = () => {
  const { students, classes, addStudent, updateStudent, deleteStudent, settings } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('Semua');
  const [selectedStatus, setSelectedStatus] = useState<string>('Semua');

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [printingStudent, setPrintingStudent] = useState<Student | null>(null);

  // Form Fields
  const [formData, setFormData] = useState({
    nis: '',
    nisn: '',
    fullName: '',
    gender: 'L' as 'L' | 'P',
    birthPlace: 'Sukabumi',
    birthDate: '2010-01-01',
    address: 'Palabuhanratu',
    phone: '',
    email: '',
    parentName: '',
    parentPhone: '',
    classId: classes[0]?.id || 'c-1',
    status: 'aktif' as 'aktif' | 'lulus' | 'pindah' | 'nonaktif',
    entryYear: '2026'
  });

  const filteredStudents = students.filter(s => {
    const matchesSearch = s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.nis.includes(searchTerm) ||
      s.nisn.includes(searchTerm);
    const matchesClass = selectedClass === 'Semua' || s.classId === selectedClass;
    const matchesStatus = selectedStatus === 'Semua' || s.status === selectedStatus;
    return matchesSearch && matchesClass && matchesStatus;
  });

  const handleOpenAdd = () => {
    setEditingStudent(null);
    const nextNis = `26010${String(students.length + 1).padStart(2, '0')}`;
    setFormData({
      nis: nextNis,
      nisn: `00876543${String(students.length + 20)}`,
      fullName: '',
      gender: 'L',
      birthPlace: 'Sukabumi',
      birthDate: '2010-05-12',
      address: 'Palabuhanratu, Sukabumi',
      phone: '0812-3456-7890',
      email: '',
      parentName: '',
      parentPhone: '0812-9988-7766',
      classId: classes[0]?.id || 'c-1',
      status: 'aktif',
      entryYear: '2026'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (std: Student) => {
    setEditingStudent(std);
    setFormData({
      nis: std.nis,
      nisn: std.nisn,
      fullName: std.fullName,
      gender: std.gender,
      birthPlace: std.birthPlace,
      birthDate: std.birthDate,
      address: std.address,
      phone: std.phone,
      email: std.email,
      parentName: std.parentName,
      parentPhone: std.parentPhone,
      classId: std.classId,
      status: std.status,
      entryYear: std.entryYear
    });
    setIsFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const targetClass = classes.find(c => c.id === formData.classId);
    const className = targetClass ? targetClass.name : 'X TKJ 1';

    if (editingStudent) {
      updateStudent(editingStudent.id, {
        ...formData,
        className,
        academicYear: settings.activeAcademicYear
      });
    } else {
      addStudent({
        ...formData,
        className,
        academicYear: settings.activeAcademicYear
      });
    }
    setIsFormOpen(false);
  };

  const handleExportCSV = () => {
    const headers = ['NIS', 'NISN', 'Nama Lengkap', 'JK', 'Kelas', 'Tahun Masuk', 'Status', 'Alamat', 'Orang Tua', 'No WA Ortu'];
    const rows = filteredStudents.map(s => [
      `"${s.nis}"`,
      `"${s.nisn}"`,
      `"${s.fullName}"`,
      s.gender,
      `"${s.className}"`,
      s.entryYear,
      s.status,
      `"${s.address.replace(/"/g, '""')}"`,
      `"${s.parentName}"`,
      `"${s.parentPhone}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Data_Siswa_SMK_AlBashry_${settings.activeAcademicYear.replace('/', '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Manajemen Data Siswa (Kesiswaan)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola biodata induk siswa, kelas rombongan belajar TKJ, mutasi, dan pencetakan Kartu Tanda Pelajar.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
            title="Ekspor CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Siswa Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Cari nama, NIS, atau NISN..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-semibold">Kelas:</span>
            <select
              value={selectedClass}
              onChange={e => setSelectedClass(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-blue-500"
            >
              <option value="Semua">Semua Kelas ({students.length})</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-semibold">Status:</span>
            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-blue-500 capitalize"
            >
              <option value="Semua">Semua Status</option>
              <option value="aktif">Aktif</option>
              <option value="lulus">Lulus</option>
              <option value="pindah">Pindah</option>
              <option value="nonaktif">Nonaktif</option>
            </select>
          </div>
        </div>
      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-3 px-3.5">NIS / NISN</th>
                <th className="py-3 px-3.5">Nama Lengkap</th>
                <th className="py-3 px-3.5">L/P</th>
                <th className="py-3 px-3.5">Rombel</th>
                <th className="py-3 px-3.5">Domisili</th>
                <th className="py-3 px-3.5">Orang Tua / Wali</th>
                <th className="py-3 px-3.5 text-center">Status</th>
                <th className="py-3 px-3.5 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-3.5 font-mono">
                    <span className="font-bold text-slate-800">{student.nis}</span>
                    <span className="block text-[10px] text-slate-400">{student.nisn}</span>
                  </td>
                  <td className="py-3 px-3.5">
                    <span className="font-bold text-slate-900 block">{student.fullName}</span>
                    <span className="text-[10px] text-slate-400">Masuk: {student.entryYear}</span>
                  </td>
                  <td className="py-3 px-3.5 font-bold">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${student.gender === 'L' ? 'bg-sky-50 text-sky-700' : 'bg-pink-50 text-pink-700'}`}>
                      {student.gender}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 font-semibold text-blue-600">
                    {student.className}
                  </td>
                  <td className="py-3 px-3.5 text-slate-600 max-w-xs truncate">
                    {student.address}
                  </td>
                  <td className="py-3 px-3.5 text-slate-700">
                    <span>{student.parentName}</span>
                    <span className="block text-[10px] text-slate-400 font-mono">{student.parentPhone}</span>
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                      student.status === 'aktif' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {student.status}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => setPrintingStudent(student)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                        title="Cetak Kartu Tanda Pelajar"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(student)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition"
                        title="Edit Siswa"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Yakin ingin menghapus siswa ${student.fullName}?`)) {
                            deleteStudent(student.id);
                          }
                        }}
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Siswa"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredStudents.length === 0 && (
          <div className="text-center py-12 text-slate-400 text-xs">
            Tidak ada siswa yang sesuai dengan filter pencarian.
          </div>
        )}
      </div>

      {/* FORM MODAL (ADD / EDIT) */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                {editingStudent ? 'Edit Data Siswa' : 'Tambah Siswa Baru'}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">NIS *</label>
                  <input
                    type="text"
                    value={formData.nis}
                    onChange={e => setFormData({ ...formData, nis: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">NISN *</label>
                  <input
                    type="text"
                    value={formData.nisn}
                    onChange={e => setFormData({ ...formData, nisn: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Lengkap Siswa *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jenis Kelamin</label>
                  <select
                    value={formData.gender}
                    onChange={e => setFormData({ ...formData, gender: e.target.value as 'L' | 'P' })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kelas / Rombel</label>
                  <select
                    value={formData.classId}
                    onChange={e => setFormData({ ...formData, classId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold text-blue-600"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tempat Lahir</label>
                  <input
                    type="text"
                    value={formData.birthPlace}
                    onChange={e => setFormData({ ...formData, birthPlace: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal Lahir</label>
                  <input
                    type="date"
                    value={formData.birthDate}
                    onChange={e => setFormData({ ...formData, birthDate: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Alamat Domisili</label>
                <textarea
                  rows={2}
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Orang Tua / Wali</label>
                  <input
                    type="text"
                    value={formData.parentName}
                    onChange={e => setFormData({ ...formData, parentName: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">No. WhatsApp Orang Tua</label>
                  <input
                    type="tel"
                    value={formData.parentPhone}
                    onChange={e => setFormData({ ...formData, parentPhone: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tahun Masuk</label>
                  <input
                    type="text"
                    value={formData.entryYear}
                    onChange={e => setFormData({ ...formData, entryYear: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Status Siswa</label>
                  <select
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg capitalize"
                  >
                    <option value="aktif">Aktif</option>
                    <option value="lulus">Lulus</option>
                    <option value="pindah">Pindah</option>
                    <option value="nonaktif">Nonaktif</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Data Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* KARTU TANDA PELAJAR MODAL (PRINT READY) */}
      {printingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200">
            <div className="p-4 bg-slate-100 border-b border-slate-200 flex items-center justify-between no-print">
              <span className="text-xs font-bold text-slate-700">Pratinjau Kartu Pelajar Resmi</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="bg-blue-600 text-white px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1 shadow"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak</span>
                </button>
                <button onClick={() => setPrintingStudent(null)} className="p-1 text-slate-500">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Official Student Card Canvas */}
            <div className="p-6 bg-gradient-to-br from-[#0B1F3A] to-[#1E3A8A] text-white rounded-2xl m-4 shadow-lg border-2 border-amber-300 relative overflow-hidden">
              <div className="flex items-center gap-3 border-b border-white/20 pb-3">
                <div className="bg-white p-1 rounded-full">
                  <SchoolLogo size={42} />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold font-heading text-white tracking-tight leading-tight">
                    SMK KOMPUTER AL-BASHRY
                  </h4>
                  <p className="text-[9px] text-sky-200 font-semibold tracking-wide">
                    KARTU TANDA PELAJAR • TEKNIK KOMPUTER & JARINGAN
                  </p>
                  <p className="text-[8px] text-slate-300">
                    Palabuhanratu, Kab. Sukabumi • NPSN: {settings.npsn}
                  </p>
                </div>
              </div>

              <div className="pt-4 flex items-center gap-4">
                <img
                  src={printingStudent.photoUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80'}
                  alt={printingStudent.fullName}
                  className="w-20 h-24 object-cover rounded-lg border-2 border-white/80 shadow"
                />
                <div className="space-y-1 text-[11px]">
                  <div>
                    <span className="text-[9px] text-sky-300 block">Nama Siswa:</span>
                    <strong className="text-white block font-heading">{printingStudent.fullName}</strong>
                  </div>
                  <div>
                    <span className="text-[9px] text-sky-300 block">NIS / NISN:</span>
                    <span className="font-mono text-slate-200">{printingStudent.nis} / {printingStudent.nisn}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-sky-300 block">Kelas / Rombel:</span>
                    <span className="font-bold text-amber-300">{printingStudent.className}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-sky-300 block">Alamat:</span>
                    <span className="text-slate-300 text-[10px] line-clamp-1">{printingStudent.address}</span>
                  </div>
                </div>
              </div>

              {/* Barcode & Signature */}
              <div className="mt-4 pt-3 border-t border-white/20 flex items-end justify-between text-[9px] text-slate-300">
                <div>
                  <div className="font-mono tracking-widest text-[10px] text-white">||| | |||| | ||| |||| |</div>
                  <span>ID: {printingStudent.id}</span>
                </div>
                <div className="text-right">
                  <span>Kepala Sekolah,</span>
                  <div className="h-6"></div>
                  <strong className="text-white underline">{settings.headmasterName.split(',')[0]}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
