import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolClass } from '../../types';
import { 
  BookOpen, 
  Plus, 
  Users, 
  Edit3, 
  Trash2, 
  X, 
  CheckCircle2, 
  Home, 
  UserCheck 
} from 'lucide-react';

export const ClassesManagement: React.FC = () => {
  const { classes, addClass, updateClass, deleteClass, teachers, students } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedClassForStudents, setSelectedClassForStudents] = useState<SchoolClass | null>(null);
  const [editingClass, setEditingClass] = useState<SchoolClass | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    gradeLevel: 'X' as 'X' | 'XI' | 'XII',
    major: 'Teknik Komputer dan Jaringan',
    homeroomTeacherId: teachers[0]?.id || '',
    capacity: 36,
    room: 'Lab Jaringan 1'
  });

  const handleOpenAdd = () => {
    setEditingClass(null);
    setFormData({
      name: 'X TKJ 3',
      gradeLevel: 'X',
      major: 'Teknik Komputer dan Jaringan',
      homeroomTeacherId: teachers[0]?.id || '',
      capacity: 36,
      room: 'Ruang Teori 4'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: SchoolClass) => {
    setEditingClass(c);
    setFormData({
      name: c.name,
      gradeLevel: c.gradeLevel,
      major: c.major,
      homeroomTeacherId: c.homeroomTeacherId,
      capacity: c.capacity,
      room: c.room
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const teacher = teachers.find(t => t.id === formData.homeroomTeacherId);
    const homeroomTeacherName = teacher ? teacher.fullName : 'Belum Ditentukan';

    if (editingClass) {
      updateClass(editingClass.id, {
        ...formData,
        homeroomTeacherName,
        academicYear: '2026/2027'
      });
    } else {
      addClass({
        ...formData,
        homeroomTeacherName,
        academicYear: '2026/2027'
      });
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <span>Manajemen Kelas & Rombongan Belajar (Rombel)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar rombel kejuruan TKJ tingkat X, XI, XII beserta penugasan wali kelas dan ruang laboratorium.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Rombel Baru</span>
        </button>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {classes.map(cls => {
          const classStudents = students.filter(s => s.classId === cls.id);
          const ratio = Math.round((classStudents.length / cls.capacity) * 100);

          return (
            <div key={cls.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200 font-mono">
                    Tingkat {cls.gradeLevel}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(cls)}
                      className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition"
                      title="Edit Rombel"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Hapus rombel ${cls.name}?`)) {
                          deleteClass(cls.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                      title="Hapus Rombel"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="text-xl font-extrabold font-heading text-slate-900 mb-1">
                  {cls.name}
                </h3>
                <p className="text-xs font-medium text-slate-500 mb-4">
                  {cls.major}
                </p>

                <div className="space-y-2.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Wali Kelas:</span>
                    <span className="font-bold text-slate-800">{cls.homeroomTeacherName.split(',')[0]}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Ruang Belajar:</span>
                    <span className="font-semibold text-slate-700">{cls.room}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Kapasitas Kursi:</span>
                    <span className="font-mono font-semibold text-slate-700">{classStudents.length} / {cls.capacity} Siswa</span>
                  </div>

                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-1">
                    <div className="bg-blue-600 h-full rounded-full" style={{ width: `${ratio}%` }}></div>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100">
                <button
                  onClick={() => setSelectedClassForStudents(cls)}
                  className="w-full bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-700 font-bold py-2 rounded-xl text-xs transition flex items-center justify-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5 text-blue-600" />
                  <span>Lihat Anggota Siswa ({classStudents.length})</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal View Class Students */}
      {selectedClassForStudents && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base font-heading">
                  Daftar Anggota Siswa — {selectedClassForStudents.name}
                </h3>
                <p className="text-xs text-sky-300">
                  Wali Kelas: {selectedClassForStudents.homeroomTeacherName}
                </p>
              </div>
              <button onClick={() => setSelectedClassForStudents(null)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto flex-1">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <th className="py-2.5 px-3">No</th>
                    <th className="py-2.5 px-3">NIS</th>
                    <th className="py-2.5 px-3">Nama Siswa</th>
                    <th className="py-2.5 px-3">L/P</th>
                    <th className="py-2.5 px-3">No. HP Orang Tua</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.filter(s => s.classId === selectedClassForStudents.id).map((std, idx) => (
                    <tr key={std.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{std.nis}</td>
                      <td className="py-2.5 px-3 font-bold text-slate-900">{std.fullName}</td>
                      <td className="py-2.5 px-3 font-bold">{std.gender}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">{std.parentPhone}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {students.filter(s => s.classId === selectedClassForStudents.id).length === 0 && (
                <div className="text-center py-8 text-xs text-slate-400">
                  Belum ada siswa yang ditempatkan pada rombel ini.
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedClassForStudents(null)}
                className="bg-blue-600 text-white font-bold text-xs px-4 py-2 rounded-lg"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Add / Edit Class */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                {editingClass ? 'Edit Rombel' : 'Tambah Rombel Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Rombel *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: X TKJ 1, XI TKJ 2"
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tingkat Kelas</label>
                  <select
                    value={formData.gradeLevel}
                    onChange={e => setFormData({ ...formData, gradeLevel: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="X">Kelas X</option>
                    <option value="XI">Kelas XI</option>
                    <option value="XII">Kelas XII</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kapasitas Maksimal</label>
                  <input
                    type="number"
                    value={formData.capacity}
                    onChange={e => setFormData({ ...formData, capacity: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Wali Kelas</label>
                <select
                  value={formData.homeroomTeacherId}
                  onChange={e => setFormData({ ...formData, homeroomTeacherId: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>{t.fullName}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ruangan / Laboratorium</label>
                <input
                  type="text"
                  value={formData.room}
                  onChange={e => setFormData({ ...formData, room: e.target.value })}
                  placeholder="Contoh: Lab Jaringan 1, Ruang Teori 2"
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Rombel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
