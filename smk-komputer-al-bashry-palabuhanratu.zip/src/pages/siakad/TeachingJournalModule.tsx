import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TeachingJournal } from '../../types';
import { 
  Calendar, 
  Plus, 
  Search, 
  BookOpen, 
  Edit3, 
  Trash2, 
  X, 
  CheckCircle2, 
  Clock, 
  Users 
} from 'lucide-react';

export const TeachingJournalModule: React.FC = () => {
  const { journals, addJournal, deleteJournal, classes, subjects, teachers, currentUser } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    classId: classes[0]?.id || 'c-1',
    subjectId: subjects[0]?.id || 's-1',
    teacherId: teachers[0]?.id || 't-1',
    period: 'Jam ke 1 - 3 (07:30 - 10:00)',
    topic: '',
    competency: '',
    learningActivities: '',
    presentCount: 35,
    absentCount: 1,
    obstacles: 'Tidak ada kendala berarti.',
    followUp: 'Pemberian tugas pengayaan konfigurasi mandiri.'
  });

  const filteredJournals = journals.filter(j => 
    j.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
    j.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
    j.subjectName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      classId: classes[0]?.id || 'c-1',
      subjectId: subjects[0]?.id || 's-1',
      teacherId: currentUser?.teacherId || teachers[1]?.id || 't-2',
      period: 'Jam ke 1 - 3 (07:30 - 10:00)',
      topic: '',
      competency: '',
      learningActivities: '',
      presentCount: 35,
      absentCount: 1,
      obstacles: '',
      followUp: ''
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cls = classes.find(c => c.id === formData.classId);
    const subj = subjects.find(s => s.id === formData.subjectId);
    const teacher = teachers.find(t => t.id === formData.teacherId);

    addJournal({
      ...formData,
      className: cls ? cls.name : 'X TKJ 1',
      subjectName: subj ? subj.name : 'Produktif TKJ',
      teacherName: teacher ? teacher.fullName : 'Guru Pengampu'
    });
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span>Jurnal Mengajar & Agenda Harian Guru</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Dokumentasi ketercapaian materi pembelajaran, kehadiran siswa, kendala praktikum lab, dan tindak lanjut.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Isi Jurnal Baru</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Cari materi, kelas, atau mapel..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
        <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
          {filteredJournals.length} Catatan Jurnal
        </span>
      </div>

      {/* Journal Cards */}
      <div className="space-y-4">
        {filteredJournals.map(jnl => (
          <div key={jnl.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:border-blue-300 transition space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-md bg-blue-600 text-white font-mono font-bold text-xs">
                  {jnl.date}
                </span>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 font-heading">
                    {jnl.subjectName} — <span className="text-blue-600">{jnl.className}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Guru: {jnl.teacherName} • {jnl.period}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-md font-semibold border border-emerald-200">
                  Hadir: {jnl.presentCount} Siswa
                </span>
                {jnl.absentCount > 0 && (
                  <span className="bg-rose-50 text-rose-800 px-2.5 py-1 rounded-md font-semibold border border-rose-200">
                    Absen: {jnl.absentCount}
                  </span>
                )}
                <button
                  onClick={() => {
                    if (confirm(`Hapus jurnal tanggal ${jnl.date}?`)) {
                      deleteJournal(jnl.id);
                    }
                  }}
                  className="p-1 text-slate-400 hover:text-rose-600"
                  title="Hapus Jurnal"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
              <div>
                <strong className="block text-slate-800 font-bold mb-1">Materi Pokok Pembelajaran:</strong>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100">{jnl.topic}</p>
              </div>
              <div>
                <strong className="block text-slate-800 font-bold mb-1">Capaian Kompetensi Dasar:</strong>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100">{jnl.competency}</p>
              </div>
            </div>

            <div>
              <strong className="block text-xs text-slate-800 font-bold mb-1">Rincian Kegiatan Pembelajaran & Praktikum:</strong>
              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                {jnl.learningActivities}
              </p>
            </div>

            {(jnl.obstacles || jnl.followUp) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 text-[11px] text-slate-500 border-t border-slate-100">
                <div>
                  <span className="font-semibold text-amber-700">Kendala Praktik: </span>
                  <span>{jnl.obstacles || 'Nihil'}</span>
                </div>
                <div>
                  <span className="font-semibold text-blue-700">Tindak Lanjut: </span>
                  <span>{jnl.followUp || 'Nihil'}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modal Add Journal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                Isi Jurnal Mengajar Harian
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal *</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jam Pelajaran</label>
                  <input
                    type="text"
                    value={formData.period}
                    onChange={e => setFormData({ ...formData, period: e.target.value })}
                    placeholder="Jam ke 1 - 3 (07:30 - 10:00)"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kelas *</label>
                  <select
                    value={formData.classId}
                    onChange={e => setFormData({ ...formData, classId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mata Pelajaran *</label>
                  <select
                    value={formData.subjectId}
                    onChange={e => setFormData({ ...formData, subjectId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Materi Pokok Pembelajaran *</label>
                <input
                  type="text"
                  value={formData.topic}
                  onChange={e => setFormData({ ...formData, topic: e.target.value })}
                  placeholder="Contoh: Konfigurasi VLAN & Trunking pada Switch Cisco"
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Kompetensi yang Dikembangkan *</label>
                <input
                  type="text"
                  value={formData.competency}
                  onChange={e => setFormData({ ...formData, competency: e.target.value })}
                  placeholder="Contoh: Mampu merancang topologi inter-VLAN dan pengujian ping antar port"
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Rincian Kegiatan Praktik Siswa</label>
                <textarea
                  rows={3}
                  value={formData.learningActivities}
                  onChange={e => setFormData({ ...formData, learningActivities: e.target.value })}
                  placeholder="Demonstrasi guru, penugasan kelompok 2 siswa per workstation, analisis packet tracer..."
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jumlah Siswa Hadir</label>
                  <input
                    type="number"
                    value={formData.presentCount}
                    onChange={e => setFormData({ ...formData, presentCount: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jumlah Tidak Hadir</label>
                  <input
                    type="number"
                    value={formData.absentCount}
                    onChange={e => setFormData({ ...formData, absentCount: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kendala / Masalah</label>
                  <input
                    type="text"
                    value={formData.obstacles}
                    onChange={e => setFormData({ ...formData, obstacles: e.target.value })}
                    placeholder="Kendala alat/perangkat jika ada..."
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tindak Lanjut Guru</label>
                  <input
                    type="text"
                    value={formData.followUp}
                    onChange={e => setFormData({ ...formData, followUp: e.target.value })}
                    placeholder="Remedial / tugas pengayaan..."
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Jurnal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
