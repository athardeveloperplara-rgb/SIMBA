import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Settings, 
  Save, 
  RotateCcw, 
  Download, 
  CheckCircle2, 
  ShieldCheck, 
  AlertTriangle, 
  Database,
  Building,
  Calendar,
  Award,
  Clock
} from 'lucide-react';

export const SystemSettingsModule: React.FC = () => {
  const { settings, updateSettings, auditLogs, resetAllData, exportJSON } = useApp();

  const [form, setForm] = useState({ ...settings });
  const [successSaved, setSuccessSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(form);
    setSuccessSaved(true);
    setTimeout(() => setSuccessSaved(false), 3000);
  };

  const handleReset = () => {
    if (confirm('PERINGATAN: Apakah Anda yakin ingin mengembalikan seluruh basis data ke kondisi awal (default)? Seluruh perubahan input akan diatur ulang.')) {
      resetAllData();
      setForm({ ...settings });
      alert('Basis data berhasil diatur ulang ke data inisial.');
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <span>Pengaturan Sistem, Konfigurasi & Audit Log</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Konfigurasi identitas lembaga, tahun ajaran aktif, bobot kalkulasi nilai, dan log aktivitas keamanan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportJSON}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
            title="Cadangkan Seluruh Basis Data ke File JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Backup Database JSON</span>
          </button>

          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-3 py-2 rounded-xl text-xs font-bold transition"
            title="Reset ke Data Bawaan"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Default</span>
          </button>
        </div>
      </div>

      {successSaved && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>Pengaturan sistem dan konfigurasi akademik berhasil diperbarui!</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Card 1: Identitas Lembaga */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 font-heading flex items-center gap-2 border-b border-slate-100 pb-2">
            <Building className="w-4 h-4" />
            <span>Identitas Resmi SMK Komputer Al-Bashry</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Resmi Sekolah</label>
              <input
                type="text"
                value={form.schoolName}
                onChange={e => setForm({ ...form, schoolName: e.target.value })}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">NPSN</label>
              <input
                type="text"
                value={form.npsn}
                onChange={e => setForm({ ...form, npsn: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Kepala Sekolah</label>
              <input
                type="text"
                value={form.headmasterName}
                onChange={e => setForm({ ...form, headmasterName: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">NIP Kepala Sekolah</label>
              <input
                type="text"
                value={form.headmasterNip}
                onChange={e => setForm({ ...form, headmasterNip: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Alamat Kampus</label>
            <input
              type="text"
              value={form.address}
              onChange={e => setForm({ ...form, address: e.target.value })}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Telepon Kantor</label>
              <input
                type="text"
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">No. WhatsApp Panitia</label>
              <input
                type="text"
                value={form.whatsapp}
                onChange={e => setForm({ ...form, whatsapp: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Resmi</label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Periode Akademik & Bobot Penilaian */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 font-heading flex items-center gap-2 border-b border-slate-100 pb-2">
            <Calendar className="w-4 h-4" />
            <span>Kalender Akademik & Konfigurasi Bobot Nilai</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tahun Pelajaran Aktif</label>
              <input
                type="text"
                value={form.activeAcademicYear}
                onChange={e => setForm({ ...form, activeAcademicYear: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold text-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Semester Aktif</label>
              <select
                value={form.activeSemester}
                onChange={e => setForm({ ...form, activeSemester: e.target.value as any })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
              >
                <option value="Ganjil">Semester Ganjil</option>
                <option value="Genap">Semester Genap</option>
              </select>
            </div>
          </div>

          {/* Bobot Nilai Slider / Input */}
          <div className="pt-2">
            <span className="block text-xs font-bold text-slate-800 mb-2">
              Formula Bobot Nilai Akhir Mata Pelajaran (Harus Total 100%):
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-slate-500 block mb-1">Formatif / Tugas:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={form.gradeWeightTugas}
                    onChange={e => setForm({ ...form, gradeWeightTugas: Number(e.target.value) })}
                    className="w-16 px-2 py-1 text-center font-bold text-sm border rounded font-mono"
                  />
                  <span>%</span>
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-slate-500 block mb-1">Praktik / Lab TKJ:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={form.gradeWeightPraktik}
                    onChange={e => setForm({ ...form, gradeWeightPraktik: Number(e.target.value) })}
                    className="w-16 px-2 py-1 text-center font-bold text-sm border rounded font-mono text-blue-600"
                  />
                  <span>%</span>
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-slate-500 block mb-1">ATS / UTS:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={form.gradeWeightUts}
                    onChange={e => setForm({ ...form, gradeWeightUts: Number(e.target.value) })}
                    className="w-16 px-2 py-1 text-center font-bold text-sm border rounded font-mono"
                  />
                  <span>%</span>
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-slate-500 block mb-1">AAS / UAS:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={form.gradeWeightUas}
                    onChange={e => setForm({ ...form, gradeWeightUas: Number(e.target.value) })}
                    className="w-16 px-2 py-1 text-center font-bold text-sm border rounded font-mono"
                  />
                  <span>%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Card 3: Konfigurasi PPDB */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 font-heading flex items-center gap-2 border-b border-slate-100 pb-2">
            <Award className="w-4 h-4" />
            <span>Pengaturan PPDB Online</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status Pendaftaran Online</label>
              <select
                value={form.ppdbActive ? 'true' : 'false'}
                onChange={e => setForm({ ...form, ppdbActive: e.target.value === 'true' })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
              >
                <option value="true">Buka (Menerima Pendaftaran)</option>
                <option value="false">Tutup (Pendaftaran Berakhir)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tahun PPDB</label>
              <input
                type="text"
                value={form.ppdbYear}
                onChange={e => setForm({ ...form, ppdbYear: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kuota Daya Tampung Siswa</label>
              <input
                type="number"
                value={form.ppdbQuota}
                onChange={e => setForm({ ...form, ppdbQuota: Number(e.target.value) })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold"
              />
            </div>
          </div>
        </div>

        <div className="text-right">
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center gap-2 ml-auto"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Semua Pengaturan</span>
          </button>
        </div>
      </form>

      {/* Audit Log Trail Viewer */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800 font-heading flex items-center gap-2 border-b border-slate-100 pb-2">
          <Clock className="w-4 h-4 text-blue-600" />
          <span>Audit Trail & Riwayat Aktivitas Sistem ({auditLogs.length} Entri)</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-2.5 px-3">Waktu</th>
                <th className="py-2.5 px-3">Pengguna</th>
                <th className="py-2.5 px-3">Aksi</th>
                <th className="py-2.5 px-3">Modul</th>
                <th className="py-2.5 px-3">Rincian Perubahan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {auditLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                  <td className="py-2 px-3 font-bold text-slate-800">{log.userName}</td>
                  <td className="py-2 px-3 font-semibold text-blue-700">{log.action}</td>
                  <td className="py-2 px-3 text-slate-600">{log.module}</td>
                  <td className="py-2 px-3 font-sans text-xs text-slate-700">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
