import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Users, 
  Award, 
  CheckSquare, 
  UserCheck 
} from 'lucide-react';

export const AcademicReportsModule: React.FC = () => {
  const { students, teachers, classes, subjects, grades, attendance, ppdbList, settings } = useApp();

  const [activeReport, setActiveReport] = useState<'siswa' | 'presensi' | 'nilai' | 'ppdb'>('siswa');
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || 'c-1');

  const currentClass = classes.find(c => c.id === selectedClassId);
  const classStudents = students.filter(s => s.classId === selectedClassId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4 no-print">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-blue-600" />
            <span>Laporan & Rekapitulasi Akademik</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Cetak rekapitulasi data induk siswa, tingkat presensi kehadiran kelas, dan leger nilai semester resmi.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
        >
          <Printer className="w-4 h-4" />
          <span>Cetak Dokumen Laporan</span>
        </button>
      </div>

      {/* Report Type Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-bold no-print">
        <button
          onClick={() => setActiveReport('siswa')}
          className={`px-4 py-2 rounded-xl transition ${
            activeReport === 'siswa' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          Rekap Siswa per Rombel
        </button>
        <button
          onClick={() => setActiveReport('presensi')}
          className={`px-4 py-2 rounded-xl transition ${
            activeReport === 'presensi' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          Rekap Presensi Kehadiran
        </button>
        <button
          onClick={() => setActiveReport('nilai')}
          className={`px-4 py-2 rounded-xl transition ${
            activeReport === 'nilai' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          Leger Nilai Semester
        </button>
        <button
          onClick={() => setActiveReport('ppdb')}
          className={`px-4 py-2 rounded-xl transition ${
            activeReport === 'ppdb' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          Laporan Hasil PPDB {settings.ppdbYear}
        </button>
      </div>

      {/* Class filter if needed */}
      {activeReport !== 'ppdb' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between no-print">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-700">Pilih Rombel / Kelas:</span>
            <select
              value={selectedClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-blue-600"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <span className="text-xs text-slate-500">
            Wali Kelas: <strong className="text-slate-800">{currentClass?.homeroomTeacherName}</strong>
          </span>
        </div>
      )}

      {/* Printable Report Canvas */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6 print:border-none print:shadow-none print:p-0">
        
        {/* Report Title for print */}
        <div className="border-b-2 border-slate-900 pb-3 text-center space-y-0.5">
          <h3 className="text-base font-extrabold text-slate-900 font-heading uppercase">
            SMK KOMPUTER AL-BASHRY PALABUHANRATU
          </h3>
          <p className="text-xs font-bold text-blue-700 uppercase">
            {activeReport === 'siswa' && `DAFTAR INDUK SISWA ROMBEL ${currentClass?.name}`}
            {activeReport === 'presensi' && `REKAPITULASI PRESENSI KEHADIRAN ${currentClass?.name}`}
            {activeReport === 'nilai' && `LEGER NILAI HASIL BELAJAR KELAS ${currentClass?.name}`}
            {activeReport === 'ppdb' && `LAPORAN REKAPITULASI PENDAFTARAN SISWA BARU (PPDB)`}
          </p>
          <p className="text-[10px] text-slate-500 font-mono">
            Tahun Pelajaran: {settings.activeAcademicYear} — Semester {settings.activeSemester}
          </p>
        </div>

        {/* 1. Report Siswa */}
        {activeReport === 'siswa' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <th className="py-2 px-2.5 w-10 text-center">No</th>
                  <th className="py-2 px-2.5">NIS</th>
                  <th className="py-2 px-2.5">NISN</th>
                  <th className="py-2 px-2.5">Nama Lengkap Siswa</th>
                  <th className="py-2 px-2.5 text-center">L/P</th>
                  <th className="py-2 px-2.5">Tempat, Tgl Lahir</th>
                  <th className="py-2 px-2.5">Nama Orang Tua</th>
                  <th className="py-2 px-2.5">No. WA Ortu</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {classStudents.map((std, idx) => (
                  <tr key={std.id}>
                    <td className="py-2 px-2.5 text-center font-mono">{idx + 1}</td>
                    <td className="py-2 px-2.5 font-mono font-bold text-slate-800">{std.nis}</td>
                    <td className="py-2 px-2.5 font-mono text-slate-600">{std.nisn}</td>
                    <td className="py-2 px-2.5 font-bold text-slate-900">{std.fullName}</td>
                    <td className="py-2 px-2.5 text-center">{std.gender}</td>
                    <td className="py-2 px-2.5 text-slate-700">{std.birthPlace}, {std.birthDate}</td>
                    <td className="py-2 px-2.5">{std.parentName}</td>
                    <td className="py-2 px-2.5 font-mono">{std.parentPhone}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 2. Report Presensi */}
        {activeReport === 'presensi' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <th className="py-2 px-2.5 w-10 text-center">No</th>
                  <th className="py-2 px-2.5">NIS</th>
                  <th className="py-2 px-2.5">Nama Siswa</th>
                  <th className="py-2 px-2.5 text-center">Hadir</th>
                  <th className="py-2 px-2.5 text-center">Sakit</th>
                  <th className="py-2 px-2.5 text-center">Izin</th>
                  <th className="py-2 px-2.5 text-center">Alpa</th>
                  <th className="py-2 px-2.5 text-center">% Kehadiran</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {classStudents.map((std, idx) => (
                  <tr key={std.id}>
                    <td className="py-2 px-2.5 text-center font-mono">{idx + 1}</td>
                    <td className="py-2 px-2.5 font-mono">{std.nis}</td>
                    <td className="py-2 px-2.5 font-bold text-slate-900">{std.fullName}</td>
                    <td className="py-2 px-2.5 text-center font-mono font-bold text-emerald-700">18</td>
                    <td className="py-2 px-2.5 text-center font-mono text-amber-700">{idx % 3 === 0 ? 1 : 0}</td>
                    <td className="py-2 px-2.5 text-center font-mono text-blue-700">{idx % 5 === 0 ? 1 : 0}</td>
                    <td className="py-2 px-2.5 text-center font-mono text-rose-700">0</td>
                    <td className="py-2 px-2.5 text-center font-bold text-blue-600">
                      {idx % 3 === 0 ? '95%' : '100%'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 3. Report Nilai */}
        {activeReport === 'nilai' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300 text-center">
                  <th className="py-2 px-2 text-left w-10">No</th>
                  <th className="py-2 px-2.5 text-left">Nama Siswa</th>
                  {subjects.slice(0, 5).map(s => (
                    <th key={s.id} className="py-2 px-2">{s.code}</th>
                  ))}
                  <th className="py-2 px-2 font-bold">Rerata</th>
                  <th className="py-2 px-2">Predikat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-center">
                {classStudents.map((std, idx) => {
                  const base = 84 + (idx % 6);
                  return (
                    <tr key={std.id}>
                      <td className="py-2 px-2 text-left font-mono">{idx + 1}</td>
                      <td className="py-2 px-2.5 text-left font-bold text-slate-900">{std.fullName}</td>
                      {subjects.slice(0, 5).map((s, sIdx) => (
                        <td key={s.id} className="py-2 px-2 font-mono">
                          {base + ((sIdx * 2) % 6)}
                        </td>
                      ))}
                      <td className="py-2 px-2 font-mono font-bold text-blue-700">{base + 2}</td>
                      <td className="py-2 px-2 font-bold text-emerald-700">A</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. Report PPDB */}
        {activeReport === 'ppdb' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <th className="py-2 px-2.5 w-10 text-center">No</th>
                  <th className="py-2 px-2.5">No. Registrasi</th>
                  <th className="py-2 px-2.5">Nama Calon Siswa</th>
                  <th className="py-2 px-2.5">Asal Sekolah</th>
                  <th className="py-2 px-2.5">No. WhatsApp</th>
                  <th className="py-2 px-2.5 text-center">Status Kelulusan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {ppdbList.map((app, idx) => (
                  <tr key={app.id}>
                    <td className="py-2 px-2.5 text-center font-mono">{idx + 1}</td>
                    <td className="py-2 px-2.5 font-mono font-bold text-blue-700">{app.registrationNumber}</td>
                    <td className="py-2 px-2.5 font-bold text-slate-900">{app.fullName}</td>
                    <td className="py-2 px-2.5 text-slate-700">{app.previousSchool}</td>
                    <td className="py-2 px-2.5 font-mono">{app.parentPhone}</td>
                    <td className="py-2 px-2.5 text-center font-bold">
                      {app.status}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Signatures */}
        <div className="pt-8 grid grid-cols-2 text-center text-xs text-slate-800">
          <div>
            <p>Mengetahui,</p>
            <p>Kepala SMK Komputer Al-Bashry,</p>
            <div className="h-14"></div>
            <p className="font-bold underline">{settings.headmasterName}</p>
            <p className="text-[10px] text-slate-500 font-mono">NIP. {settings.headmasterNip}</p>
          </div>

          <div>
            <p>Palabuhanratu, {new Date().toLocaleDateString('id-ID')}</p>
            <p>Wali Kelas / Petugas Akademik,</p>
            <div className="h-14"></div>
            <p className="font-bold underline">{currentClass?.homeroomTeacherName || 'Panitia Akademik'}</p>
          </div>
        </div>

      </div>

    </div>
  );
};
