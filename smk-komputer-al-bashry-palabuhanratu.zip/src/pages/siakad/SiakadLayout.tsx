import React, { useState } from 'react';
import { useApp, SiakadModule } from '../../context/AppContext';
import { SchoolLogo } from '../../components/SchoolLogo';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  BookOpen, 
  Calendar, 
  Clock, 
  CheckSquare, 
  Award, 
  FileText, 
  BookMarked, 
  UserCheck, 
  FileSpreadsheet, 
  Settings, 
  LogOut, 
  Globe, 
  Menu, 
  X, 
  Bell, 
  ShieldCheck, 
  User, 
  ChevronRight,
  Database
} from 'lucide-react';

export const SiakadLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { 
    currentUser, 
    logout, 
    activeSiakadModule, 
    navigateToSiakad, 
    exitSiakadToPublic,
    settings 
  } = useApp();

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const role = currentUser?.role || 'siswa';

  // Role permissions check
  const canAccess = (moduleKey: SiakadModule): boolean => {
    if (role === 'super_admin' || role === 'admin_sekolah' || role === 'operator') return true;

    switch (moduleKey) {
      case 'dashboard':
        return true;
      case 'siswa':
        return role === 'wali_kelas';
      case 'guru-admin':
        return false;
      case 'kelas':
        return role === 'wali_kelas';
      case 'mapel':
        return false;
      case 'jadwal':
        return true; // Guru, Siswa, Ortu can see schedules
      case 'presensi':
        return role === 'guru' || role === 'wali_kelas' || role === 'siswa' || role === 'orang_tua';
      case 'nilai':
        return role === 'guru' || role === 'wali_kelas' || role === 'siswa' || role === 'orang_tua';
      case 'rapor':
        return role === 'wali_kelas' || role === 'siswa' || role === 'orang_tua';
      case 'jurnal':
        return role === 'guru';
      case 'ppdb-admin':
        return role === 'petugas_ppdb';
      case 'berita-admin':
        return false;
      case 'laporan':
        return role === 'wali_kelas';
      case 'pengaturan':
        return false;
      default:
        return false;
    }
  };

  const navItems: { key: SiakadModule; label: string; icon: React.ElementType }[] = [
    { key: 'dashboard', label: 'Dashboard Utama', icon: LayoutDashboard },
    { key: 'siswa', label: 'Data Siswa', icon: Users },
    { key: 'guru-admin', label: 'Data Guru & Tendik', icon: GraduationCap },
    { key: 'kelas', label: 'Kelas & Rombel', icon: BookOpen },
    { key: 'mapel', label: 'Mata Pelajaran', icon: BookMarked },
    { key: 'jadwal', label: 'Jadwal Pelajaran', icon: Clock },
    { key: 'presensi', label: 'Presensi Kehadiran', icon: CheckSquare },
    { key: 'nilai', label: 'Penilaian & Nilai', icon: Award },
    { key: 'rapor', label: 'Rapor Digital Siswa', icon: FileText },
    { key: 'jurnal', label: 'Jurnal Mengajar Guru', icon: Calendar },
    { key: 'ppdb-admin', label: 'Verifikasi PPDB', icon: UserCheck },
    { key: 'laporan', label: 'Laporan Akademik', icon: FileSpreadsheet },
    { key: 'pengaturan', label: 'Pengaturan & Audit', icon: Settings },
  ];

  const filteredNavItems = navItems.filter(item => canAccess(item.key));

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col">
      
      {/* Top Navbar */}
      <header className="no-print bg-[#0B1F3A] text-white border-b border-slate-800 sticky top-8 z-30 shadow-md">
        <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Left: Mobile trigger & School Identity */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div 
              onClick={exitSiakadToPublic}
              className="flex items-center gap-3 cursor-pointer group"
              title="Kembali ke Website Publik"
            >
              <div className="bg-white p-1 rounded-full shadow-sm">
                <SchoolLogo size={38} />
              </div>
              <div className="hidden sm:flex flex-col">
                <span className="font-extrabold text-white text-sm sm:text-base tracking-tight font-heading group-hover:text-sky-300 transition">
                  SIAKAD AL-BASHRY
                </span>
                <span className="text-[10px] text-sky-300 font-semibold uppercase tracking-wider">
                  Sistem Informasi Akademik TKJ
                </span>
              </div>
            </div>
          </div>

          {/* Right: Academic Year Pill, Notifications & User Profile */}
          <div className="flex items-center gap-3">
            
            {/* Active Academic Year Pill */}
            <div className="hidden md:flex items-center gap-1.5 bg-blue-900/60 border border-blue-700/60 px-3 py-1 rounded-full text-xs text-sky-200">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-semibold">TA {settings.activeAcademicYear} ({settings.activeSemester})</span>
            </div>

            {/* Back to Public button */}
            <button
              onClick={exitSiakadToPublic}
              className="hidden sm:inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
            >
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span>Portal Publik</span>
            </button>

            {/* User Profile Dropdown Pill */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-700">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center border border-white/20">
                {currentUser?.fullName.charAt(0) || 'U'}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-bold text-white leading-tight">
                  {currentUser?.fullName}
                </span>
                <span className="text-[10px] text-sky-300 font-mono capitalize">
                  {currentUser?.role.replace('_', ' ')}
                </span>
              </div>

              <button
                onClick={logout}
                className="p-1.5 text-slate-300 hover:text-rose-400 hover:bg-white/10 rounded-lg transition ml-1"
                title="Keluar / Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>
      </header>

      {/* Main App Layout */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        
        {/* Left Sidebar */}
        <aside className={`
          no-print fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white lg:bg-transparent border-r lg:border-none border-slate-200 p-4 lg:p-0 flex flex-col justify-between transition-transform duration-200
          ${sidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
        `}>
          <div className="space-y-6">
            
            {/* Mobile Header in Drawer */}
            <div className="lg:hidden flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="font-bold text-slate-900 text-sm">Menu SIAKAD</span>
              <button onClick={() => setSidebarOpen(false)} className="p-1 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Role Header card */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-[#0B1F3A] to-[#1E3A8A] text-white shadow-xs">
              <span className="text-[10px] text-sky-300 uppercase tracking-wider font-bold block mb-1">
                Hak Akses Aktif:
              </span>
              <p className="text-xs font-extrabold font-heading text-white truncate">
                {currentUser?.fullName}
              </p>
              <div className="inline-block mt-1.5 bg-blue-500/30 text-sky-200 text-[10px] font-mono px-2 py-0.5 rounded border border-blue-400/30 uppercase">
                {currentUser?.role.replace('_', ' ')}
              </div>
            </div>

            {/* Navigation Menu List */}
            <nav className="space-y-1">
              {filteredNavItems.map(item => {
                const Icon = item.icon;
                const isActive = activeSiakadModule === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => {
                      navigateToSiakad(item.key);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      <span>{item.label}</span>
                    </div>
                    {isActive && <ChevronRight className="w-3.5 h-3.5 text-blue-200" />}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar Footer info */}
          <div className="pt-4 border-t border-slate-200 text-[11px] text-slate-400">
            <p className="font-semibold text-slate-600">{settings.schoolName}</p>
            <p className="text-[10px] mt-0.5">Versi SIAKAD v2.6 • Terenkripsi</p>
          </div>
        </aside>

        {/* Backdrop for mobile drawer */}
        {sidebarOpen && (
          <div 
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden fixed inset-0 z-30 bg-slate-900/40 backdrop-blur-xs"
          />
        )}

        {/* Right Main Content Area */}
        <main className="flex-1 min-w-0">
          {children}
        </main>

      </div>

    </div>
  );
};
