import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject } from '../../types';
import { 
  BookMarked, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  X, 
  CheckCircle2, 
  Layers 
} from 'lucide-react';

export const SubjectsManagement: React.FC = () => {
  const { subjects, addSubject, updateSubject, deleteSubject, teachers } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('Semua');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  const [formData, setFormData] = useState({
    code: '',
    name: '',
    group: 'Muatan Peminatan Kejuruan (TKJ)' as Subject['group'],
    totalHours: 5,
    teacherId: teachers[0]?.id || '',
    targetGrades: ['X'] as ('X' | 'XI' | 'XII')[],
    description: ''
  });

  const filteredSubjects = subjects.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.teacherName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = selectedGroup === 'Semua' || s.group === selectedGroup;
    return matchesSearch && matchesGroup;
  });

  const handleOpenAdd = () => {
    setEditingSubject(null);
    setFormData({
      code: `TKJ-${String(subjects.length + 10)}`,
      name: '',
      group: 'Muatan Peminatan Kejuruan (TKJ)',
      totalHours: 5,
      teacherId: teachers[0]?.id || '',
      targetGrades: ['XI'],
      description: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (s: Subject) => {
    setEditingSubject(s);
    setFormData({
      code: s.code,
      name: s.name,
      group: s.group,
      totalHours: s.totalHours,
      teacherId: s.teacherId,
      targetGrades: s.targetGrades,
      description: s.description || ''
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const teacher = teachers.find(t => t.id === formData.teacherId);
    const teacherName = teacher ? teacher.fullName : 'Belum Ditugaskan';

    if (editingSubject) {
      updateSubject(editingSubject.id, {
        ...formData,
        teacherName
      });
    } else {
      addSubject({
        ...formData,
        teacherName
      });
    }
    setIsModalOpen(false);
  };

  const toggleGrade = (grade: 'X' | 'XI' | 'XII') => {
    if (formData.targetGrades.includes(grade)) {
      if (formData.targetGrades.length > 1) {
        setFormData({ ...formData, targetGrades: formData.targetGrades.filter(g => g !== grade) });
      }
    } else {
      setFormData({ ...formData, targetGrades: [...formData.targetGrades, grade] });
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <BookMarked className="w-5 h-5 text-blue-600" />
            <span>Manajemen Kurikulum & Mata Pelajaran</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar mata pelajaran umum, kejuruan TKJ, alokasi jam belajar per minggu, serta penetapan guru pengampu.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Mata Pelajaran</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Cari nama atau kode mapel..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">Kelompok:</span>
          <select
            value={selectedGroup}
            onChange={e => setSelectedGroup(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-blue-500"
          >
            <option value="Semua">Semua Kelompok ({subjects.length})</option>
            <option value="Muatan Peminatan Kejuruan (TKJ)">Produktif TKJ</option>
            <option value="Muatan Nasional">Muatan Nasional</option>
            <option value="Muatan Kewilayahan">Muatan Kewilayahan</option>
            <option value="Muatan Lokal">Muatan Lokal</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-3 px-3.5">Kode Mapel</th>
                <th className="py-3 px-3.5">Nama Mata Pelajaran</th>
                <th className="py-3 px-3.5">Kelompok Kurikulum</th>
                <th className="py-3 px-3.5">Beban Jam</th>
                <th className="py-3 px-3.5">Tingkat</th>
                <th className="py-3 px-3.5">Guru Pengampu</th>
                <th className="py-3 px-3.5 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSubjects.map(subj => (
                <tr key={subj.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-3.5 font-mono font-bold text-blue-600">
                    {subj.code}
                  </td>
                  <td className="py-3 px-3.5">
                    <span className="font-bold text-slate-900 block">{subj.name}</span>
                    <span className="text-[10px] text-slate-400 line-clamp-1">{subj.description}</span>
                  </td>
                  <td className="py-3 px-3.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      subj.group.includes('TKJ') ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {subj.group}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 font-mono font-semibold text-slate-700">
                    {subj.totalHours} JP / Minggu
                  </td>
                  <td className="py-3 px-3.5 font-semibold text-slate-700">
                    {subj.targetGrades.join(', ')}
                  </td>
                  <td className="py-3 px-3.5 font-medium text-slate-800">
                    {subj.teacherName}
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(subj)}
                        className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition"
                        title="Edit Mapel"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Hapus mapel ${subj.name}?`)) {
                            deleteSubject(subj.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Mapel"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Subject */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                {editingSubject ? 'Edit Mata Pelajaran' : 'Tambah Mata Pelajaran'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kode Mapel *</label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={e => setFormData({ ...formData, code: e.target.value })}
                    placeholder="Contoh: KJD-10, AIJ-11"
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jumlah JP / Minggu</label>
                  <input
                    type="number"
                    value={formData.totalHours}
                    onChange={e => setFormData({ ...formData, totalHours: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Mata Pelajaran *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Administrasi Infrastruktur Jaringan"
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Kelompok Kurikulum</label>
                <select
                  value={formData.group}
                  onChange={e => setFormData({ ...formData, group: e.target.value as any })}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                >
                  <option value="Muatan Peminatan Kejuruan (TKJ)">Muatan Peminatan Kejuruan (TKJ)</option>
                  <option value="Muatan Nasional">Muatan Nasional</option>
                  <option value="Muatan Kewilayahan">Muatan Kewilayahan</option>
                  <option value="Muatan Lokal">Muatan Lokal</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Guru Pengampu</label>
                <select
                  value={formData.teacherId}
                  onChange={e => setFormData({ ...formData, teacherId: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>{t.fullName}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tingkat Kelas</label>
                <div className="flex items-center gap-3">
                  {(['X', 'XI', 'XII'] as const).map(g => (
                    <button
                      type="button"
                      key={g}
                      onClick={() => toggleGrade(g)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                        formData.targetGrades.includes(g)
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      Kelas {g}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Deskripsi Ringkas</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Ringkasan materi pokok dan capaian praktikum..."
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Mapel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
