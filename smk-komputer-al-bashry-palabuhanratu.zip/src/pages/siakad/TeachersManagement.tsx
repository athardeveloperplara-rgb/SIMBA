import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Teacher } from '../../types';
import { 
  GraduationCap, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  X, 
  CheckCircle2, 
  BookOpen,
  Phone,
  Mail
} from 'lucide-react';

export const TeachersManagement: React.FC = () => {
  const { teachers, addTeacher, updateTeacher, deleteTeacher, classes } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);

  const [formData, setFormData] = useState({
    nip: '',
    fullName: '',
    gender: 'L' as 'L' | 'P',
    phone: '',
    email: '',
    education: '',
    subjectsTaught: '',
    roleTitle: 'Guru Produktif TKJ',
    status: 'aktif' as 'aktif' | 'nonaktif'
  });

  const filteredTeachers = teachers.filter(t => 
    t.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.nip.includes(searchTerm) ||
    t.roleTitle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingTeacher(null);
    setFormData({
      nip: `199${Math.floor(100000 + Math.random() * 900000)} 202601 1 001`,
      fullName: '',
      gender: 'L',
      phone: '0812-3456-7890',
      email: '',
      education: 'S1 Teknik Informatika',
      subjectsTaught: 'Komputer dan Jaringan Dasar (KJD)',
      roleTitle: 'Guru Produktif TKJ',
      status: 'aktif'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (t: Teacher) => {
    setEditingTeacher(t);
    setFormData({
      nip: t.nip,
      fullName: t.fullName,
      gender: t.gender,
      phone: t.phone,
      email: t.email,
      education: t.education,
      subjectsTaught: t.subjectsTaught.join(', '),
      roleTitle: t.roleTitle,
      status: t.status
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const subjectsArray = formData.subjectsTaught.split(',').map(s => s.trim()).filter(Boolean);

    if (editingTeacher) {
      updateTeacher(editingTeacher.id, {
        ...formData,
        subjectsTaught: subjectsArray
      });
    } else {
      addTeacher({
        ...formData,
        subjectsTaught: subjectsArray,
        isHomeroom: false,
        photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'
      });
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-blue-600" />
            <span>Manajemen Pendidik & Tenaga Kependidikan</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar pengajar kurikulum kejuruan TKJ, guru muatan umum, serta penugasan jabatan struktural.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Guru Baru</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Cari nama guru, NIP, atau jabatan..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
        <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
          Total: {filteredTeachers.length} Guru
        </span>
      </div>

      {/* Teachers Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-3 px-3.5">Nama & NIP</th>
                <th className="py-3 px-3.5">Jabatan / Peran</th>
                <th className="py-3 px-3.5">Pendidikan</th>
                <th className="py-3 px-3.5">Mata Pelajaran Diampu</th>
                <th className="py-3 px-3.5">Kontak</th>
                <th className="py-3 px-3.5 text-center">Status</th>
                <th className="py-3 px-3.5 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTeachers.map(teacher => (
                <tr key={teacher.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-3.5">
                    <span className="font-bold text-slate-900 block">{teacher.fullName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">NIP. {teacher.nip}</span>
                  </td>
                  <td className="py-3 px-3.5">
                    <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded text-[11px]">
                      {teacher.roleTitle}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 text-slate-600">
                    {teacher.education}
                  </td>
                  <td className="py-3 px-3.5 text-slate-700 font-medium">
                    {teacher.subjectsTaught.join(', ')}
                  </td>
                  <td className="py-3 px-3.5 text-slate-500 font-mono text-[11px]">
                    <div>{teacher.phone}</div>
                    <div className="text-[10px] text-slate-400">{teacher.email}</div>
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                      teacher.status === 'aktif' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {teacher.status}
                    </span>
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(teacher)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition"
                        title="Edit Guru"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Hapus data guru ${teacher.fullName}?`)) {
                            deleteTeacher(teacher.id);
                          }
                        }}
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Guru"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add/Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl">
            <div className="bg-[#0B1F3A] text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-sm font-heading">
                {editingTeacher ? 'Edit Data Pendidik' : 'Tambah Pendidik Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Lengkap & Gelar *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="Contoh: Irvan Kurniawan, S.Pd., M.Kom."
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">NIP *</label>
                  <input
                    type="text"
                    value={formData.nip}
                    onChange={e => setFormData({ ...formData, nip: e.target.value })}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jenis Kelamin</label>
                  <select
                    value={formData.gender}
                    onChange={e => setFormData({ ...formData, gender: e.target.value as 'L' | 'P' })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Jabatan / Peran</label>
                  <input
                    type="text"
                    value={formData.roleTitle}
                    onChange={e => setFormData({ ...formData, roleTitle: e.target.value })}
                    placeholder="Contoh: Guru Produktif TKJ"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Pendidikan Terakhir</label>
                  <input
                    type="text"
                    value={formData.education}
                    onChange={e => setFormData({ ...formData, education: e.target.value })}
                    placeholder="Contoh: S1 Teknik Informatika"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mata Pelajaran yang Diampu (Pisahkan dengan koma)
                </label>
                <input
                  type="text"
                  value={formData.subjectsTaught}
                  onChange={e => setFormData({ ...formData, subjectsTaught: e.target.value })}
                  placeholder="Contoh: Administrasi Infrastruktur Jaringan, Keamanan Jaringan"
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">No. WhatsApp</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Email Sekolah</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 shadow"
                >
                  Simpan Data Guru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
