import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GradeItem } from '../../types';
import { 
  Award, 
  Printer, 
  Save, 
  CheckCircle2, 
  Download, 
  HelpCircle, 
  Sparkles 
} from 'lucide-react';

export const GradesModule: React.FC = () => {
  const { classes, subjects, students, grades, saveGrade, settings, currentUser } = useApp();

  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || 'c-1');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.id || 's-1');
  const [successToast, setSuccessToast] = useState(false);

  const currentClass = classes.find(c => c.id === selectedClassId);
  const currentSubject = subjects.find(s => s.id === selectedSubjectId);
  const classStudents = students.filter(s => s.classId === selectedClassId);

  // Local state for table editing
  const [localScores, setLocalScores] = useState<Record<string, { tugas: number; praktik: number; uts: number; uas: number; notes: string }>>(() => {
    const map: Record<string, { tugas: number; praktik: number; uts: number; uas: number; notes: string }> = {};
    classStudents.forEach(s => {
      const existing = grades.find(g => g.studentId === s.id && g.subjectId === selectedSubjectId);
      map[s.id] = {
        tugas: existing ? existing.tugas : 85,
        praktik: existing ? existing.praktik : 88,
        uts: existing ? existing.uts : 82,
        uas: existing ? existing.uas : 86,
        notes: existing ? existing.teacherNotes : 'Menunjukkan ketelitian baik dalam perakitan dan konfigurasi.'
      };
    });
    return map;
  });

  const handleScoreChange = (studentId: string, field: 'tugas' | 'praktik' | 'uts' | 'uas', val: number) => {
    const clamped = Math.max(0, Math.min(100, isNaN(val) ? 0 : val));
    setLocalScores(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: clamped
      }
    }));
  };

  const handleNotesChange = (studentId: string, text: string) => {
    setLocalScores(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes: text
      }
    }));
  };

  const computeFinal = (item: { tugas: number; praktik: number; uts: number; uas: number }) => {
    const wT = settings.gradeWeightTugas / 100;
    const wP = settings.gradeWeightPraktik / 100;
    const wUTS = settings.gradeWeightUts / 100;
    const wUAS = settings.gradeWeightUas / 100;

    const final = Math.round((item.tugas * wT) + (item.praktik * wP) + (item.uts * wUTS) + (item.uas * wUAS));
    let pred: 'A' | 'B' | 'C' | 'D' = 'D';
    if (final >= 88) pred = 'A';
    else if (final >= 78) pred = 'B';
    else if (final >= 70) pred = 'C';

    return { final, pred };
  };

  const handleSaveAllGrades = () => {
    classStudents.forEach(s => {
      const scores = localScores[s.id] || { tugas: 80, praktik: 85, uts: 80, uas: 82, notes: '' };
      saveGrade({
        studentId: s.id,
        studentName: s.fullName,
        classId: selectedClassId,
        subjectId: selectedSubjectId,
        subjectName: currentSubject?.name || 'Mata Pelajaran TKJ',
        semester: settings.activeSemester,
        academicYear: settings.activeAcademicYear,
        tugas: scores.tugas,
        praktik: scores.praktik,
        uts: scores.uts,
        uas: scores.uas,
        teacherNotes: scores.notes,
        updatedBy: currentUser?.fullName || 'Guru Pengampu'
      });
    });

    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4 no-print">
        <div>
          <h2 className="text-xl font-extrabold font-heading text-slate-900 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-600" />
            <span>Penilaian & Nilai Siswa (Kurikulum TKJ)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Penginputan nilai Formatif/Tugas ({settings.gradeWeightTugas}%), Praktik Lab ({settings.gradeWeightPraktik}%), ATS/UTS ({settings.gradeWeightUts}%), dan AAS/UAS ({settings.gradeWeightUas}%).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Leger Nilai</span>
          </button>

          <button
            onClick={handleSaveAllGrades}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl text-xs font-bold shadow transition"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Nilai</span>
          </button>
        </div>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2 no-print">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>Nilai mata pelajaran {currentSubject?.name} kelas {currentClass?.name} berhasil disimpan dan dikalkulasi!</span>
        </div>
      )}

      {/* Selectors */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4 no-print">
        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Pilih Kelas:</label>
            <select
              value={selectedClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-blue-600"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Mata Pelajaran:</label>
            <select
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
              ))}
            </select>
          </div>
        </div>

        <div className="text-right text-xs text-slate-500">
          <span>Bobot: Tugas {settings.gradeWeightTugas}% | Praktik {settings.gradeWeightPraktik}% | UTS {settings.gradeWeightUts}% | UAS {settings.gradeWeightUas}%</span>
        </div>
      </div>

      {/* Grade Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-slate-900 font-heading">
              Leger Nilai: {currentSubject?.name} ({currentClass?.name})
            </h3>
            <p className="text-xs text-slate-500">
              Pengampu: {currentSubject?.teacherName} • TA {settings.activeAcademicYear} ({settings.activeSemester})
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-center">
                <th className="py-3 px-3 text-left w-12">No</th>
                <th className="py-3 px-3 text-left">Nama Siswa</th>
                <th className="py-3 px-3 w-20">Tugas (30%)</th>
                <th className="py-3 px-3 w-20">Praktik (30%)</th>
                <th className="py-3 px-3 w-20">UTS (20%)</th>
                <th className="py-3 px-3 w-20">UAS (20%)</th>
                <th className="py-3 px-3 w-24">Nilai Akhir</th>
                <th className="py-3 px-3 w-16">Predikat</th>
                <th className="py-3 px-3 text-left">Catatan Capaian Guru</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classStudents.map((student, idx) => {
                const sData = localScores[student.id] || { tugas: 80, praktik: 85, uts: 80, uas: 80, notes: '' };
                const { final, pred } = computeFinal(sData);

                return (
                  <tr key={student.id} className="hover:bg-slate-50/80 transition text-center">
                    <td className="py-2.5 px-3 text-left font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-2.5 px-3 text-left">
                      <span className="font-bold text-slate-900 block">{student.fullName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">NIS: {student.nis}</span>
                    </td>
                    <td className="py-2.5 px-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={sData.tugas}
                        onChange={e => handleScoreChange(student.id, 'tugas', Number(e.target.value))}
                        className="w-16 px-1.5 py-1 text-center font-mono font-bold text-slate-800 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                    <td className="py-2.5 px-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={sData.praktik}
                        onChange={e => handleScoreChange(student.id, 'praktik', Number(e.target.value))}
                        className="w-16 px-1.5 py-1 text-center font-mono font-bold text-blue-700 bg-blue-50/50 border border-blue-300 rounded focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                    <td className="py-2.5 px-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={sData.uts}
                        onChange={e => handleScoreChange(student.id, 'uts', Number(e.target.value))}
                        className="w-16 px-1.5 py-1 text-center font-mono font-bold text-slate-800 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                    <td className="py-2.5 px-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={sData.uas}
                        onChange={e => handleScoreChange(student.id, 'uas', Number(e.target.value))}
                        className="w-16 px-1.5 py-1 text-center font-mono font-bold text-slate-800 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                    <td className="py-2.5 px-3 font-mono font-extrabold text-base text-slate-900">
                      {final}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-extrabold ${
                        pred === 'A' ? 'bg-emerald-100 text-emerald-800' :
                        pred === 'B' ? 'bg-blue-100 text-blue-800' :
                        pred === 'C' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {pred}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-left">
                      <input
                        type="text"
                        value={sData.notes}
                        onChange={e => handleNotesChange(student.id, e.target.value)}
                        placeholder="Deskripsi pencapaian kompetensi..."
                        className="w-full px-2 py-1 text-xs border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 text-slate-700"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
