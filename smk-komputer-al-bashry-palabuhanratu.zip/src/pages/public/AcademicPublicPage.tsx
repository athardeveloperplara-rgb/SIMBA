import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Calendar, 
  BookOpen, 
  Clock, 
  Award, 
  FileText, 
  CheckCircle2, 
  Briefcase,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';

export const AcademicPublicPage: React.FC = () => {
  const { settings, subjects } = useApp();
  const [activeSem, setActiveSem] = useState<'ganjil' | 'genap'>('ganjil');

  const ganjilEvents = [
    { date: '14 - 16 Juli 2026', title: 'Masa Pengenalan Lingkungan Sekolah (MPLS) Siswa Baru', type: 'Kegiatan Awal' },
    { date: '17 Juli 2026', title: 'Awal Masuk Pembelajaran Efektif Semester Ganjil', type: 'Akademik' },
    { date: '17 Agustus 2026', title: 'Upacara HUT Kemerdekaan RI ke-81', type: 'Hari Libur Nasional' },
    { date: '21 - 26 September 2026', title: 'Asesmen Tengah Semester (ATS) Ganjil', type: 'Ujian / Asesmen' },
    { date: '19 - 24 Oktober 2026', title: 'Praktik Uji Coba Konfigurasi Lab TKJ Terpadu', type: 'Praktikum' },
    { date: '30 Nov - 05 Des 2026', title: 'Asesmen Akhir Semester (AAS) Ganjil', type: 'Ujian / Asesmen' },
    { date: '18 Desember 2026', title: 'Pembagian Buku Rapor Semester Ganjil', type: 'Rapor' },
    { date: '21 Des 2026 - 02 Jan 2027', title: 'Libur Akhir Semester Ganjil', type: 'Libur Sekolah' }
  ];

  const genapEvents = [
    { date: '04 Januari 2027', title: 'Awal Masuk Pembelajaran Efektif Semester Genap', type: 'Akademik' },
    { date: '11 Januari 2027', title: 'Pemberangkatan Siswa Praktik Kerja Lapangan (PKL) Kelas XI', type: 'PKL / Industri' },
    { date: '01 - 06 Maret 2027', title: 'Asesmen Tengah Semester (ATS) Genap', type: 'Ujian / Asesmen' },
    { date: '22 - 27 Maret 2027', title: 'Uji Kompetensi Keahlian (UKK) Mandiri TKJ Berstandar BNSP', type: 'Sertifikasi UKK' },
    { date: '05 - 10 April 2027', title: 'Ujian Sekolah (US) Kelas XII', type: 'Ujian / Asesmen' },
    { date: '07 - 12 Juni 2027', title: 'Asesmen Akhir Tahun (AAT) Kelas X & XI', type: 'Ujian / Asesmen' },
    { date: '25 Juni 2027', title: 'Pembagian Rapor Kenaikan Kelas & Kelulusan', type: 'Rapor' },
    { date: '28 Juni - 10 Juli 2027', title: 'Libur Akhir Tahun Pelajaran', type: 'Libur Sekolah' }
  ];

  return (
    <div className="space-y-14 pb-16">
      
      {/* Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-blue-900/60 text-sky-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-blue-700/60">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Pendidikan & Kurikulum</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-heading text-white">
            Informasi Akademik & Kalender Pendidikan
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Tahun Pelajaran {settings.activeAcademicYear} — Panduan jadwal belajar, asesmen terpadu, praktik lab TKJ, serta uji kompetensi siswa.
          </p>
        </div>
      </div>

      {/* Kalender Pendidikan Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 flex items-center gap-2">
                <Calendar className="w-6 h-6 text-blue-600" />
                <span>Kalender Pendidikan Tahun Ajaran {settings.activeAcademicYear}</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Disusun selaras dengan Dinas Pendidikan Provinsi Jawa Barat dan Kalender Pembelajaran Al-Bashry.
              </p>
            </div>

            {/* Toggle Ganjil / Genap */}
            <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button
                onClick={() => setActiveSem('ganjil')}
                className={`px-4 py-2 rounded-lg transition ${
                  activeSem === 'ganjil' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semester Ganjil
              </button>
              <button
                onClick={() => setActiveSem('genap')}
                className={`px-4 py-2 rounded-lg transition ${
                  activeSem === 'genap' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semester Genap
              </button>
            </div>
          </div>

          {/* Event Timeline Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <th className="py-3 px-4">Rentang Waktu</th>
                  <th className="py-3 px-4">Agenda / Kegiatan Sekolah</th>
                  <th className="py-3 px-4">Kategori</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(activeSem === 'ganjil' ? ganjilEvents : genapEvents).map((evt, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap">
                      {evt.date}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {evt.title}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-100">
                        {evt.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                        Terjadwal
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </section>

      {/* Mata Pelajaran Produktif TKJ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
            Struktur Mata Pelajaran
          </span>
          <h2 className="text-2xl font-bold font-heading text-slate-900 mt-2">
            Mata Pelajaran Kurikulum Kejuruan TKJ
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Kombinasi mata pelajaran umum berkarakter dan mata pelajaran kejuruan berbasis standar kompetensi kerja.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subjects.map(subj => (
            <div key={subj.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                    {subj.code}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    {subj.totalHours} Jam / Minggu
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-sm font-heading mb-1.5">
                  {subj.name}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {subj.description || 'Materi pembelajaran kurikulum nasional dan keahlian terpadu.'}
                </p>
              </div>
              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Pengampu: <strong className="text-slate-700">{subj.teacherName}</strong></span>
                <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-semibold">
                  Tingkat {subj.targetGrades.join(', ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Uji Kompetensi Keahlian (UKK) Highlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-950 px-3 py-1 rounded-full border border-amber-800">
                Standar Kelulusan Vokasi
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">
                Uji Kompetensi Keahlian (UKK) Berstandar Industri & BNSP
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Setiap siswa tingkat akhir wajib menempuh ujian praktik komprehensif di depan penguji internal dan asesor eksternal dari industri telekomunikasi (ISP). Tugas UKK meliputi rancang bangun topologi jaringan berbasis MikroTik, konfigurasi routing OSPF multi-subnet, deployment web server Debian dengan keamanan firewall, serta penyambungan kabel fiber optik di lapangan.
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                <span className="bg-slate-800 text-slate-200 text-xs px-3 py-1 rounded-full border border-slate-700">
                  ✓ Asesor Eksternal DUDI
                </span>
                <span className="bg-slate-800 text-slate-200 text-xs px-3 py-1 rounded-full border border-slate-700">
                  ✓ Sertifikat Keahlian Khusus
                </span>
                <span className="bg-slate-800 text-slate-200 text-xs px-3 py-1 rounded-full border border-slate-700">
                  ✓ Portofolio Teknis Siswa
                </span>
              </div>
            </div>

            <div className="lg:col-span-4 flex justify-center">
              <div className="bg-white/10 p-6 rounded-2xl border border-white/15 text-center">
                <ShieldCheck className="w-16 h-16 text-emerald-400 mx-auto mb-2" />
                <h4 className="font-bold text-white text-base font-heading">Akreditasi Kompetensi</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Pengakuan resmi atas keterampilan teknis riil yang siap pakai di dunia kerja.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
