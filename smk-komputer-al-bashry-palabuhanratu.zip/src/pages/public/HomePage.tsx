import React from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolLogo } from '../../components/SchoolLogo';
import { 
  ArrowRight, 
  CheckCircle2, 
  Server, 
  Cpu, 
  Wifi, 
  ShieldCheck, 
  Users, 
  Calendar, 
  Sparkles, 
  Layers, 
  Award,
  ChevronRight,
  Monitor,
  PhoneCall,
  GraduationCap
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { 
    settings, 
    students, 
    teachers, 
    newsList, 
    galleryList, 
    navigateToPublic, 
    setIsAuthModalOpen 
  } = useApp();

  const activeStudentCount = students.filter(s => s.status === 'aktif').length;
  const teacherCount = teachers.length;

  return (
    <div className="space-y-20 pb-16">
      
      {/* 1. HERO SECTION */}
      <section className="relative bg-[#071426] text-white overflow-hidden pt-12 pb-24 lg:pt-20 lg:pb-32 border-b border-slate-800">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none"></div>
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-sky-500/15 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Text column */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 bg-blue-900/60 border border-blue-700/50 text-blue-200 px-3.5 py-1.5 rounded-full text-xs font-semibold backdrop-blur-md">
                <Sparkles className="w-4 h-4 text-sky-400" />
                <span>Pusat Kejuruan Teknik Komputer & Jaringan Palabuhanratu</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-heading leading-tight text-white">
                Selamat Datang di <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-blue-300 to-white">
                  SMK Komputer Al-Bashry
                </span> <br />
                Palabuhanratu
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
                Mempersiapkan generasi yang kompeten, terampil, berkarakter, dan siap menghadapi perkembangan teknologi digital serta kebutuhan industri jaringan modern.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => navigateToPublic('tkj')}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-blue-600/30 flex items-center gap-2 transition transform hover:-translate-y-0.5"
                >
                  <Server className="w-4 h-4" />
                  <span>Program Keahlian TKJ</span>
                </button>

                <button
                  onClick={() => navigateToPublic('ppdb')}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition transform hover:-translate-y-0.5"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Informasi PPDB 2026</span>
                </button>

                <button
                  onClick={() => navigateToPublic('profil')}
                  className="bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-sm px-5 py-3.5 rounded-xl transition"
                >
                  Jelajahi Profil Sekolah
                </button>
              </div>

              {/* Fast trust stats */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800/80 max-w-lg">
                <div>
                  <div className="text-2xl font-extrabold text-white font-heading">100%</div>
                  <div className="text-xs text-slate-400">Praktik Lab Mandiri</div>
                </div>
                <div>
                  <div className="text-2xl font-extrabold text-sky-400 font-heading">MTCNA</div>
                  <div className="text-xs text-slate-400">Kurikulum Berlisensi</div>
                </div>
                <div>
                  <div className="text-2xl font-extrabold text-emerald-400 font-heading">ISP & DUDI</div>
                  <div className="text-xs text-slate-400">Mitra Magang Industri</div>
                </div>
              </div>

            </div>

            {/* Visual Hero Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border-2 border-slate-700/60 shadow-2xl bg-slate-900 group">
                <img
                  src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1000&q=80"
                  alt="Laboratorium Jaringan Komputer SMK Al-Bashry"
                  className="w-full h-80 sm:h-96 object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071426] via-transparent to-transparent"></div>
                
                {/* Overlay Badge */}
                <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-md p-4 rounded-xl border border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-blue-600 rounded-lg text-white">
                      <Cpu className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">Lab Fiber Optic & Cisco Router</p>
                      <p className="text-[11px] text-slate-400">Peralatan standar teknisi lapangan</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-sky-400 bg-sky-950 px-2 py-1 rounded border border-sky-800">
                    Aktif
                  </span>
                </div>
              </div>

              {/* Floating emblem stamp */}
              <div className="absolute -top-6 -left-6 bg-white p-2.5 rounded-full shadow-2xl border-2 border-amber-300 hidden sm:block animate-bounce [animation-duration:4s]">
                <SchoolLogo size={56} />
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. STATISTIK TERVERIFIKASI SEKOLAH */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-20">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200/80 p-6 sm:p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-y md:divide-y-0 md:divide-x divide-slate-100">
            
            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#0B1F3A] font-heading">
                {activeStudentCount}
              </div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                Siswa Aktif Terdaftar
              </p>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#0B1F3A] font-heading">
                {teacherCount}
              </div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                Guru & Tenaga Kependidikan
              </p>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#0B1F3A] font-heading">
                3 Lab
              </div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                Laboratorium Komputer & Jaringan
              </p>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-blue-600 font-heading">
                {settings.accreditation}
              </div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                Status Akreditasi Resmi
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* 3. SAMBUTAN KEPALA SEKOLAH */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-3xl p-8 sm:p-12 border border-slate-200">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-4 flex flex-col items-center text-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80"
                  alt="Kepala Sekolah SMK Komputer Al-Bashry"
                  className="w-48 h-48 sm:w-56 sm:h-56 object-cover rounded-2xl shadow-lg border-4 border-white"
                />
                <div className="absolute -bottom-3 bg-[#0B1F3A] text-white px-3 py-1 rounded-full text-xs font-bold shadow">
                  Kepala Sekolah
                </div>
              </div>
              <h3 className="text-base font-extrabold text-slate-900 mt-5 font-heading">
                {settings.headmasterName}
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                NIP. {settings.headmasterNip}
              </p>
            </div>

            <div className="lg:col-span-8 space-y-4">
              <div className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-100/70 px-3 py-1 rounded-full">
                Sambutan Kepala Sekolah
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
                Mencetak Teknisi Jaringan Berdaya Saing Global & Berakhlak Mulia
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed">
                <em>Assalamu’alaikum Warahmatullahi Wabarakatuh.</em><br />
                Selamat datang di website resmi SMK Komputer Al-Bashry Palabuhanratu. Di tengah pesatnya laju transformasi teknologi informasi, kami hadir sebagai kawah candradimuka bagi generasi muda Kabupaten Sukabumi untuk menguasai kompetensi nyata di bidang Teknik Komputer dan Jaringan (TKJ).
              </p>
              <p className="text-slate-600 text-sm leading-relaxed">
                Pembelajaran kami dirancang mengedepankan praktik langsung pada perangkat jaringan nyata (hardware networking, router Cisco, MikroTik, fiber optic splicer, dan server Linux). Kami bertekad mendidik siswa tidak hanya pintar secara teknis (hard skills), namun juga santun, beretika, dan memiliki integritas tinggi.
              </p>

              <div className="pt-2">
                <button
                  onClick={() => navigateToPublic('profil')}
                  className="inline-flex items-center gap-2 text-sm font-bold text-blue-600 hover:text-blue-800 transition"
                >
                  <span>Baca Selengkapnya Profil & Visi Misi</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. PROGRAM KEAHLIAN TEKNIK KOMPUTER & JARINGAN (TKJ) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold tracking-wider uppercase text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
            Fokus Kejuruan Utama
          </span>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading mt-3">
            Teknik Komputer dan Jaringan (TKJ)
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Kurikulum berbasis praktik industri yang membekali siswa dengan keahlian teknisi komputer, perancang jaringan skala luas, dan administrator server.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:shadow-md transition">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4">
              <Cpu className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-lg mb-2 font-heading">
              Hardware & Dasar Komputer
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Keahlian merakit komputer desktop, diagnosa kerusakan hardware, instalasi multi-OS (Linux & Windows), dan troubleshooting peripheral.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:shadow-md transition">
            <div className="w-12 h-12 bg-sky-100 text-sky-600 rounded-xl flex items-center justify-center mb-4">
              <Wifi className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-lg mb-2 font-heading">
              Infrastruktur & Routing
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Konfigurasi Switch VLAN, Static & Dynamic Routing (OSPF, BGP), Wireless Distribution System, dan Manajemen Bandwidth MikroTik.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:shadow-md transition">
            <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center mb-4">
              <Server className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-lg mb-2 font-heading">
              Sistem Server & Fiber Optik
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Administrasi Linux Debian server (DNS, Web, Mail, FTP), penyambungan kabel fiber optik dengan fusion splicer, dan instalasi VoIP.
            </p>
          </div>

        </div>

        <div className="mt-8 text-center">
          <button
            onClick={() => navigateToPublic('tkj')}
            className="inline-flex items-center gap-2 bg-[#0B1F3A] hover:bg-blue-900 text-white font-bold text-sm px-6 py-3 rounded-xl shadow transition"
          >
            <span>Lihat Silabus & Praktik Lab TKJ Lengkap</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 5. FASILITAS LABORATORIUM UNGGULAN */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs font-bold tracking-wider uppercase text-sky-400 bg-sky-950 px-3 py-1 rounded-full border border-sky-800">
                Fasilitas Pembelajaran
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-white mt-2">
                Laboratorium Komputer & Praktik Modern
              </h2>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm max-w-md">
              Setiap siswa mendapatkan akses ke perangkat jaringan nyata untuk mengasah keterampilan teknis langsung.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <div className="bg-slate-800/80 rounded-2xl overflow-hidden border border-slate-700">
              <img
                src="https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=600&q=80"
                alt="Lab Perakitan Komputer"
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="font-bold text-white text-base font-heading">Lab Perakitan & Maintenance</h3>
                <p className="text-xs text-slate-300 mt-1">
                  Dilengkapi toolbox lengkap, POST diagnostic card, power supply tester, dan ragam motherboard untuk praktik bedah hardware.
                </p>
              </div>
            </div>

            <div className="bg-slate-800/80 rounded-2xl overflow-hidden border border-slate-700">
              <img
                src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=600&q=80"
                alt="Lab Fiber Optik & Splicer"
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="font-bold text-white text-base font-heading">Lab Fiber Optic & Telekomunikasi</h3>
                <p className="text-xs text-slate-300 mt-1">
                  Penyambung fusi serat optik otomatis, Optical Time-Domain Reflectometer (OTDR), dan visual fault locator.
                </p>
              </div>
            </div>

            <div className="bg-slate-800/80 rounded-2xl overflow-hidden border border-slate-700">
              <img
                src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80"
                alt="Lab Cisco & Mikrotik"
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="font-bold text-white text-base font-heading">Lab Cisco, MikroTik & Server</h3>
                <p className="text-xs text-slate-300 mt-1">
                  Rak server berpendingin dengan routerboard seri RB750Gr3, switch manageable, serta server fisik Debian dan Proxmox VE.
                </p>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 6. BERITA & AGENDA SEKOLAH */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold tracking-wider uppercase text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              Kabar Terbaru
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading mt-1">
              Berita & Informasi Sekolah
            </h2>
          </div>
          <button
            onClick={() => navigateToPublic('berita')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 transition"
          >
            <span>Lihat Semua Berita</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newsList.slice(0, 3).map(article => (
            <article 
              key={article.id}
              onClick={() => navigateToPublic('berita-detail', article.slug)}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition cursor-pointer flex flex-col group"
            >
              <div className="relative overflow-hidden h-44 bg-slate-100">
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 left-3 bg-[#0B1F3A]/90 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                  {article.category}
                </span>
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] text-slate-400 font-medium mb-1.5 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{article.publishedAt}</span>
                    <span>•</span>
                    <span>{article.author}</span>
                  </div>
                  <h3 className="font-extrabold text-slate-900 text-sm group-hover:text-blue-600 transition line-clamp-2 font-heading">
                    {article.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                    {article.summary}
                  </p>
                </div>
                <div className="pt-4 mt-3 border-t border-slate-100 text-xs font-bold text-blue-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Baca Artikel</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* 7. GALERI KEGIATAN SISWA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold tracking-wider uppercase text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              Dokumentasi
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading mt-1">
              Galeri Praktik & Kegiatan Siswa
            </h2>
          </div>
          <button
            onClick={() => navigateToPublic('galeri')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 transition"
          >
            <span>Buka Galeri Foto</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryList.slice(0, 4).map(item => (
            <div
              key={item.id}
              onClick={() => navigateToPublic('galeri')}
              className="relative rounded-xl overflow-hidden aspect-4/3 cursor-pointer group shadow-xs"
            >
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-end">
                <span className="text-[10px] font-bold text-sky-300 uppercase">{item.category}</span>
                <p className="text-xs font-bold text-white line-clamp-1">{item.title}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. PPDB CALL TO ACTION BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-[#0B1F3A] to-[#1E3A8A] rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-4">
            <span className="inline-block text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-3 py-1 rounded-full">
              Penerimaan Siswa Baru {settings.ppdbYear}
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold font-heading text-white">
              Siap Menjadi Ahli Jaringan Komputer & Administrator Server Masa Depan?
            </h2>
            <p className="text-slate-200 text-xs sm:text-sm leading-relaxed">
              Daftarkan diri Anda secara online untuk Program Keahlian Teknik Komputer dan Jaringan. Kuota terbatas hanya 108 siswa (3 rombel) untuk menjaga rasio praktik lab 1 siswa 1 perangkat!
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => navigateToPublic('ppdb')}
                className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm px-6 py-3 rounded-xl shadow-lg transition"
              >
                Daftar PPDB Online Sekarang
              </button>
              <button
                onClick={() => navigateToPublic('kontak')}
                className="bg-white/10 hover:bg-white/20 text-white font-semibold text-sm px-5 py-3 rounded-xl transition"
              >
                Konsultasi WhatsApp Panitia
              </button>
            </div>
          </div>
          
          <div className="absolute -right-16 -bottom-16 opacity-10 pointer-events-none hidden md:block">
            <SchoolLogo size={340} />
          </div>
        </div>
      </section>

    </div>
  );
};
