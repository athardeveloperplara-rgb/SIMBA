import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolLogo } from '../../components/SchoolLogo';
import { PPDBApplication } from '../../types';
import { 
  GraduationCap, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  FileText, 
  HelpCircle, 
  Phone, 
  Search, 
  Printer, 
  AlertCircle, 
  Upload, 
  UserCheck,
  ShieldCheck,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export const PpdbPage: React.FC = () => {
  const { settings, ppdbList, submitPPDB } = useApp();
  const [activeTab, setActiveTab] = useState<'info' | 'daftar' | 'status' | 'faq'>('info');

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    nisn: '',
    gender: 'L' as 'L' | 'P',
    birthPlace: 'Palabuhanratu',
    birthDate: '2011-05-15',
    address: '',
    previousSchool: '',
    graduationYear: '2026',
    parentName: '',
    parentPhone: '',
    email: '',
    chosenMajor: 'Teknik Komputer dan Jaringan (TKJ)',
    agreePrivacy: false,
    docs: {
      ijazahOrSkl: true,
      kartuKeluarga: true,
      aktaKelahiran: true,
      pasFoto: true,
      raporSmp: true
    }
  });

  const [formSuccessNumber, setFormSuccessNumber] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Status Search State
  const [searchRegNumber, setSearchRegNumber] = useState('');
  const [searchedApp, setSearchedApp] = useState<PPDBApplication | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.fullName.trim() || !formData.address.trim() || !formData.previousSchool.trim() || !formData.parentPhone.trim()) {
      setFormError('Mohon lengkapi semua kolom wajib dengan data yang benar.');
      return;
    }

    if (!formData.agreePrivacy) {
      setFormError('Anda harus menyetujui pemrosesan data pribadi untuk pendaftaran.');
      return;
    }

    const newRegNum = submitPPDB({
      fullName: formData.fullName,
      nisn: formData.nisn || '0000000000',
      gender: formData.gender,
      birthPlace: formData.birthPlace,
      birthDate: formData.birthDate,
      address: formData.address,
      previousSchool: formData.previousSchool,
      graduationYear: formData.graduationYear,
      parentName: formData.parentName,
      parentPhone: formData.parentPhone,
      email: formData.email,
      chosenMajor: formData.chosenMajor,
      documentsUploaded: formData.docs
    });

    setFormSuccessNumber(newRegNum);
  };

  const handleSearchStatus = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError(null);
    setSearchedApp(null);

    const query = searchRegNumber.trim().toUpperCase();
    if (!query) {
      setSearchError('Masukkan nomor pendaftaran.');
      return;
    }

    const found = ppdbList.find(p => p.registrationNumber.toUpperCase() === query);
    if (found) {
      setSearchedApp(found);
    } else {
      setSearchError(`Nomor registrasi "${query}" tidak ditemukan. Pastikan format sesuai (Contoh: PPDB-2026-TKJ-001).`);
    }
  };

  const printSlip = (app: PPDBApplication) => {
    window.print();
  };

  return (
    <div className="space-y-12 pb-20">
      
      {/* Header Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-emerald-950 text-emerald-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-emerald-800">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Penerimaan Peserta Didik Baru (PPDB)</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white">
            PPDB Online Tahun Ajaran {settings.ppdbYear}
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Bergabunglah bersama SMK Komputer Al-Bashry Palabuhanratu. Kuota terbatas hanya 108 calon siswa (3 rombel) untuk program keahlian Teknik Komputer dan Jaringan.
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 no-print">
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2 text-xs sm:text-sm font-bold">
          <button
            onClick={() => setActiveTab('info')}
            className={`px-5 py-2.5 rounded-xl transition whitespace-nowrap ${
              activeTab === 'info' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Informasi & Alur PPDB
          </button>
          <button
            onClick={() => {
              setActiveTab('daftar');
              setFormSuccessNumber(null);
            }}
            className={`px-5 py-2.5 rounded-xl transition whitespace-nowrap ${
              activeTab === 'daftar' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-emerald-700 hover:bg-emerald-50'
            }`}
          >
            Formulir Pendaftaran Online
          </button>
          <button
            onClick={() => setActiveTab('status')}
            className={`px-5 py-2.5 rounded-xl transition whitespace-nowrap ${
              activeTab === 'status' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Cek Status Pendaftaran & Cetak Bukti
          </button>
          <button
            onClick={() => setActiveTab('faq')}
            className={`px-5 py-2.5 rounded-xl transition whitespace-nowrap ${
              activeTab === 'faq' ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            FAQ & Tanya Jawab
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* TAB 1: INFORMASI PPDB */}
        {activeTab === 'info' && (
          <div className="space-y-10 animate-in fade-in duration-200">
            {/* Quick Timeline Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded uppercase">Gelombang 1</span>
                <h3 className="text-lg font-bold font-heading text-slate-900 mt-2">Pendaftaran Jalur Minat & Prestasi</h3>
                <p className="text-xs text-slate-500 mt-1">1 Oktober 2026 – 28 Februari 2027</p>
                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600">
                  Bebas biaya tes seleksi + potongan biaya seragam praktik wearpack TKJ.
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded uppercase">Gelombang 2</span>
                <h3 className="text-lg font-bold font-heading text-slate-900 mt-2">Pendaftaran Jalur Reguler</h3>
                <p className="text-xs text-slate-500 mt-1">1 Maret 2027 – 10 Juli 2027</p>
                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600">
                  Pendaftaran ditutup sewaktu-waktu jika kuota 108 siswa telah terpenuhi.
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded uppercase">Daftar Ulang & MPLS</span>
                <h3 className="text-lg font-bold font-heading text-slate-900 mt-2">Verifikasi Fisik & MPLS</h3>
                <p className="text-xs text-slate-500 mt-1">12 – 16 Juli 2027</p>
                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600">
                  Pengambilan perlengkapan sekolah dan orientasi laboratorium komputer.
                </div>
              </div>
            </div>

            {/* Requirements & Flow */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Syarat Pendaftaran */}
              <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-lg font-bold font-heading text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <span>Syarat & Berkas Pendaftaran</span>
                </h3>
                <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>Lulusan SMP / MTs / Sederajat atau siswa kelas IX yang akan lulus tahun 2026/2027.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>Fotokopi Ijazah / Surat Keterangan Lulus (SKL) yang dilegalisir (2 lembar).</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>Fotokopi Kartu Keluarga (KK) dan Akta Kelahiran (2 lembar).</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>Pas foto formal ukuran 3x4 latar belakang merah (4 lembar).</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>Tidak buta warna (untuk kelancaran membaca kode warna kabel jaringan UTP & fiber optic).</span>
                  </li>
                </ul>
              </div>

              {/* Alur Pendaftaran */}
              <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-lg font-bold font-heading text-slate-900 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span>Alur Pendaftaran Online</span>
                </h3>
                <div className="space-y-3 text-xs sm:text-sm text-slate-600">
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center flex-shrink-0 text-xs">1</span>
                    <p><strong>Pengisian Formulir:</strong> Isi biodata lengkap secara online dan dapatkan Nomor Registrasi unik.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center flex-shrink-0 text-xs">2</span>
                    <p><strong>Verifikasi Berkas:</strong> Panitia PPDB memverifikasi data dan dokumen pendukung.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center flex-shrink-0 text-xs">3</span>
                    <p><strong>Cek Kelulusan:</strong> Pantau status kelulusan berkala melalui menu "Cek Status" menggunakan Nomor Registrasi.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center flex-shrink-0 text-xs">4</span>
                    <p><strong>Daftar Ulang:</strong> Cetak Bukti Pendaftaran dan serahkan berkas fisik ke Sekretariat PPDB sekolah.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct CTA */}
            <div className="p-8 rounded-3xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div>
                <h4 className="text-lg font-bold font-heading text-emerald-950">
                  Siap Melangkah Bersama SMK Komputer Al-Bashry?
                </h4>
                <p className="text-xs text-emerald-800 mt-1">
                  Pengisian formulir online hanya memakan waktu 3 menit. Dapatkan bukti registrasi resmi sekarang juga.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('daftar')}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition flex items-center gap-2 whitespace-nowrap"
              >
                <span>Buka Formulir Pendaftaran</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: FORMULIR ONLINE */}
        {activeTab === 'daftar' && (
          <div className="max-w-3xl mx-auto animate-in fade-in duration-200">
            {formSuccessNumber ? (
              <div className="bg-white rounded-3xl p-8 border border-emerald-200 shadow-lg text-center space-y-5">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-extrabold font-heading text-slate-900">
                  Pendaftaran Online Berhasil!
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                  Data calon siswa telah tersimpan di pangkalan data PPDB SMK Komputer Al-Bashry Palabuhanratu.
                </p>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl max-w-sm mx-auto">
                  <span className="text-xs text-slate-500 block mb-1">Nomor Registrasi Anda:</span>
                  <span className="text-xl font-mono font-extrabold text-blue-600 tracking-wider">
                    {formSuccessNumber}
                  </span>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Simpan nomor ini untuk pengecekan status kelulusan dan cetak kartu.
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      setSearchRegNumber(formSuccessNumber);
                      setActiveTab('status');
                      const found = ppdbList.find(p => p.registrationNumber === formSuccessNumber);
                      if (found) setSearchedApp(found);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow transition"
                  >
                    Lihat Bukti Pendaftaran & Cetak
                  </button>
                  <button
                    onClick={() => {
                      setFormSuccessNumber(null);
                      setFormData({
                        ...formData,
                        fullName: '',
                        address: '',
                        previousSchool: ''
                      });
                    }}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs px-4 py-2.5 rounded-xl transition"
                  >
                    Daftar Calon Siswa Lain
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-sm space-y-6">
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold font-heading text-slate-900">
                    Formulir Registrasi Calon Siswa Baru
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Isi data diri dengan akurat sesuai Kartu Keluarga (KK) dan Ijazah SMP/MTs.
                  </p>
                </div>

                {formError && (
                  <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-500" />
                    <span>{formError}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                  
                  {/* Calon Siswa */}
                  <div className="space-y-4 pt-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-100 pb-2">
                      A. Identitas Calon Peserta Didik
                    </h4>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Nama Lengkap Siswa *
                      </label>
                      <input
                        type="text"
                        value={formData.fullName}
                        onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder="Contoh: Muhammad Farhan Maulana"
                        required
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          NISN (Nomor Induk Siswa Nasional)
                        </label>
                        <input
                          type="text"
                          value={formData.nisn}
                          onChange={e => setFormData({ ...formData, nisn: e.target.value })}
                          placeholder="10 digit nomor NISN"
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Jenis Kelamin *
                        </label>
                        <select
                          value={formData.gender}
                          onChange={e => setFormData({ ...formData, gender: e.target.value as 'L' | 'P' })}
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        >
                          <option value="L">Laki-laki</option>
                          <option value="P">Perempuan</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Tempat Lahir *
                        </label>
                        <input
                          type="text"
                          value={formData.birthPlace}
                          onChange={e => setFormData({ ...formData, birthPlace: e.target.value })}
                          required
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Tanggal Lahir *
                        </label>
                        <input
                          type="date"
                          value={formData.birthDate}
                          onChange={e => setFormData({ ...formData, birthDate: e.target.value })}
                          required
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Alamat Domisili Lengkap *
                      </label>
                      <textarea
                        rows={2}
                        value={formData.address}
                        onChange={e => setFormData({ ...formData, address: e.target.value })}
                        placeholder="Nama jalan, RT/RW, Dusun, Desa/Kelurahan, Kecamatan Palabuhanratu"
                        required
                        className="w-full px-3.5 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Asal Sekolah */}
                  <div className="space-y-4 pt-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-100 pb-2">
                      B. Asal Sekolah & Pilihan Jurusan
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Nama Asal SMP / MTs *
                        </label>
                        <input
                          type="text"
                          value={formData.previousSchool}
                          onChange={e => setFormData({ ...formData, previousSchool: e.target.value })}
                          placeholder="Contoh: SMP Negeri 1 Palabuhanratu"
                          required
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Tahun Lulus
                        </label>
                        <input
                          type="text"
                          value={formData.graduationYear}
                          onChange={e => setFormData({ ...formData, graduationYear: e.target.value })}
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Program Keahlian Dipilih *
                      </label>
                      <input
                        type="text"
                        readOnly
                        value="Teknik Komputer dan Jaringan (TKJ)"
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-blue-50/60 border border-blue-200 text-blue-900 font-bold rounded-xl"
                      />
                    </div>
                  </div>

                  {/* Kontak Orang Tua */}
                  <div className="space-y-4 pt-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-100 pb-2">
                      C. Data Orang Tua / Wali & Kontak
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Nama Orang Tua / Wali *
                        </label>
                        <input
                          type="text"
                          value={formData.parentName}
                          onChange={e => setFormData({ ...formData, parentName: e.target.value })}
                          placeholder="Nama lengkap ayah/ibu/wali"
                          required
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          No. WhatsApp Aktif *
                        </label>
                        <input
                          type="tel"
                          value={formData.parentPhone}
                          onChange={e => setFormData({ ...formData, parentPhone: e.target.value })}
                          placeholder="Contoh: 0812-3456-7890"
                          required
                          className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Email (Opsional)
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        placeholder="email.aktif@gmail.com"
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Checklist Berkas */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                    <span className="text-xs font-bold text-slate-800 block">
                      D. Kesiapan Berkas yang Dimiliki:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.docs.ijazahOrSkl}
                          onChange={e => setFormData({ ...formData, docs: { ...formData.docs, ijazahOrSkl: e.target.checked } })}
                          className="rounded text-blue-600"
                        />
                        <span>Ijazah / SKL SMP</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.docs.kartuKeluarga}
                          onChange={e => setFormData({ ...formData, docs: { ...formData.docs, kartuKeluarga: e.target.checked } })}
                          className="rounded text-blue-600"
                        />
                        <span>Kartu Keluarga (KK)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.docs.aktaKelahiran}
                          onChange={e => setFormData({ ...formData, docs: { ...formData.docs, aktaKelahiran: e.target.checked } })}
                          className="rounded text-blue-600"
                        />
                        <span>Akta Kelahiran</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.docs.pasFoto}
                          onChange={e => setFormData({ ...formData, docs: { ...formData.docs, pasFoto: e.target.checked } })}
                          className="rounded text-blue-600"
                        />
                        <span>Pas Foto 3x4 (Latar Merah)</span>
                      </label>
                    </div>
                  </div>

                  {/* Persetujuan Privasi */}
                  <div className="pt-2">
                    <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-600 leading-relaxed">
                      <input
                        type="checkbox"
                        checked={formData.agreePrivacy}
                        onChange={e => setFormData({ ...formData, agreePrivacy: e.target.checked })}
                        className="mt-0.5 rounded text-blue-600"
                      />
                      <span>
                        Saya menyatakan data yang diisikan adalah benar dan bersedia mematuhi segala tata tertib Penerimaan Peserta Didik Baru SMK Komputer Al-Bashry Palabuhanratu.
                      </span>
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl shadow-md transition text-xs sm:text-sm flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                    <span>Kirim Formulir Pendaftaran PPDB</span>
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: CEK STATUS PENDAFTARAN & CETAK */}
        {activeTab === 'status' && (
          <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-200">
            
            {/* Search Input Box */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4 no-print">
              <h3 className="text-lg font-bold font-heading text-slate-900">
                Pengecekan Status Seleksi PPDB
              </h3>
              <p className="text-xs text-slate-500">
                Masukkan Nomor Registrasi yang Anda dapatkan saat mendaftar online (Contoh: <code className="text-blue-600 font-mono font-bold">PPDB-2026-TKJ-001</code>).
              </p>

              <form onSubmit={handleSearchStatus} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchRegNumber}
                    onChange={e => setSearchRegNumber(e.target.value)}
                    placeholder="Contoh: PPDB-2026-TKJ-001"
                    className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition"
                >
                  Periksa
                </button>
              </form>

              {searchError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                  {searchError}
                </div>
              )}
            </div>

            {/* Application Detail Card */}
            {searchedApp && (
              <div className="bg-white rounded-3xl border-2 border-slate-300 shadow-xl overflow-hidden print:border-none print:shadow-none">
                
                {/* Official Letterhead Header for Print & Display */}
                <div className="bg-[#0B1F3A] text-white p-6 sm:p-8 flex items-center justify-between gap-4 border-b-4 border-amber-400 print:bg-white print:text-slate-900 print:border-b-2 print:border-black">
                  <div className="flex items-center gap-4">
                    <div className="bg-white p-1 rounded-full shadow-md">
                      <SchoolLogo size={56} />
                    </div>
                    <div>
                      <h4 className="text-lg sm:text-xl font-extrabold font-heading text-white print:text-black">
                        SMK KOMPUTER AL-BASHRY
                      </h4>
                      <p className="text-xs text-sky-200 print:text-slate-600 font-semibold">
                        PANITIA PENERIMAAN PESERTA DIDIK BARU (PPDB) TAHUN {settings.ppdbYear}
                      </p>
                      <p className="text-[11px] text-slate-300 print:text-slate-500">
                        {settings.address}, {settings.city} — Telp: {settings.phone}
                      </p>
                    </div>
                  </div>

                  <div className="no-print">
                    <button
                      onClick={() => printSlip(searchedApp)}
                      className="inline-flex items-center gap-1.5 bg-white text-slate-900 hover:bg-slate-100 px-3.5 py-2 rounded-xl text-xs font-bold shadow transition"
                    >
                      <Printer className="w-4 h-4 text-blue-600" />
                      <span>Cetak Bukti Pendaftaran</span>
                    </button>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-6 sm:p-8 space-y-6">
                  
                  {/* Status Banner */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-200 gap-3">
                    <div>
                      <span className="text-xs text-slate-500 block">Status Hasil Verifikasi:</span>
                      <span className={`text-base font-extrabold font-heading ${
                        searchedApp.status === 'Diterima' ? 'text-emerald-600' :
                        searchedApp.status === 'Terverifikasi' ? 'text-blue-600' :
                        searchedApp.status === 'Perlu Perbaikan' ? 'text-amber-600' : 'text-slate-700'
                      }`}>
                        {searchedApp.status}
                      </span>
                    </div>

                    <div className="text-left sm:text-right">
                      <span className="text-xs text-slate-500 block">Nomor Registrasi:</span>
                      <span className="text-base font-mono font-bold text-slate-900">
                        {searchedApp.registrationNumber}
                      </span>
                    </div>
                  </div>

                  {/* Verification Notes */}
                  {searchedApp.notes && (
                    <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900">
                      <strong>Catatan Petugas Panitia:</strong> {searchedApp.notes}
                    </div>
                  )}

                  {/* Bio Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Nama Lengkap Siswa:</span>
                      <span className="font-bold text-slate-900">{searchedApp.fullName}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">NISN:</span>
                      <span className="font-mono font-bold text-slate-900">{searchedApp.nisn}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Tempat, Tanggal Lahir:</span>
                      <span className="font-medium text-slate-900">{searchedApp.birthPlace}, {searchedApp.birthDate}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Jenis Kelamin:</span>
                      <span className="font-medium text-slate-900">{searchedApp.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Asal SMP / MTs:</span>
                      <span className="font-medium text-slate-900">{searchedApp.previousSchool}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Program Keahlian:</span>
                      <span className="font-bold text-blue-600">{searchedApp.chosenMajor}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Nama Orang Tua / Wali:</span>
                      <span className="font-medium text-slate-900">{searchedApp.parentName}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-500 block text-xs">Kontak WhatsApp:</span>
                      <span className="font-mono font-medium text-slate-900">{searchedApp.parentPhone}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 sm:col-span-2">
                      <span className="text-slate-500 block text-xs">Alamat Domisili:</span>
                      <span className="font-medium text-slate-900">{searchedApp.address}</span>
                    </div>
                  </div>

                  {/* Signatures for Print */}
                  <div className="pt-8 border-t border-slate-200 grid grid-cols-2 text-center text-xs text-slate-700">
                    <div>
                      <p>Calon Peserta Didik,</p>
                      <div className="h-16"></div>
                      <p className="font-bold underline">{searchedApp.fullName}</p>
                    </div>
                    <div>
                      <p>Palabuhanratu, {searchedApp.registrationDate}</p>
                      <p>Panitia PPDB Al-Bashry,</p>
                      <div className="h-16"></div>
                      <p className="font-bold underline">Petugas Pendaftaran</p>
                    </div>
                  </div>

                </div>

              </div>
            )}
          </div>
        )}

        {/* TAB 4: FAQ & TANYA JAWAB */}
        {activeTab === 'faq' && (
          <div className="max-w-3xl mx-auto space-y-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-2">
              <h4 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-blue-600" />
                <span>Apakah pendaftaran PPDB Al-Bashry dipungut biaya?</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed pl-6">
                Pendaftaran online dan tes potensi awal tidak dipungut biaya (gratis). Biaya pendidikan hanya mencakup administrasi seragam khusus wearpack lab, iuran komite, dan perlengkapan praktik saat dinyatakan diterima.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-2">
              <h4 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-blue-600" />
                <span>Berapa kuota penerimaan siswa baru tahun ini?</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed pl-6">
                Untuk menjamin kualitas praktikum laboratorium komputer jaringan 1 siswa 1 perangkat, kuota kami batasi sebanyak 3 rombongan belajar (maksimal 108 siswa).
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-2">
              <h4 className="font-bold text-slate-900 text-sm font-heading flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-blue-600" />
                <span>Apakah harus memiliki laptop sendiri untuk masuk jurusan TKJ?</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed pl-6">
                Tidak wajib. Sekolah menyediakan 3 laboratorium komputer dengan unit komputer PC desktop, workstation server, dan router lengkap yang dapat digunakan siswa selama praktikum maupun di luar jam pelajaran.
              </p>
            </div>

            <div className="p-6 bg-slate-900 text-white rounded-2xl text-center space-y-3">
              <h4 className="text-base font-bold font-heading text-white">Butuh Informasi Lebih Lanjut?</h4>
              <p className="text-xs text-slate-300">
                Hubungi Panitia Penerimaan Siswa Baru melalui WhatsApp atau kunjungi langsung kampus sekolah.
              </p>
              <a
                href={`https://wa.me/62${settings.whatsapp.replace(/[^0-9]/g, '').slice(1)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs shadow transition"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Chat WhatsApp Panitia ({settings.whatsapp})</span>
              </a>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
