import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Server, 
  Cpu, 
  Wifi, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Terminal, 
  Award, 
  Briefcase, 
  GraduationCap, 
  Cable, 
  HardDrive,
  Workflow,
  Globe2,
  Lock
} from 'lucide-react';

export const TkjPage: React.FC = () => {
  const { navigateToPublic } = useApp();

  const competencies = [
    {
      title: 'Perakitan & Pemeliharaan Komputer',
      icon: Cpu,
      desc: 'Arsitektur PC modern, pemilihan komponen prosesor, RAM, motherboard, GPU, PSU, pengujian hardware benchmark, dan diagnosa kerusakan komputer.'
    },
    {
      title: 'Instalasi Sistem Operasi & Virtualisasi',
      icon: HardDrive,
      desc: 'Instalasi multi-boot Linux Debian/Ubuntu Server, Windows 11 Pro, manajemen partisi GPT/MBR, serta virtualisasi bare-metal menggunakan Proxmox VE dan VMware ESXi.'
    },
    {
      title: 'Pengkabelan LAN, WLAN & Fiber Optik',
      icon: Cable,
      desc: 'Crimping kabel UTP Cat5e/Cat6 standar T568A/T568B, fluking kabel, penyambungan core kabel fiber optik dengan fusion splicer, dan pengukuran redaman dengan OTDR/OPM.'
    },
    {
      title: 'Pengalamatan IP & Subnetting CIDR',
      icon: Terminal,
      desc: 'Keahlian kalkulasi IPv4 (Classless Inter-Domain Routing / VLSM), perancangan topologi IP hierarki, konfigurasi gateway, DHCP Server, serta pengenalan IPv6.'
    },
    {
      title: 'Konfigurasi Switch Manageable & VLAN',
      icon: Layers,
      desc: 'Penerapan Virtual LAN (VLAN), 802.1Q Trunking, Spanning Tree Protocol (STP), Port Security, dan Inter-VLAN Routing pada switch manageable Cisco dan D-Link.'
    },
    {
      title: 'Konfigurasi Router MikroTik & Cisco',
      icon: Wifi,
      desc: 'Static Routing, Dynamic Routing (OSPF & BGP), Network Address Translation (NAT/Masquerade), Firewall Filter Rules, Mangle, serta Bandwidth Queue Tree.'
    },
    {
      title: 'Administrasi Server & Layanan Jaringan',
      icon: Server,
      desc: 'Deployment DNS Server (BIND9), Web Server (Apache/Nginx dengan SSL/TLS), Database (MySQL/PostgreSQL), Mail Server (Postfix), FTP Server, dan SAMBA File Sharing.'
    },
    {
      title: 'Teknologi Layanan Jaringan & VoIP',
      icon: Globe2,
      desc: 'Protokol komunikasi suara (SIP), instalasi server VoIP Asterisk/FreePBX, konfigurasi IP Phone, softphone Zoiper, dan integrasi dial plan komunikasi kantor.'
    },
    {
      title: 'Keamanan Jaringan & Troubleshooting',
      icon: Lock,
      desc: 'Deteksi ancaman DoS/DDoS, Port Scanning analysis (Nmap & Wireshark), pengamanan akses Wi-Fi (WPA3-Enterprise), backup konfigurasi otomatis, dan metodologi troubleshooting jaringan.'
    }
  ];

  const careerPaths = [
    {
      title: 'Network Administrator / Teknisi Jaringan',
      desc: 'Mengelola, memelihara, dan memastikan konektivitas jaringan kantor, sekolah, atau perhotelan beroperasi 24/7 tanpa gangguan.'
    },
    {
      title: 'Teknisi Fiber Optik & ISP Engineer',
      desc: 'Melakukan instalasi tiang, penarikan kabel drop core, splicing sambungan optik, dan penanganan gangguan koneksi internet pelanggan ISP.'
    },
    {
      title: 'Junior Linux System Administrator',
      desc: 'Mengelola server hosting, pemantauan utilitas CPU/RAM, backup basis data, dan konfigurasi layanan cloud dasar.'
    },
    {
      title: 'IT Helpdesk & Technical Support Specialist',
      desc: 'Memberikan bantuan teknis bagi pengguna komputer, instalasi software, konfigurasi printer jaringan, dan perbaikan perangkat kerja.'
    },
    {
      title: 'Wirausaha Penyedia Jasa IT & RT/RW Net',
      desc: 'Membuka usaha mandiri servis laptop/PC, instalasi CCTV online, perancangan hotspot voucher Kafe, atau penyedia jaringan lokal.'
    },
    {
      title: 'Melanjutkan ke Perguruan Tinggi',
      desc: 'Memiliki fondasi kuat untuk kuliah di program studi Teknik Informatika, Ilmu Komputer, Sistem Informasi, atau Teknik Telekomunikasi.'
    }
  ];

  return (
    <div className="space-y-16 pb-20">
      
      {/* Header Banner */}
      <section className="bg-gradient-to-br from-[#071426] via-[#0B1F3A] to-[#1E3A8A] text-white py-16 border-b border-slate-800 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-4">
          <span className="inline-flex items-center gap-1.5 bg-blue-500/20 text-sky-300 px-3.5 py-1 rounded-full text-xs font-bold border border-blue-400/30">
            <Server className="w-3.5 h-3.5 text-sky-400" />
            Program Keahlian Unggulan
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white">
            Teknik Komputer dan Jaringan (TKJ)
          </h1>
          <p className="text-sm sm:text-base text-slate-300 max-w-3xl leading-relaxed">
            Menghasilkan teknisi jaringan komputer profesional yang tangguh, menguasai infrastruktur kabel tembaga & fiber optik, routerboard industri, server Linux, serta keamanan sistem jaringan.
          </p>
        </div>
      </section>

      {/* Overview & Core Philosophy */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          <div className="lg:col-span-7 space-y-4">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Kurikulum Berbasis Praktik Industri dan Sertifikasi Nyata
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Program Keahlian TKJ di SMK Komputer Al-Bashry dirancang dengan proporsi <strong>70% Praktikum Laboratorium & Lapangan</strong> dan <strong>30% Teori Konseptual</strong>. Kami memastikan setiap siswa memahami logika di balik transfer paket data, bukan hanya sekadar menghafal langkah konfigurasi.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Didukung oleh fasilitas laboratorium berstandar vendor global, siswa kami dilatih menggunakan perangkat riil (MikroTik RouterBOARD, Cisco Switch, Fujikura/Inno Fusion Splicer, Optical Power Meter, dan Server Linux Debian).
            </p>

            <div className="grid grid-cols-2 gap-4 pt-3">
              <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-100">
                <span className="text-xs font-bold text-blue-900 block mb-1">Standar Vendor</span>
                <span className="text-[11px] text-slate-600">Kurikulum mengacu standar MikroTik Academy & Cisco Networking.</span>
              </div>
              <div className="p-3.5 bg-emerald-50/80 rounded-xl border border-emerald-100">
                <span className="text-xs font-bold text-emerald-900 block mb-1">Sertifikasi BNSP</span>
                <span className="text-[11px] text-slate-600">Uji Kompetensi Keahlian (UKK) skema Teknisi Madya Jaringan Komputer.</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200">
              <img
                src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80"
                alt="Praktik Laboratorium Jaringan TKJ"
                className="w-full h-80 object-cover"
              />
              <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold">Laboratorium Server & Router Al-Bashry</p>
                  <p className="text-[11px] text-slate-400">Simulasi topologi jaringan skala menengah</p>
                </div>
                <Award className="w-5 h-5 text-amber-400" />
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 9 Core Competency Pillars */}
      <section className="bg-slate-50 py-16 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-100/70 px-3 py-1 rounded-full">
              Pilar Kompetensi Siswa
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading mt-2">
              Keahlian Teknis yang Dipelajari di Jurusan TKJ
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Setiap modul disusun bertahap dari kelas X hingga kelas XII dengan capaian portofolio terukur.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {competencies.map((comp, idx) => {
              const Icon = comp.icon;
              return (
                <div 
                  key={idx}
                  className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:border-blue-300 hover:shadow-md transition group"
                >
                  <div className="w-12 h-12 bg-blue-50 group-hover:bg-blue-600 text-blue-600 group-hover:text-white rounded-xl flex items-center justify-center mb-4 transition-colors">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-base mb-2 font-heading group-hover:text-blue-600 transition">
                    {comp.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {comp.desc}
                  </p>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* Program PKL & Kemitraan Industri */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-blue-900 to-[#0B1F3A] rounded-3xl p-8 sm:p-12 text-white shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400 bg-sky-950 px-3 py-1 rounded-full border border-sky-800">
                Praktik Kerja Lapangan (PKL)
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">
                Magang Industri Nyata Selama 6 Bulan di Penyedia Jasa Internet & Perusahaan IT
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Setiap siswa kelas XI wajib mengikuti program PKL untuk merasakan ritme kerja profesional, penanganan kabel serat optik lapangan, instalasi router di sisi pelanggan (CPE), hingga interaksi etis dengan konsumen dan supervisor industri.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block">Mitra ISP & Telco</span>
                  <span className="text-slate-300 text-[11px]">PT Telkom Indonesia, CitraNet, Palabuhanratu Digital Network</span>
                </div>
                <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block">Instansi Pemerintah</span>
                  <span className="text-slate-300 text-[11px]">Diskominfo Kab. Sukabumi, Setda, Kantor Kecamatan Palabuhanratu</span>
                </div>
                <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block">Perusahaan Swasta</span>
                  <span className="text-slate-300 text-[11px]">Penyedia Solusi IT, Perhotelan Palabuhanratu, Sentra Retail Komputer</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-center justify-center text-center p-6 bg-white/5 rounded-2xl border border-white/10">
              <Award className="w-16 h-16 text-amber-400 mb-3" />
              <div className="text-2xl font-bold font-heading text-white">100% Terserap</div>
              <p className="text-xs text-slate-300 mt-1">
                Lulusan dibekali sertifikat industri dan surat referensi kerja dari perusahaan tempat magang.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Peluang Karir Lulusan TKJ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
            Prospek Masa Depan
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading mt-2">
            Peluang Kerja & Masa Depan Lulusan TKJ
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Lulusan SMK Komputer Al-Bashry siap bekerja, melanjutkan studi ke perguruan tinggi, maupun membangun bisnis mandiri (BMW).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {careerPaths.map((cp, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <h3 className="font-bold text-slate-900 text-sm font-heading">{cp.title}</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-7">
                {cp.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={() => navigateToPublic('ppdb')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-8 py-3.5 rounded-xl shadow-lg transition"
          >
            Daftar Sekarang ke Jurusan TKJ (PPDB 2026)
          </button>
        </div>
      </section>

    </div>
  );
};
