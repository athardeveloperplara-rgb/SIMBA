import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolLogo } from '../../components/SchoolLogo';
import { 
  Building, 
  Target, 
  Eye, 
  Award, 
  Users, 
  ShieldCheck, 
  BookOpen, 
  CheckCircle2, 
  Cpu, 
  Monitor,
  Flame,
  Globe
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { settings, teachers } = useApp();
  const [activeTab, setActiveTab] = useState<'identitas' | 'sejarah' | 'kepsek' | 'organisasi' | 'sarana' | 'tatatertib'>('identitas');

  return (
    <div className="space-y-12 pb-16">
      
      {/* Header Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-blue-900/60 text-sky-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-blue-700/60">
            <Building className="w-3.5 h-3.5" />
            <span>Tentang Sekolah</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-heading text-white">
            Profil SMK Komputer Al-Bashry
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Membangun insan bertakwa, cerdas dalam rekayasa teknologi komputer jaringan, dan berdaya saing tinggi di Palabuhanratu, Sukabumi.
          </p>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 text-xs sm:text-sm font-semibold text-slate-600">
          <button
            onClick={() => setActiveTab('identitas')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'identitas' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Identitas, Visi & Misi
          </button>
          <button
            onClick={() => setActiveTab('sejarah')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'sejarah' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Sejarah Pendirian
          </button>
          <button
            onClick={() => setActiveTab('kepsek')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'kepsek' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Sambutan & Profil Kepsek
          </button>
          <button
            onClick={() => setActiveTab('organisasi')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'organisasi' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Struktur Organisasi
          </button>
          <button
            onClick={() => setActiveTab('sarana')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'sarana' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Sarana & Laboratorium
          </button>
          <button
            onClick={() => setActiveTab('tatatertib')}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition ${
              activeTab === 'tatatertib' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            Budaya & Tata Tertib
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Tab 1: Identitas, Visi & Misi */}
        {activeTab === 'identitas' && (
          <div className="space-y-10 animate-in fade-in duration-200">
            {/* Identity Table */}
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
              <h2 className="text-xl font-bold font-heading text-slate-900 mb-6 flex items-center gap-2">
                <Building className="w-5 h-5 text-blue-600" />
                <span>Identitas Resmi Lembaga</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">Nama Sekolah:</span>
                  <span className="font-bold text-slate-900">{settings.schoolName}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">NPSN:</span>
                  <span className="font-mono font-bold text-slate-900">{settings.npsn}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">Bentuk Pendidikan:</span>
                  <span className="font-bold text-slate-900">Sekolah Menengah Kejuruan (SMK)</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">Status Akreditasi:</span>
                  <span className="font-bold text-emerald-600">{settings.accreditation}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">Program Keahlian:</span>
                  <span className="font-bold text-blue-600">Teknik Komputer dan Jaringan (TKJ)</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100">
                  <span className="text-slate-500">Kepala Sekolah:</span>
                  <span className="font-bold text-slate-900">{settings.headmasterName}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl flex justify-between border border-slate-100 md:col-span-2">
                  <span className="text-slate-500">Alamat Kampus:</span>
                  <span className="font-medium text-slate-900 text-right">
                    {settings.address}, {settings.subdistrict}, {settings.city}, {settings.province} ({settings.postalCode})
                  </span>
                </div>
              </div>
            </div>

            {/* Visi & Misi */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Visi */}
              <div className="bg-gradient-to-br from-[#0B1F3A] to-[#1E3A8A] text-white rounded-2xl p-8 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-4 text-sky-400">
                    <Eye className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold font-heading mb-3 text-white">Visi Sekolah</h3>
                  <p className="text-sm leading-relaxed text-slate-200 italic">
                    “Terwujudnya SMK Komputer Al-Bashry sebagai pusat pendidikan kejuruan teknologi informasi dan jaringan yang unggul, berkarakter islami, kompeten berstandar industri, serta berjiwa wirausaha pada tahun 2030.”
                  </p>
                </div>
                <div className="pt-6 border-t border-white/10 text-xs text-sky-300 font-medium">
                  SMK Komputer Al-Bashry Palabuhanratu
                </div>
              </div>

              {/* Misi */}
              <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs">
                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-heading text-slate-900 mb-3">Misi Sekolah</h3>
                <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Menyelenggarakan pembelajaran kejuruan TKJ berbasis kurikulum industri dan sertifikasi internasional.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Mengoptimalkan sarana laboratorium komputer, fiber optik, dan perangkat jaringan nyata untuk hands-on training.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Menjalin kemitraan strategis dengan Dunia Usaha dan Dunia Industri (DUDI) telekomunikasi serta ISP terkemuka.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Menanamkan nilai-nilai religius, etika profesi, kejujuran teknis, dan kepedulian lingkungan maritim Palabuhanratu.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Arti Lambang Sekolah */}
            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div className="md:col-span-4 flex justify-center">
                  <div className="bg-white p-4 rounded-3xl shadow-md border border-slate-200">
                    <SchoolLogo size={180} />
                  </div>
                </div>
                <div className="md:col-span-8 space-y-3">
                  <h3 className="text-lg font-bold font-heading text-slate-900">
                    Makna Filosofis Lambang SMK Komputer Al-Bashry
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    <strong>Warna Biru Navy & Emas:</strong> Melambangkan kedalaman wawasan ilmu pengetahuan teknologi dan kemuliaan karakter pekerti.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    <strong>Perisai & Obor:</strong> Melambangkan ketangguhan iman dan obor penerang ilmu yang tak kunjung padam dalam mencerdaskan generasi.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    <strong>Komputer, Bola Dunia & Panah Melingkar:</strong> Melambangkan kompetensi utama Teknik Komputer dan Jaringan yang terhubung secara global, dinamis, dan solutif.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    <strong>Motif Ombak di Bagian Bawah:</strong> Menggambarkan identitas geografis Palabuhanratu sebagai kawasan pesisir Kabupaten Sukabumi yang kaya potensi bahari dan keterbukaan.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Sejarah Pendirian */}
        {activeTab === 'sejarah' && (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in duration-200">
            <h2 className="text-2xl font-bold font-heading text-slate-900">
              Sejarah SMK Komputer Al-Bashry Palabuhanratu
            </h2>
            <div className="prose prose-slate max-w-none text-xs sm:text-sm leading-relaxed text-slate-600 space-y-4">
              <p>
                SMK Komputer Al-Bashry didirikan atas dasar kepedulian mendalam terhadap kebutuhan tenaga kerja terampil di bidang teknologi informasi di kawasan Palabuhanratu dan Kabupaten Sukabumi bagian selatan. Seiring perkembangan jaringan telekomunikasi dan era digitalisasi pelayanan publik, ketersediaan teknisi komputer dan jaringan yang handal menjadi prasyarat kemajuan daerah.
              </p>
              <p>
                Diinisiasi oleh para akademisi dan praktisi IT yang dimotori oleh Yayasan Al-Bashry, sekolah ini secara konsisten memusatkan orientasi pendidikannya pada <strong>Teknik Komputer dan Jaringan (TKJ)</strong>. Pemilihan satu fokus jurusan ini dilakukan agar seluruh investasi fasilitas, laboratorium, pengadaan server, dan kompetensi guru benar-benar mendalam dan paripurna.
              </p>
              <p>
                Dari awal berdiri dengan satu laboratorium komputer sederhana, kini SMK Komputer Al-Bashry telah berkembang pesat dengan 3 laboratorium khusus (Lab Hardware & Troubleshooting, Lab Cisco/MikroTik, dan Lab Fiber Optik), serta terhubung dengan puluhan mitra industri penyedia jasa internet (ISP) dan instansi pemerintah daerah.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Sambutan & Profil Kepsek */}
        {activeTab === 'kepsek' && (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-8 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row items-center gap-8">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80"
                alt="Kepala Sekolah"
                className="w-48 h-48 object-cover rounded-2xl shadow-md border-2 border-slate-200"
              />
              <div className="space-y-2 text-center sm:text-left">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                  Pimpinan Sekolah
                </span>
                <h2 className="text-2xl font-extrabold font-heading text-slate-900">
                  {settings.headmasterName}
                </h2>
                <p className="text-xs text-slate-500 font-mono">
                  NIP. {settings.headmasterNip}
                </p>
                <p className="text-xs sm:text-sm text-slate-600 max-w-xl pt-2">
                  Magister Teknik Elektro & Informatika dengan pengalaman lebih dari 20 tahun dalam pengembangan kurikulum vokasi IT dan arsitektur jaringan komputer.
                </p>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-6 space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Amanat Kepemimpinan: “Integritas Teknis & Keterampilan Nyata”
              </h3>
              <p>
                Bagi kami di SMK Komputer Al-Bashry, pendidikan kejuruan bukan sekadar menghafal modul teori, melainkan tentang keberanian merangkai, membedah masalah konfigurasi jaringan, hingga sistem berfungsi dengan baik dan aman.
              </p>
              <p>
                Kami menyambut hangat para orang tua yang mempercayakan putra-putrinya untuk dididik di kampus ini. Kami berkomitmen menjaga kepercayaan tersebut dengan memberikan pengajaran berkualitas, sarana laboratorium yang layak, dan pendampingan karakter agar lulusan siap bekerja, berwirausaha, maupun melanjutkan ke jenjang perguruan tinggi.
              </p>
            </div>
          </div>
        )}

        {/* Tab 4: Struktur Organisasi */}
        {activeTab === 'organisasi' && (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in duration-200">
            <h2 className="text-xl font-bold font-heading text-slate-900">
              Struktur Organisasi SMK Komputer Al-Bashry
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Kepala Sekolah</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">{settings.headmasterName}</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Ketua Program Keahlian TKJ</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">Irvan Kurniawan, S.Pd., M.Kom.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Kepala Laboratorium Komputer</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">Dedi Mulyadi, S.T.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Wakasek Kurikulum & Pengajaran</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">Fitri Handayani, S.Kom.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Wakasek Kesiswaan & Kedisiplinan</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">Asep Hidayat, S.Pd.I.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-500">Pokja Hubungan Industri & PKL</p>
                <p className="text-sm font-extrabold text-[#0B1F3A] mt-1">Siti Rahmawati, S.Kom.</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Sarana & Laboratorium */}
        {activeTab === 'sarana' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                <Monitor className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Lab Perakitan Komputer & Maintenance
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                36 meja praktik hardware dengan antistatik mat, catu daya uji, diagnostic tool card, serta ragam motherboard dan prosesor generasi mutakhir untuk praktikum dasar perakitan PC.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <div className="w-10 h-10 bg-sky-100 text-sky-600 rounded-lg flex items-center justify-center">
                <Cpu className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Lab Jaringan Router & Switch Manageable
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Dilengkapi dengan 30 unit MikroTik RouterBOARD RB750/RB941, switch Catalyst 2960 series, patch panel 24 port, dan kabel tester digital untuk konfigurasi VLAN dan Dynamic Routing.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center">
                <Flame className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Lab Fiber Optic Splicing & OTDR
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Perangkat fusion splicer presisi mikron, fiber cleaver, Optical Power Meter (OPM), dan Visual Fault Locator (VFL) guna melatih teknisi kabel serat optik lapangan.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-heading">
                Akses Internet Dedicated & Server Lokal
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Bandwidth simetris berkecepatan tinggi dengan server bare-metal Proxmox VE yang digunakan sebagai platform lab virtual simulasi Debian server dan Linux cloud siswa.
              </p>
            </div>
          </div>
        )}

        {/* Tab 6: Budaya & Tata Tertib */}
        {activeTab === 'tatatertib' && (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in duration-200">
            <h2 className="text-xl font-bold font-heading text-slate-900">
              Budaya Kerja 5R & Tata Tertib Siswa
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm text-slate-600">
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-slate-900 font-heading">
                  Penerapan Budaya Industri 5R di Laboratorium:
                </h3>
                <ul className="space-y-2">
                  <li><strong>Ringkas:</strong> Memilah alat dan perangkat jaringan yang diperlukan di meja lab.</li>
                  <li><strong>Rapi:</strong> Mengatur susunan kabel (cable management) sesuai kerapian rak server.</li>
                  <li><strong>Resik:</strong> Menjaga kebersihan perangkat dari debu dan cairan.</li>
                  <li><strong>Rawat:</strong> Menguji kelayakan alat praktikum setelah digunakan.</li>
                  <li><strong>Rajin:</strong> Mematuhi Standar Operasional Prosedur (SOP) keselamatan listrik.</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-slate-900 font-heading">
                  Tata Tertib Akademik & Disiplin:
                </h3>
                <ul className="space-y-2">
                  <li>Hadir tepat waktu sebelum pukul 07.15 WIB.</li>
                  <li>Mengenakan seragam resmi dan wearpack khusus saat praktik laboratorium.</li>
                  <li>Dilarang mengubah konfigurasi password perangkat server lab tanpa izin instruktur.</li>
                  <li>Menjunjung tinggi etika digital dan dilarang menyalahgunakan alat untuk tindakan cyber crime.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
