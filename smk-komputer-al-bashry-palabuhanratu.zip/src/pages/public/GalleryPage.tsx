import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GalleryItem } from '../../types';
import { 
  Image as ImageIcon, 
  Calendar, 
  Tag, 
  X, 
  ZoomIn, 
  Maximize2 
} from 'lucide-react';

export const GalleryPage: React.FC = () => {
  const { galleryList } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activePhoto, setActivePhoto] = useState<GalleryItem | null>(null);

  const categories = [
    'Semua', 
    'Praktik TKJ', 
    'Laboratorium', 
    'Kegiatan Sekolah', 
    'Ekstrakurikuler', 
    'Kunjungan Industri'
  ];

  const filteredPhotos = selectedCategory === 'Semua'
    ? galleryList
    : galleryList.filter(g => g.category === selectedCategory);

  return (
    <div className="space-y-12 pb-16">
      
      {/* Header Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-blue-900/60 text-sky-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-blue-700/60">
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Dokumentasi Visual</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-heading text-white">
            Galeri Kegiatan & Praktikum TKJ
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Merekam dinamika belajar, aktivitas perakitan komputer, konfigurasi jaringan, ekstrakurikuler, dan momentum kebersamaan siswa SMK Komputer Al-Bashry.
          </p>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2 text-xs font-bold">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl transition whitespace-nowrap ${
                selectedCategory === cat ? 'bg-blue-600 text-white shadow-xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Photo Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {filteredPhotos.map(photo => (
            <div
              key={photo.id}
              onClick={() => setActivePhoto(photo)}
              className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-lg transition cursor-pointer group flex flex-col justify-between"
            >
              <div className="relative aspect-4/3 overflow-hidden bg-slate-100">
                <img
                  src={photo.imageUrl}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="bg-white/90 backdrop-blur-xs p-2.5 rounded-full text-slate-900 shadow">
                    <Maximize2 className="w-5 h-5" />
                  </div>
                </div>
                <div className="absolute top-3 left-3 bg-[#0B1F3A]/90 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-0.5 rounded-md">
                  {photo.category}
                </div>
              </div>

              <div className="p-4 space-y-1.5">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                  <Calendar className="w-3 h-3" />
                  <span>{photo.date}</span>
                </div>
                <h3 className="font-bold text-slate-900 text-sm font-heading group-hover:text-blue-600 transition line-clamp-1">
                  {photo.title}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {photo.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activePhoto && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setActivePhoto(null)}
        >
          <div 
            className="max-w-4xl w-full bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-800 text-white"
            onClick={e => e.stopPropagation()}
          >
            <div className="relative">
              <button
                onClick={() => setActivePhoto(null)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black/90 transition"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={activePhoto.imageUrl}
                alt={activePhoto.title}
                className="w-full max-h-[70vh] object-contain bg-black"
              />
            </div>
            <div className="p-6 space-y-2">
              <div className="flex items-center gap-3 text-xs text-sky-400">
                <span className="bg-sky-950 border border-sky-800 px-2.5 py-0.5 rounded-md font-bold uppercase">
                  {activePhoto.category}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {activePhoto.date}
                </span>
              </div>
              <h3 className="text-xl font-bold font-heading text-white">
                {activePhoto.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {activePhoto.description}
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
