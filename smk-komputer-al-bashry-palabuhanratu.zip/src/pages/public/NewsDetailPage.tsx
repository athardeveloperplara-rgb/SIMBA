import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Tag, 
  Share2, 
  Check, 
  ChevronRight,
  BookOpen
} from 'lucide-react';

export const NewsDetailPage: React.FC = () => {
  const { selectedNewsSlug, newsList, navigateToPublic } = useApp();
  const [copied, setCopied] = React.useState(false);

  const article = newsList.find(n => n.slug === selectedNewsSlug) || newsList[0];
  const relatedArticles = newsList.filter(n => n.id !== article?.id).slice(0, 3);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-base text-slate-600">Artikel tidak ditemukan.</p>
        <button
          onClick={() => navigateToPublic('berita')}
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Berita</span>
        </button>
      </div>
    );
  }

  return (
    <div className="py-10 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Back Link */}
        <button
          onClick={() => navigateToPublic('berita')}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Daftar Berita & Pengumuman</span>
        </button>

        {/* Article Header */}
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-md">
              {article.category}
            </span>
            {article.isImportant && (
              <span className="bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-md">
                Penting
              </span>
            )}
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading leading-tight">
            {article.title}
          </h1>

          <div className="flex flex-wrap items-center justify-between gap-4 py-3 border-y border-slate-200 text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 font-medium">
                <Calendar className="w-4 h-4 text-slate-400" />
                {article.publishedAt}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 font-medium">
                <User className="w-4 h-4 text-slate-400" />
                {article.author}
              </span>
            </div>

            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tautan Disalin!' : 'Bagikan Berita'}</span>
            </button>
          </div>
        </div>

        {/* Featured Image */}
        <div className="rounded-2xl overflow-hidden shadow-lg border border-slate-200">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-72 sm:h-96 object-cover"
          />
        </div>

        {/* Content Body */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4 text-xs sm:text-base leading-relaxed text-slate-700 whitespace-pre-line">
          <p className="font-semibold text-slate-900 text-sm sm:text-lg italic border-l-4 border-blue-600 pl-4 py-1">
            {article.summary}
          </p>
          <div>{article.content}</div>
        </div>

        {/* Related Articles */}
        <div className="pt-8 border-t border-slate-200 space-y-4">
          <h3 className="text-lg font-bold font-heading text-slate-900">
            Berita Terkait Lainnya
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {relatedArticles.map(rel => (
              <div
                key={rel.id}
                onClick={() => navigateToPublic('berita-detail', rel.slug)}
                className="bg-white rounded-xl border border-slate-200 p-4 hover:border-blue-400 transition cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-bold text-blue-600 uppercase block mb-1">
                    {rel.category}
                  </span>
                  <h4 className="font-bold text-xs text-slate-900 group-hover:text-blue-600 transition line-clamp-2">
                    {rel.title}
                  </h4>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-100">
                  <Calendar className="w-3 h-3" />
                  <span>{rel.publishedAt}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
