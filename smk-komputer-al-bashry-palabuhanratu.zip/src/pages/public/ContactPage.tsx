import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  PhoneCall, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  MessageSquare,
  Globe
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { settings } = useApp();
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.message) return;
    setSent(true);
  };

  return (
    <div className="space-y-12 pb-20">
      
      {/* Header Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-blue-900/60 text-sky-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-blue-700/60">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Hubungi Kami</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-heading text-white">
            Kontak & Lokasi Kampus
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Kami siap melayani pertanyaan seputar pendaftaran siswa baru, kemitraan praktik industri TKJ, atau kunjungan langsung ke kampus sekolah.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Contact Info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
              <h2 className="text-xl font-bold font-heading text-slate-900">
                Informasi Kontak Resmi
              </h2>

              <ul className="space-y-4 text-xs sm:text-sm text-slate-600">
                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <strong className="block text-slate-900 font-semibold mb-0.5">Alamat Kampus:</strong>
                    <span>{settings.address}, {settings.subdistrict}, {settings.city}, {settings.province} {settings.postalCode}</span>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <strong className="block text-slate-900 font-semibold mb-0.5">Telepon & WhatsApp:</strong>
                    <span>Kantor: {settings.phone}</span><br />
                    <span>WhatsApp Panitia: {settings.whatsapp}</span>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <strong className="block text-slate-900 font-semibold mb-0.5">Email Resmi:</strong>
                    <span>{settings.email}</span>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <strong className="block text-slate-900 font-semibold mb-0.5">Jam Pelayanan Kantor:</strong>
                    <span>Senin – Jumat: 07.15 – 16.00 WIB</span><br />
                    <span>Sabtu (Pelayanan Khusus PPDB): 08.00 – 12.00 WIB</span>
                  </div>
                </li>
              </ul>

              <div className="pt-4 border-t border-slate-100">
                <a
                  href={`https://wa.me/62${settings.whatsapp.replace(/[^0-9]/g, '').slice(1)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Kirim Pesan Cepat via WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Google Maps Embed for Palabuhanratu */}
            <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xs">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-2 text-xs font-bold text-slate-700">
                <Globe className="w-4 h-4 text-blue-600" />
                <span>Peta Lokasi Palabuhanratu, Sukabumi</span>
              </div>
              <div className="aspect-video w-full">
                <iframe
                  title="Peta Palabuhanratu"
                  src="https://maps.google.com/maps?q=Palabuhanratu,%20Sukabumi&t=&z=14&ie=UTF8&iwloc=&output=embed"
                  className="w-full h-full border-0"
                  allowFullScreen
                  loading="lazy"
                ></iframe>
              </div>
            </div>
          </div>

          {/* Right: Message Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-xs space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900">
                  Formulir Kirim Pesan & Pengaduan
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Sampaikan saran, permohonan informasi kemitraan, atau pengaduan akademik melalui formulir ini.
                </p>
              </div>

              {sent ? (
                <div className="p-8 text-center bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 font-heading">
                    Pesan Berhasil Terkirim!
                  </h3>
                  <p className="text-xs text-slate-600 max-w-sm mx-auto">
                    Terima kasih telah menghubungi SMK Komputer Al-Bashry Palabuhanratu. Tim kami akan segera menindaklanjuti pesan Anda.
                  </p>
                  <button
                    onClick={() => {
                      setSent(false);
                      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
                    }}
                    className="bg-emerald-600 text-white font-bold text-xs px-4 py-2 rounded-lg"
                  >
                    Kirim Pesan Lain
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nama Lengkap *
                    </label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={e => setForm({ ...form, name: e.target.value })}
                      placeholder="Nama lengkap Anda"
                      required
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Alamat Email
                      </label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={e => setForm({ ...form, email: e.target.value })}
                        placeholder="email@domain.com"
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Nomor Telepon / WhatsApp
                      </label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={e => setForm({ ...form, phone: e.target.value })}
                        placeholder="Contoh: 0812-3456-7890"
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Subjek / Perihal *
                    </label>
                    <input
                      type="text"
                      value={form.subject}
                      onChange={e => setForm({ ...form, subject: e.target.value })}
                      placeholder="Contoh: Pertanyaan PPDB 2026 atau Pengajuan Kerja Sama PKL"
                      required
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Isi Pesan *
                    </label>
                    <textarea
                      rows={5}
                      value={form.message}
                      onChange={e => setForm({ ...form, message: e.target.value })}
                      placeholder="Tuliskan pesan atau pertanyaan Anda secara rinci..."
                      required
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Kirim Pesan ke Sekolah</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
