import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  Search, 
  GraduationCap, 
  BookOpen, 
  Mail, 
  Award,
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';

export const TeachersPublicPage: React.FC = () => {
  const { teachers } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'semua' | 'produktif' | 'umum'>('semua');

  const filteredTeachers = teachers.filter(t => {
    const matchesSearch = t.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.subjectsTaught.some(s => s.toLowerCase().includes(searchTerm.toLowerCase())) ||
      t.roleTitle.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (categoryFilter === 'produktif') {
      return t.roleTitle.toLowerCase().includes('tkj') || 
             t.subjectsTaught.some(s => s.toLowerCase().includes('jaringan') || s.toLowerCase().includes('tkj') || s.toLowerCase().includes('komputer'));
    }
    if (categoryFilter === 'umum') {
      return !t.roleTitle.toLowerCase().includes('tkj') && !t.subjectsTaught.some(s => s.toLowerCase().includes('jaringan') || s.toLowerCase().includes('tkj'));
    }

    return true;
  });

  return (
    <div className="space-y-12 pb-16">
      
      {/* Header Banner */}
      <div className="bg-[#0B1F3A] text-white py-14 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-blue-900/60 text-sky-300 px-3.5 py-1 rounded-full text-xs font-semibold border border-blue-700/60">
            <Users className="w-3.5 h-3.5" />
            <span>Pendidik & Tenaga Kependidikan</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-heading text-white">
            Direktori Guru & Tenaga Kependidikan
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto">
            Dipandu oleh para pendidik bersertifikasi, praktisi teknologi informasi, dan instruktur jaringan yang berdedikasi membimbing generasi muda.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Cari nama guru atau mata pelajaran..."
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 text-xs font-bold">
            <button
              onClick={() => setCategoryFilter('semua')}
              className={`px-3.5 py-2 rounded-lg transition whitespace-nowrap ${
                categoryFilter === 'semua' ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Semua ({teachers.length})
            </button>
            <button
              onClick={() => setCategoryFilter('produktif')}
              className={`px-3.5 py-2 rounded-lg transition whitespace-nowrap ${
                categoryFilter === 'produktif' ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Guru Produktif TKJ
            </button>
            <button
              onClick={() => setCategoryFilter('umum')}
              className={`px-3.5 py-2 rounded-lg transition whitespace-nowrap ${
                categoryFilter === 'umum' ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Guru Muatan Umum
            </button>
          </div>

        </div>
      </div>

      {/* Teachers Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTeachers.map(teacher => (
            <div 
              key={teacher.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="relative h-56 bg-slate-100 overflow-hidden">
                  <img
                    src={teacher.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                    alt={teacher.fullName}
                    className="w-full h-full object-cover object-top hover:scale-105 transition duration-500"
                  />
                  <div className="absolute bottom-2 left-2 right-2">
                    <span className="inline-block bg-[#0B1F3A]/90 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                      {teacher.roleTitle}
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base font-heading leading-snug">
                      {teacher.fullName}
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                      NIP. {teacher.nip}
                    </p>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    <div className="flex items-start gap-2">
                      <GraduationCap className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                      <span className="text-[11px] font-medium leading-relaxed">{teacher.education}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <BookOpen className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span className="text-[11px] font-medium leading-relaxed">
                        {teacher.subjectsTaught.join(', ')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="inline-flex items-center gap-1 text-emerald-600 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Pendidik Aktif
                </span>
                <span className="text-slate-400">SMK Al-Bashry</span>
              </div>
            </div>
          ))}
        </div>

        {filteredTeachers.length === 0 && (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
            <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold text-slate-700">Tidak ada guru yang cocok dengan pencarian.</p>
            <p className="text-xs text-slate-500 mt-1">Coba gunakan kata kunci nama atau bidang tugas lainnya.</p>
          </div>
        )}
      </div>

    </div>
  );
};
