import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  UserProfile, 
  UserRole, 
  Student, 
  Teacher, 
  SchoolClass, 
  Subject, 
  ScheduleItem, 
  AttendanceRecord, 
  GradeItem, 
  TeachingJournal, 
  PPDBApplication, 
  SchoolNews, 
  GalleryItem, 
  SchoolSettings, 
  AuditLog
} from '../types';
import { 
  initialSchoolSettings, 
  initialTeachers, 
  initialClasses, 
  initialSubjects, 
  initialStudents, 
  initialSchedules, 
  initialAttendance, 
  initialGrades, 
  initialJournals, 
  initialPPDB, 
  initialNews, 
  initialGallery, 
  initialAuditLogs,
  demoAccounts
} from '../data/seedData';

export type PublicPage = 
  | 'home'
  | 'profil'
  | 'tkj'
  | 'akademik'
  | 'guru'
  | 'berita'
  | 'berita-detail'
  | 'galeri'
  | 'ppdb'
  | 'kontak';

export type SiakadModule = 
  | 'dashboard'
  | 'siswa'
  | 'guru-admin'
  | 'kelas'
  | 'mapel'
  | 'jadwal'
  | 'presensi'
  | 'nilai'
  | 'rapor'
  | 'jurnal'
  | 'ppdb-admin'
  | 'berita-admin'
  | 'laporan'
  | 'pengaturan';

interface AppContextType {
  // Navigation & Mode
  isSiakadMode: boolean;
  publicPage: PublicPage;
  activeSiakadModule: SiakadModule;
  selectedNewsSlug: string | null;
  navigateToPublic: (page: PublicPage, param?: string) => void;
  navigateToSiakad: (module?: SiakadModule) => void;
  exitSiakadToPublic: () => void;

  // Authentication
  currentUser: UserProfile | null;
  login: (username: string, pass: string) => boolean;
  quickSwitchRole: (role: string) => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  // State Collections
  settings: SchoolSettings;
  students: Student[];
  teachers: Teacher[];
  classes: SchoolClass[];
  subjects: Subject[];
  schedules: ScheduleItem[];
  attendance: AttendanceRecord[];
  grades: GradeItem[];
  journals: TeachingJournal[];
  ppdbList: PPDBApplication[];
  newsList: SchoolNews[];
  galleryList: GalleryItem[];
  auditLogs: AuditLog[];

  // Student CRUD
  addStudent: (student: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, updated: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  // Teacher CRUD
  addTeacher: (teacher: Omit<Teacher, 'id'>) => void;
  updateTeacher: (id: string, updated: Partial<Teacher>) => void;
  deleteTeacher: (id: string) => void;

  // Class CRUD
  addClass: (cls: Omit<SchoolClass, 'id'>) => void;
  updateClass: (id: string, updated: Partial<SchoolClass>) => void;
  deleteClass: (id: string) => void;

  // Subject CRUD
  addSubject: (subj: Omit<Subject, 'id'>) => void;
  updateSubject: (id: string, updated: Partial<Subject>) => void;
  deleteSubject: (id: string) => void;

  // Schedule CRUD
  addSchedule: (sch: Omit<ScheduleItem, 'id'>) => void;
  updateSchedule: (id: string, updated: Partial<ScheduleItem>) => void;
  deleteSchedule: (id: string) => void;

  // Attendance
  saveAttendanceBatch: (records: Omit<AttendanceRecord, 'id'>[]) => void;

  // Grades
  saveGrade: (grade: Omit<GradeItem, 'id' | 'finalScore' | 'predicate' | 'lastUpdated'> & { id?: string }) => void;

  // Journal
  addJournal: (jnl: Omit<TeachingJournal, 'id'>) => void;
  updateJournal: (id: string, updated: Partial<TeachingJournal>) => void;
  deleteJournal: (id: string) => void;

  // PPDB
  submitPPDB: (data: Omit<PPDBApplication, 'id' | 'registrationNumber' | 'registrationDate' | 'status'>) => string;
  updatePPDBStatus: (id: string, status: PPDBApplication['status'], notes?: string) => void;

  // News & Gallery
  addNews: (news: Omit<SchoolNews, 'id' | 'slug' | 'publishedAt'>) => void;
  updateNews: (id: string, updated: Partial<SchoolNews>) => void;
  deleteNews: (id: string) => void;
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  deleteGalleryItem: (id: string) => void;

  // System
  updateSettings: (newSettings: Partial<SchoolSettings>) => void;
  resetAllData: () => void;
  exportJSON: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'smk_albashry_user_v1',
  SETTINGS: 'smk_albashry_settings_v1',
  STUDENTS: 'smk_albashry_students_v1',
  TEACHERS: 'smk_albashry_teachers_v1',
  CLASSES: 'smk_albashry_classes_v1',
  SUBJECTS: 'smk_albashry_subjects_v1',
  SCHEDULES: 'smk_albashry_schedules_v1',
  ATTENDANCE: 'smk_albashry_attendance_v1',
  GRADES: 'smk_albashry_grades_v1',
  JOURNALS: 'smk_albashry_journals_v1',
  PPDB: 'smk_albashry_ppdb_v1',
  NEWS: 'smk_albashry_news_v1',
  GALLERY: 'smk_albashry_gallery_v1',
  LOGS: 'smk_albashry_logs_v1'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation
  const [isSiakadMode, setIsSiakadMode] = useState<boolean>(false);
  const [publicPage, setPublicPage] = useState<PublicPage>('home');
  const [activeSiakadModule, setActiveSiakadModule] = useState<SiakadModule>('dashboard');
  const [selectedNewsSlug, setSelectedNewsSlug] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return null; // Guest by default
  });

  // Data Collections with LocalStorage hydration
  const [settings, setSettings] = useState<SchoolSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialSchoolSettings;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialStudents;
  });

  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TEACHERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialTeachers;
  });

  const [classes, setClasses] = useState<SchoolClass[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CLASSES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialClasses;
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUBJECTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialSubjects;
  });

  const [schedules, setSchedules] = useState<ScheduleItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialSchedules;
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialAttendance;
  });

  const [grades, setGrades] = useState<GradeItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GRADES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialGrades;
  });

  const [journals, setJournals] = useState<TeachingJournal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOURNALS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialJournals;
  });

  const [ppdbList, setPpdbList] = useState<PPDBApplication[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PPDB);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialPPDB;
  });

  const [newsList, setNewsList] = useState<SchoolNews[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NEWS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialNews;
  });

  const [galleryList, setGalleryList] = useState<GalleryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GALLERY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialGallery;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return initialAuditLogs;
  });

  // Persistent storage synchronizer
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } catch (e) { console.error(e); }
  }, [currentUser]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
      localStorage.setItem(STORAGE_KEYS.TEACHERS, JSON.stringify(teachers));
      localStorage.setItem(STORAGE_KEYS.CLASSES, JSON.stringify(classes));
      localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(subjects));
      localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance));
      localStorage.setItem(STORAGE_KEYS.GRADES, JSON.stringify(grades));
      localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
      localStorage.setItem(STORAGE_KEYS.PPDB, JSON.stringify(ppdbList));
      localStorage.setItem(STORAGE_KEYS.NEWS, JSON.stringify(newsList));
      localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(galleryList));
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(auditLogs));
    } catch (e) {
      console.error(e);
    }
  }, [settings, students, teachers, classes, subjects, schedules, attendance, grades, journals, ppdbList, newsList, galleryList, auditLogs]);

  // Helper log function
  const recordLog = (action: string, module: string, details: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleString('id-ID'),
      userName: currentUser ? currentUser.fullName : 'Sistem / Tamu',
      userRole: currentUser ? currentUser.role : 'Publik',
      action,
      module,
      details
    };
    setAuditLogs(prev => [newLog, ...prev.slice(0, 99)]);
  };

  // Navigation handlers
  const navigateToPublic = (page: PublicPage, param?: string) => {
    setIsSiakadMode(false);
    setPublicPage(page);
    if (param) setSelectedNewsSlug(param);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToSiakad = (module: SiakadModule = 'dashboard') => {
    if (!currentUser) {
      // Auto open login or switch to admin
      setIsAuthModalOpen(true);
      return;
    }
    setIsSiakadMode(true);
    setActiveSiakadModule(module);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const exitSiakadToPublic = () => {
    setIsSiakadMode(false);
    setPublicPage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Auth methods
  const login = (username: string, pass: string): boolean => {
    const found = demoAccounts.find(
      acc => acc.username.toLowerCase() === username.toLowerCase() || acc.email.toLowerCase() === username.toLowerCase()
    );
    if (found) {
      const user: UserProfile = {
        id: `usr-${found.role}`,
        username: found.username,
        fullName: found.name,
        email: found.email,
        role: found.role as UserRole,
        studentId: found.studentId,
        teacherId: found.teacherId
      };
      setCurrentUser(user);
      setIsAuthModalOpen(false);
      setIsSiakadMode(true);
      setActiveSiakadModule('dashboard');
      recordLog('LOGIN', 'Autentikasi', `Login berhasil sebagai ${user.fullName} (${user.role})`);
      return true;
    }
    return false;
  };

  const quickSwitchRole = (roleKey: string) => {
    const demo = demoAccounts.find(d => d.role === roleKey);
    if (demo) {
      const user: UserProfile = {
        id: `usr-${demo.role}`,
        username: demo.username,
        fullName: demo.name,
        email: demo.email,
        role: demo.role as UserRole,
        studentId: demo.studentId,
        teacherId: demo.teacherId
      };
      setCurrentUser(user);
      setIsAuthModalOpen(false);
      recordLog('SWITCH_ROLE', 'Sistem', `Berganti peran aktif ke: ${demo.name}`);
    }
  };

  const logout = () => {
    if (currentUser) {
      recordLog('LOGOUT', 'Autentikasi', `User ${currentUser.fullName} keluar.`);
    }
    setCurrentUser(null);
    setIsSiakadMode(false);
    setPublicPage('home');
  };

  // Student CRUD
  const addStudent = (studentData: Omit<Student, 'id'>) => {
    const newStudent: Student = {
      ...studentData,
      id: `std-${Date.now()}`
    };
    setStudents(prev => [newStudent, ...prev]);
    recordLog('TAMBAH_SISWA', 'Kesiswaan', `Menambahkan siswa baru: ${newStudent.fullName} (${newStudent.nis})`);
  };

  const updateStudent = (id: string, updated: Partial<Student>) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
    recordLog('UPDATE_SISWA', 'Kesiswaan', `Pembaruan data siswa ID ${id}`);
  };

  const deleteStudent = (id: string) => {
    const std = students.find(s => s.id === id);
    setStudents(prev => prev.filter(s => s.id !== id));
    recordLog('HAPUS_SISWA', 'Kesiswaan', `Menghapus data siswa: ${std?.fullName || id}`);
  };

  // Teacher CRUD
  const addTeacher = (teacherData: Omit<Teacher, 'id'>) => {
    const newTeacher: Teacher = {
      ...teacherData,
      id: `t-${Date.now()}`
    };
    setTeachers(prev => [newTeacher, ...prev]);
    recordLog('TAMBAH_GURU', 'Kepegawaian', `Menambahkan guru: ${newTeacher.fullName}`);
  };

  const updateTeacher = (id: string, updated: Partial<Teacher>) => {
    setTeachers(prev => prev.map(t => t.id === id ? { ...t, ...updated } : t));
    recordLog('UPDATE_GURU', 'Kepegawaian', `Pembaruan data guru ID ${id}`);
  };

  const deleteTeacher = (id: string) => {
    const t = teachers.find(item => item.id === id);
    setTeachers(prev => prev.filter(item => item.id !== id));
    recordLog('HAPUS_GURU', 'Kepegawaian', `Menghapus guru: ${t?.fullName || id}`);
  };

  // Class CRUD
  const addClass = (clsData: Omit<SchoolClass, 'id'>) => {
    const newCls: SchoolClass = { ...clsData, id: `c-${Date.now()}` };
    setClasses(prev => [...prev, newCls]);
    recordLog('TAMBAH_KELAS', 'Akademik', `Menambahkan rombel ${newCls.name}`);
  };

  const updateClass = (id: string, updated: Partial<SchoolClass>) => {
    setClasses(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c));
    recordLog('UPDATE_KELAS', 'Akademik', `Update rombel ID ${id}`);
  };

  const deleteClass = (id: string) => {
    setClasses(prev => prev.filter(c => c.id !== id));
    recordLog('HAPUS_KELAS', 'Akademik', `Menghapus kelas ID ${id}`);
  };

  // Subject CRUD
  const addSubject = (subjData: Omit<Subject, 'id'>) => {
    const newSubj: Subject = { ...subjData, id: `s-${Date.now()}` };
    setSubjects(prev => [...prev, newSubj]);
    recordLog('TAMBAH_MAPEL', 'Kurikulum', `Menambahkan mapel ${newSubj.name}`);
  };

  const updateSubject = (id: string, updated: Partial<Subject>) => {
    setSubjects(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
    recordLog('UPDATE_MAPEL', 'Kurikulum', `Update mapel ID ${id}`);
  };

  const deleteSubject = (id: string) => {
    setSubjects(prev => prev.filter(s => s.id !== id));
    recordLog('HAPUS_MAPEL', 'Kurikulum', `Menghapus mapel ID ${id}`);
  };

  // Schedule CRUD
  const addSchedule = (schData: Omit<ScheduleItem, 'id'>) => {
    const newSch: ScheduleItem = { ...schData, id: `sch-${Date.now()}` };
    setSchedules(prev => [...prev, newSch]);
    recordLog('TAMBAH_JADWAL', 'Jadwal', `Jadwal ${newSch.subjectName} (${newSch.className}) ditambahkan`);
  };

  const updateSchedule = (id: string, updated: Partial<ScheduleItem>) => {
    setSchedules(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
  };

  const deleteSchedule = (id: string) => {
    setSchedules(prev => prev.filter(s => s.id !== id));
  };

  // Attendance
  const saveAttendanceBatch = (records: Omit<AttendanceRecord, 'id'>[]) => {
    const newRecords: AttendanceRecord[] = records.map((r, idx) => ({
      ...r,
      id: `att-${Date.now()}-${idx}`
    }));
    // Remove duplicates for same student, class, date, subject
    setAttendance(prev => {
      const filtered = prev.filter(p => 
        !records.some(r => r.studentId === p.studentId && r.date === p.date && r.classId === p.classId)
      );
      return [...newRecords, ...filtered];
    });
    recordLog('SIMPAN_PRESENSI', 'Presensi', `Menyimpan presensi ${records.length} siswa.`);
  };

  // Grades
  const saveGrade = (input: Omit<GradeItem, 'id' | 'finalScore' | 'predicate' | 'lastUpdated'> & { id?: string }) => {
    const wTugas = settings.gradeWeightTugas / 100;
    const wPraktik = settings.gradeWeightPraktik / 100;
    const wUts = settings.gradeWeightUts / 100;
    const wUas = settings.gradeWeightUas / 100;

    const finalScore = Math.round(
      (input.tugas * wTugas) +
      (input.praktik * wPraktik) +
      (input.uts * wUts) +
      (input.uas * wUas)
    );

    let predicate: 'A' | 'B' | 'C' | 'D' = 'D';
    if (finalScore >= 88) predicate = 'A';
    else if (finalScore >= 78) predicate = 'B';
    else if (finalScore >= 70) predicate = 'C';

    const updatedGrade: GradeItem = {
      ...input,
      id: input.id || `grd-${Date.now()}`,
      finalScore,
      predicate,
      lastUpdated: new Date().toISOString().split('T')[0]
    };

    setGrades(prev => {
      const exists = prev.some(g => g.id === updatedGrade.id || (g.studentId === updatedGrade.studentId && g.subjectId === updatedGrade.subjectId));
      if (exists) {
        return prev.map(g => (g.id === updatedGrade.id || (g.studentId === updatedGrade.studentId && g.subjectId === updatedGrade.subjectId)) ? updatedGrade : g);
      }
      return [updatedGrade, ...prev];
    });

    recordLog('SIMPAN_NILAI', 'Penilaian', `Input/update nilai siswa ${input.studentName} mapel ${input.subjectName} -> ${finalScore} (${predicate})`);
  };

  // Teaching Journal
  const addJournal = (jnlData: Omit<TeachingJournal, 'id'>) => {
    const newJnl: TeachingJournal = { ...jnlData, id: `jnl-${Date.now()}` };
    setJournals(prev => [newJnl, ...prev]);
    recordLog('TAMBAH_JURNAL', 'Jurnal Guru', `Agenda guru ${newJnl.teacherName} kelas ${newJnl.className}`);
  };

  const updateJournal = (id: string, updated: Partial<TeachingJournal>) => {
    setJournals(prev => prev.map(j => j.id === id ? { ...j, ...updated } : j));
  };

  const deleteJournal = (id: string) => {
    setJournals(prev => prev.filter(j => j.id !== id));
  };

  // PPDB
  const submitPPDB = (data: Omit<PPDBApplication, 'id' | 'registrationNumber' | 'registrationDate' | 'status'>): string => {
    const nextSeq = String(ppdbList.length + 1).padStart(3, '0');
    const regNum = `PPDB-${settings.ppdbYear.slice(0, 4)}-TKJ-${nextSeq}`;
    const newApp: PPDBApplication = {
      ...data,
      id: `ppdb-${Date.now()}`,
      registrationNumber: regNum,
      registrationDate: new Date().toISOString().split('T')[0],
      status: 'Menunggu Verifikasi',
      notes: 'Formulir online berhasil dikirim. Menunggu verifikasi berkas oleh panitia.'
    };
    setPpdbList(prev => [newApp, ...prev]);
    recordLog('SUBMIT_PPDB', 'PPDB Online', `Pendaftaran calon siswa: ${newApp.fullName} (${regNum})`);
    return regNum;
  };

  const updatePPDBStatus = (id: string, status: PPDBApplication['status'], notes?: string) => {
    setPpdbList(prev => prev.map(item => item.id === id ? {
      ...item,
      status,
      notes: notes !== undefined ? notes : item.notes
    } : item));
    recordLog('STATUS_PPDB', 'PPDB Admin', `Verifikasi status ID ${id} diubah ke ${status}`);
  };

  // News
  const addNews = (newsData: Omit<SchoolNews, 'id' | 'slug' | 'publishedAt'>) => {
    const slug = newsData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newArticle: SchoolNews = {
      ...newsData,
      id: `news-${Date.now()}`,
      slug,
      publishedAt: new Date().toISOString().split('T')[0]
    };
    setNewsList(prev => [newArticle, ...prev]);
    recordLog('TAMBAH_BERITA', 'Konten Website', `Publikasi artikel: ${newArticle.title}`);
  };

  const updateNews = (id: string, updated: Partial<SchoolNews>) => {
    setNewsList(prev => prev.map(n => n.id === id ? { ...n, ...updated } : n));
  };

  const deleteNews = (id: string) => {
    setNewsList(prev => prev.filter(n => n.id !== id));
  };

  // Gallery
  const addGalleryItem = (itemData: Omit<GalleryItem, 'id'>) => {
    const newItem: GalleryItem = { ...itemData, id: `gal-${Date.now()}` };
    setGalleryList(prev => [newItem, ...prev]);
    recordLog('TAMBAH_GALERI', 'Konten Website', `Unggah foto galeri: ${newItem.title}`);
  };

  const deleteGalleryItem = (id: string) => {
    setGalleryList(prev => prev.filter(g => g.id !== id));
  };

  // Settings
  const updateSettings = (newSettings: Partial<SchoolSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    recordLog('UPDATE_PENGATURAN', 'Sistem', 'Pembaruan pengaturan identitas & konfigurasi akademik sekolah.');
  };

  // Reset & Export
  const resetAllData = () => {
    setSettings(initialSchoolSettings);
    setStudents(initialStudents);
    setTeachers(initialTeachers);
    setClasses(initialClasses);
    setSubjects(initialSubjects);
    setSchedules(initialSchedules);
    setAttendance(initialAttendance);
    setGrades(initialGrades);
    setJournals(initialJournals);
    setPpdbList(initialPPDB);
    setNewsList(initialNews);
    setGalleryList(initialGallery);
    setAuditLogs(initialAuditLogs);
    localStorage.clear();
    recordLog('RESET_DATABASE', 'Sistem', 'Database telah diatur ulang ke data inisial.');
  };

  const exportJSON = () => {
    const fullBackup = {
      exportDate: new Date().toISOString(),
      school: settings.schoolName,
      settings,
      students,
      teachers,
      classes,
      subjects,
      schedules,
      attendance,
      grades,
      journals,
      ppdbList,
      newsList,
      galleryList,
      auditLogs
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullBackup, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `Backup_SIAKAD_SMK_AlBashry_${new Date().toISOString().split('T')[0]}.json`);
    dlAnchor.click();
  };

  return (
    <AppContext.Provider
      value={{
        isSiakadMode,
        publicPage,
        activeSiakadModule,
        selectedNewsSlug,
        navigateToPublic,
        navigateToSiakad,
        exitSiakadToPublic,

        currentUser,
        login,
        quickSwitchRole,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,

        settings,
        students,
        teachers,
        classes,
        subjects,
        schedules,
        attendance,
        grades,
        journals,
        ppdbList,
        newsList,
        galleryList,
        auditLogs,

        addStudent,
        updateStudent,
        deleteStudent,

        addTeacher,
        updateTeacher,
        deleteTeacher,

        addClass,
        updateClass,
        deleteClass,

        addSubject,
        updateSubject,
        deleteSubject,

        addSchedule,
        updateSchedule,
        deleteSchedule,

        saveAttendanceBatch,
        saveGrade,

        addJournal,
        updateJournal,
        deleteJournal,

        submitPPDB,
        updatePPDBStatus,

        addNews,
        updateNews,
        deleteNews,

        addGalleryItem,
        deleteGalleryItem,

        updateSettings,
        resetAllData,
        exportJSON
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
